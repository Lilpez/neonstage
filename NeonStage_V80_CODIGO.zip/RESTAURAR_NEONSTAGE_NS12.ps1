$ErrorActionPreference = 'Stop'
$root = 'C:\Users\freit\Downloads\NeonStage_V80'
$backup = 'C:\Users\freit\Downloads\NeonStage_V80\BACKUP_ANTES_NS12_20261012_182947_385495'
if (!(Test-Path $backup)) { throw 'Backup nao encontrado' }
Copy-Item -LiteralPath (Join-Path $backup 'static\index.html') -Destination (Join-Path $root 'static\index.html') -Force
Copy-Item -LiteralPath (Join-Path $backup 'static\neon_next.js') -Destination (Join-Path $root 'static\neon_next.js') -Force
Copy-Item -LiteralPath (Join-Path $backup 'static\neon10.js') -Destination (Join-Path $root 'static\neon10.js') -Force
Remove-Item -LiteralPath (Join-Path $root 'static\neon12.js') -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath (Join-Path $root 'static\neon12.css') -Force -ErrorAction SilentlyContinue
Write-Host 'NS11 restaurada. Reinicie o navegador.' -ForegroundColor Green
