﻿from __future__ import annotations
from pathlib import Path
import sys, re, json, shutil, datetime, subprocess, os

if len(sys.argv) != 2:
    raise SystemExit('Uso: python install53.py RAIZ_NEONSTAGE')
root = Path(sys.argv[1]).resolve()
app = root / 'app.py'
html = root / 'static' / 'index.html'
js = root / 'static' / 'neon_storage_phase5.js'
css = root / 'static' / 'neon_storage_phase5.css'
config = root / 'neon_storage.json'
files = (app, html, js, css)
if not all(p.is_file() for p in files):
    raise SystemExit('Instale antes o armazenamento Fase 5 e o seletor Fase 5.2.')

source = app.read_text(encoding='utf-8-sig')
original_html = html.read_bytes()
if '# NS_STORAGE_FASE5_BOOT' not in source or '# NS_STORAGE_FASE5_API' not in source or '# NS_STORAGE_FOLDER_PICKER_52' not in source:
    raise SystemExit('Estrutura da Fase 5.2 nao reconhecida. Nada foi alterado.')
if 'neon_storage_phase5.js' not in original_html.decode('utf-8-sig'):
    raise SystemExit('O HTML nao carrega o armazenamento Fase 5. Nada alterado.')

BOOT = r'''# NS_STORAGE_FASE5_BOOT
# NS_STORAGE_FASE53_NO_COPY
import json as _ns_storage_json
_NS_STORAGE_CONFIG = ROOT / 'neon_storage.json'

def _ns_storage_documents_folder():
    try:
        import winreg as _ns_winreg
        with _ns_winreg.OpenKey(_ns_winreg.HKEY_CURRENT_USER,
                r'Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders') as key:
            raw, _ = _ns_winreg.QueryValueEx(key, 'Personal')
            return Path(os.path.expandvars(raw)).resolve()
    except Exception:
        return Path.home() / 'Documents'

def _ns_storage_default_folder():
    return _ns_storage_documents_folder() / 'NeonStage' / 'Musicas'

def _ns_storage_selected():
    try:
        obj = _ns_storage_json.loads(_NS_STORAGE_CONFIG.read_text(encoding='utf-8-sig'))
        raw = str(obj.get('songs_path', '')).strip()
        dest = Path(os.path.expandvars(raw)).expanduser()
        if raw and dest.is_absolute():
            return dest.resolve(strict=False)
    except (OSError, ValueError, TypeError):
        pass
    return _ns_storage_default_folder()

SONGS = _ns_storage_selected()
SONGS.mkdir(parents=True, exist_ok=True)
'''

API = r'''# NS_STORAGE_FASE5_API
# NS_STORAGE_FASE53_SETTINGS
@app.get('/api/neon/storage')
def neon_storage_info():
    if request.remote_addr not in ('127.0.0.1', '::1'):
        return jsonify(error='Apenas no PC do servidor.'), 403
    saved = _ns_storage_selected()
    active = SONGS.resolve()
    return jsonify(path=str(active), selected=str(saved),
        default=str(_ns_storage_default_folder()),
        restart_required=saved != active)

'''

POST = r'''# NS_STORAGE_FASE53_SAVE_WITHOUT_COPY
@app.post('/api/neon/storage')
def neon_storage_change():
    if request.remote_addr not in ('127.0.0.1', '::1'):
        return jsonify(error='Apenas no PC do servidor.'), 403
    origin = request.headers.get('Origin', '')
    if origin and origin != (request.scheme + '://' + request.host):
        return jsonify(error='Origem nao autorizada.'), 403
    if request.headers.get('X-NeonStage-Local') != '1':
        return jsonify(error='Requisicao local nao autorizada.'), 403
    with LOCK:
        if any(j.get('progress', 0) < 100 and not j.get('error') for j in JOBS.values()):
            return jsonify(error='Aguarde concluir o preparo das musicas.'), 409
    params = request.get_json(silent=True) or {}
    is_default = params.get('restore_default') is True
    requested = str(_ns_storage_default_folder()) if is_default else str(params.get('path') or '').strip()
    if not requested or len(requested) > 550:
        return jsonify(error='Escolha uma pasta valida.'), 400
    try:
        dest = Path(os.path.expandvars(requested)).expanduser()
        if not dest.is_absolute():
            return jsonify(error='Escolha o caminho completo da pasta.'), 400
        dest = dest.resolve(strict=False)
        legacy = SONGS.resolve()
        # Keep the current legacy location usable, but reject selecting a new
        # directory within the application or selecting a drive root.
        if dest != legacy and (dest == ROOT or dest in ROOT.parents or ROOT in dest.parents):
            return jsonify(error='Escolha uma pasta fora do diretorio do programa.'), 400
        if dest == Path(dest.anchor):
            return jsonify(error='Escolha uma pasta dentro do disco, nao a raiz.'), 400
        dest.mkdir(parents=True, exist_ok=True)
        if not dest.is_dir():
            return jsonify(error='O caminho escolhido nao e uma pasta.'), 400
        import tempfile as _ns_tempfile
        with _ns_tempfile.TemporaryFile(dir=str(dest)) as test:
            test.write(b'OK')
            test.flush()
        path = ROOT / 'neon_storage.json'
        temp = path.with_name('neon_storage.json.pending')
        payload = _ns_storage_json.dumps({'songs_path': str(dest)}, ensure_ascii=False, indent=2)
        try:
            temp.write_text(payload, encoding='utf-8')
            temp.replace(path)
        finally:
            temp.unlink(missing_ok=True)
        return jsonify(ok=True, path=str(dest),
            restart_required=(dest != legacy),
            copied=0, restored_default=is_default)
    except (OSError, ValueError, PermissionError) as exc:
        return jsonify(error=str(exc)[:400]), 400

'''

# Build an all-or-nothing patch. Preserve Windows HTML bytes exactly, except
# for cache-query values for these two storage assets.
if '# NS_STORAGE_FASE53_NO_COPY' not in source:
    start = source.index('# NS_STORAGE_FASE5_BOOT')
    end = source.index("app = Flask(", start)
    source = source[:start] + BOOT + '\n' + source[end:]

    start = source.index('# NS_STORAGE_FASE5_API')
    end = source.index('# NS_STORAGE_FOLDER_PICKER_52', start)
    source = source[:start] + API + source[end:]

    start = source.index("@app.post('/api/neon/storage')")
    end = source.index("@app.get('/api/library')", start)
    source = source[:start] + POST + source[end:]

    # Do not auto-populate new selected folders with the demonstration song.
    source, count = re.subn(r'(?m)^make_demo\(\)\s*$',
        "if SONGS.resolve() == (ROOT / 'songs').resolve():\n    make_demo()", source, count=1)
    if count != 1:
        raise SystemExit('Inicializacao de demonstracao nao reconhecida; nada alterado.')
compile(source, str(app), 'exec')

STORAGE_JS = r'''(()=>{
'use strict';
if(window.__NS_STORAGE_53__)return;
window.__NS_STORAGE_53__=true;
const mount=()=>{
 const slot=document.querySelector('#settingsSection #nsDevStorage');
 if(!slot)return;
 const card=slot.closest('.ns-dev-card');if(!card)return;
 const existing=card.querySelector('#nsStoragePicker');if(existing)existing.remove();
 const hint=card.querySelector('.search-hint');
 if(hint)hint.textContent='Escolha a pasta onde as proximas musicas ficarao salvas. Nao copia nem remove musicas de outras pastas.';
 const box=document.createElement('div');box.id='nsStoragePicker';
 const label=document.createElement('label');label.htmlFor='nsStorageFolder';label.textContent='Local das musicas';
 const field=document.createElement('input');field.type='text';field.id='nsStorageFolder';field.spellcheck=false;field.placeholder='Escolha uma pasta no computador';
 const actions=document.createElement('div');actions.className='ns-storage-actions';
 const button=(id,title,cls)=>{const b=document.createElement('button');b.type='button';b.id=id;b.textContent=title;b.className=cls;actions.appendChild(b);return b};
 const browse=button('nsStorageBrowse','Procurar pasta...','ghost');
 const save=button('nsStorageSave','Salvar','primary');
 const reset=button('nsStorageDefault','Restaurar local padrao','ghost');
 const info=document.createElement('p');info.id='nsStorageMessage';info.setAttribute('role','status');
 const note=document.createElement('p');note.className='ns-storage-note';
 note.textContent='Uma pasta nova comeca vazia. As musicas da pasta anterior continuam la; para ve-las novamente, selecione aquela pasta.';
 box.append(label,field,actions,info,note);card.appendChild(box);
 let activePath='',savedPath='',defaultPath='';
 const status=(s,isError=false)=>{info.textContent=s;info.dataset.error=isError?'1':'0'};
 const load=async()=>{
  const r=await fetch('/api/neon/storage',{cache:'no-store'});const d=await r.json();
  if(!r.ok)throw Error(d.error||'Nao foi possivel ler o armazenamento.');
  activePath=d.path||'';savedPath=d.selected||activePath;defaultPath=d.default||'';
  field.value=savedPath;slot.textContent='Pasta ativa: '+activePath;
  if(d.restart_required)status('Alteracao salva. Reinicie o NeonStage para ativar a pasta selecionada.');
  else status('Armazenamento pronto.');
 };
 const commit=async(restore=false)=>{
  save.disabled=reset.disabled=browse.disabled=true;
  status('Salvando o local escolhido...');
  try{
   const r=await fetch('/api/neon/storage',{
    method:'POST',headers:{'Content-Type':'application/json','X-NeonStage-Local':'1'},
    body:JSON.stringify(restore?{restore_default:true}:{path:field.value})
   });
   const d=await r.json();if(!r.ok)throw Error(d.error||'Falha ao salvar.');
   savedPath=d.path;field.value=savedPath;
   if(d.restart_required)status('Local salvo. Reinicie o NeonStage para utilizar esta pasta. Nenhuma musica foi copiada.');
   else status('Local ja esta ativo. Nenhuma musica foi copiada.');
  }catch(e){status('Erro ao salvar: '+e.message,true)}
  finally{save.disabled=reset.disabled=browse.disabled=false}
 };
 browse.onclick=async()=>{
  browse.disabled=true;status('Escolha a pasta na janela do Windows.');
  try{
   const r=await fetch('/api/neon/storage/pick-folder',{
    method:'POST',headers:{'Content-Type':'application/json','X-NeonStage-Local':'1'},
    body:JSON.stringify({current:field.value})
   });
   const d=await r.json();if(!r.ok)throw Error(d.error||'Falha ao abrir o explorador.');
   if(d.cancelled){status('Selecao cancelada.');return}
   if(!d.path)throw Error('O seletor nao retornou uma pasta.');
   field.value=d.path;status('Pasta escolhida. Clique em Salvar para ativar.');
  }catch(e){status('Erro ao escolher pasta: '+e.message,true)}
  finally{browse.disabled=false}
 };
 save.onclick=()=>commit(false);
 reset.onclick=()=>{
  if(!defaultPath){status('Nao foi possivel identificar Documentos.',true);return}
  field.value=defaultPath;commit(true);
 };
 load().catch(e=>status('Erro: '+e.message,true));
};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount);else mount();
})();
'''

STORAGE_CSS = r'''#nsStoragePicker{margin-top:18px;max-width:780px;color:#d8dbf1}
#nsStoragePicker label{display:block;font-size:13px;font-weight:750;margin-bottom:8px}
#nsStorageFolder{width:100%;box-sizing:border-box;padding:14px 15px;border:1px solid #ffffff40;border-radius:10px;color:#fff;background:#101321;font:500 14px system-ui}
#nsStoragePicker .ns-storage-actions{display:flex;gap:12px;flex-wrap:wrap;margin-top:15px}
#nsStoragePicker .ns-storage-actions button{padding:12px 16px;border-radius:10px;cursor:pointer;font-weight:750}
#nsStorageBrowse{background:linear-gradient(115deg,#6652a4,#453a7a);color:#fff;border:1px solid #9f86e3;box-shadow:0 3px 18px #0003}
#nsStorageDefault{background:#20243a;color:#f0f0ff;border:1px solid #aaa5d070}
#nsStorageSave{background:linear-gradient(90deg,#7055d4,#9953d0);color:white;border:1px solid #cab1ff5e}
#nsStoragePicker button:hover{filter:brightness(1.12)}
#nsStoragePicker button:disabled{opacity:.5;cursor:wait}
#nsStorageMessage{margin-top:12px;font-size:13px;line-height:1.5;color:#bde9d4}
#nsStorageMessage[data-error="1"]{color:#ffc3c3}
#nsStoragePicker .ns-storage-note{margin-top:8px;color:#aeb6ce;line-height:1.5;font-size:12px}
'''

html_bytes = original_html
for filename, tag in ((b'neon_storage_phase5.js', b'5301'),(b'neon_storage_phase5.css',b'5301')):
    regex = rb'('+re.escape(filename)+rb')(?:\?v=\d+)?'
    html_bytes, found = re.subn(regex, lambda m: m.group(1)+b'?v='+tag, html_bytes)
    if found != 1:
        raise SystemExit('Referencia HTML invalida: '+filename.decode())

# Preserve current folder until the user chooses to switch.  On new installs
# where there is no config, this writes the existing legacy path as selection.
config_payload = None
if not config.exists():
    config_payload = json.dumps({'songs_path':str(root/'songs')},ensure_ascii=False,indent=2)
else:
    # Validate existing config; do not change it.
    json.loads(config.read_text(encoding='utf-8-sig'))

node = shutil.which('node')
if node:
    chk = subprocess.run([node, '--check', '-'],input=STORAGE_JS,text=True,capture_output=True)
    if chk.returncode: raise SystemExit('Erro no JS: '+chk.stderr[-400:])

contents = {app: source.encode('utf-8'), js: STORAGE_JS.encode('utf-8'),css: STORAGE_CSS.encode('utf-8'),html:html_bytes}
modified = {p:body for p,body in contents.items() if p.read_bytes()!=body}
if not modified and config_payload is None:
    print('FASE 5.3 ja instalada. Nenhuma alteracao.')
    raise SystemExit(0)
backup = root / ('backup_pre_storage53_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
backup.mkdir()
for p in modified:
    relative=p.relative_to(root);dest=backup/relative;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)

try:
    for p,body in modified.items():
        temp=p.with_name(p.name+'.ns53tmp')
        try:
            temp.write_bytes(body)
            temp.replace(p)
        finally:
            temp.unlink(missing_ok=True)
    if config_payload is not None:
        config.write_text(config_payload,encoding='utf-8')
except BaseException:
    for p in modified:
        shutil.copy2(backup/p.relative_to(root),p)
    if config_payload is not None:
        config.unlink(missing_ok=True)
    raise

print('ARMAZENAMENTO FASE 5.3 INSTALADO')
print('Pasta atual preservada ate escolha em Configuracoes.')
print('Padrao: Documentos\\NeonStage\\Musicas')
print('Sem copiar ou apagar musicas.')
print('Backup:',backup)
print('Reinicie o servidor para ativar esta alteracao.')
