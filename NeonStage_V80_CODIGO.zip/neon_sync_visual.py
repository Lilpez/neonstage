"""NS14.3 experimental karaoke video image-analysis module.

Strictly local analysis, no server-provided file paths, no OCR of the user's lyrics.
The external YouTube recording is merely a visual reference; never changes chart.json.
"""
from __future__ import annotations
import json
import math
import os
import statistics
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from difflib import SequenceMatcher
from neon_sync_reference import youtube_url, match_cues

MAX_SECONDS = 720
MAX_BYTES = 65 * 1024 * 1024


def metadata(url: str) -> dict:
    # The canonical URL is mandatory, not an arbitrary fetch destination.
    url = youtube_url(url)
    import yt_dlp
    with yt_dlp.YoutubeDL({'quiet': True, 'no_warnings': True, 'no_playlist':True, 'skip_download':True,
                         'socket_timeout':15, 'retries':1, 'extractor_retries':1}) as ydl:
        data=ydl.extract_info(url, download=False)
    if data is None or data.get('_type') == 'playlist':
        raise ValueError('Escolha um video individual.')
    duration=float(data.get('duration') or 0)
    if not 10 <= duration <= MAX_SECONDS:
        raise ValueError('Video sem duracao conhecida ou maior que 12 minutos.')
    return {'title': str(data.get('title') or '')[:180], 'duration':duration,
            'url':url}


def download_video(url: str, folder: Path) -> Path:
    import yt_dlp
    options={'quiet': True, 'no_warnings':True, 'no_playlist':True,
             'format':'best[height<=480][ext=mp4]/best[height<=480][ext=webm]/best[height<=480]',
             'outtmpl':str(folder/'visual.%(ext)s'),
             'max_filesize':MAX_BYTES, 'socket_timeout':15, 'retries':1,
             'extractor_retries':1, 'noplaylist':True, 'overwrites':False,
             'postprocessors':[]}
    with yt_dlp.YoutubeDL(options) as ydl:
        ydl.download([youtube_url(url)])
    candidates=[p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in ('.mp4','.webm','.mkv')]
    if len(candidates)!=1 or candidates[0].stat().st_size>MAX_BYTES:
        raise ValueError('Video indisponivel ou acima do limite de 65 MB.')
    return candidates[0]


def _ocr_texts(engine, crop, y_offset:int=0,x_offset:int=0) -> list[dict]:
    import cv2
    result=engine(cv2.cvtColor(crop, cv2.COLOR_BGR2RGB))
    if isinstance(result,tuple): result=result[0]
    if hasattr(result, 'txts'):
        texts=result.txts if result.txts is not None else []
        boxes=result.boxes if result.boxes is not None else []
        scores=result.scores if result.scores is not None else []
        vals=zip(boxes,texts,scores)
    elif isinstance(result,list):
        vals=[(r[0],r[1],r[2]) for r in result if isinstance(r,(tuple,list)) and len(r)>=3]
    else:return []
    found=[]
    for box,txt,score in vals:
        try:
            score=float(score)
            if score<.42 or len(str(txt).strip())<4:continue
            xs=[float(p[0]) for p in box];ys=[float(p[1]) for p in box]
            l,t,r,b=int(min(xs))+x_offset,int(min(ys))+y_offset,int(max(xs))+x_offset,int(max(ys))+y_offset
            if b-t<8 or r-l<16:continue
            found.append({'text':str(txt).strip()[:220], 'score':round(score,3), 'bbox':[l,t,r,b]})
        except (TypeError,ValueError,IndexError,KeyError):continue
    return found


def _norm(text:str) -> str:
    import re,unicodedata
    text=''.join(c for c in unicodedata.normalize('NFKD',text.casefold()) if not unicodedata.combining(c))
    return ' '.join(re.findall(r'[a-z0-9]+',text))


def _fuse(observations: list[dict], max_gap=1.7) -> list[dict]:
    # Group sightings of the same line. A stable line held onscreen is NOT a new lyric every frame.
    active={};finished=[]
    for obs in sorted(observations,key=lambda z:z['at']):
        key=_norm(obs['text'])
        if not key:continue
        old=active.get(key)
        if old and obs['at']-old['end']<=max_gap:
            old['end']=obs['at'];old['frames']+=1
            if obs['score']>old['ocr_conf']:
                old.update(text=obs['text'],ocr_conf=obs['score'],bbox=obs['bbox'])
        else:
            if old:finished.append(old)
            active[key]={'start':obs['at'],'end':obs['at'],'text':obs['text'],
                         'ocr_conf':obs['score'],'bbox':obs['bbox'],'frames':1}
    finished.extend(active.values())
    finished.sort(key=lambda x:(x['start'],x['end']))
    return [d for d in finished if d['frames']>=2 and len(_norm(d['text']))>=6]


def _highlight(video:Path, bbox, first:float, last:float, interval=.25) -> dict:
    """Heuristic color-transition estimate, never validated speech onset."""
    import cv2
    cap=cv2.VideoCapture(str(video))
    if not cap.isOpened():return {'state':'video_unreadable'}
    fps=cap.get(cv2.CAP_PROP_FPS) or 0
    w=int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)); h=int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    x0,y0,x1,y1=[int(x) for x in bbox]
    x0=max(0,x0-4);x1=min(w,x1+4);y0=max(0,y0-3);y1=min(h,y1+3)
    if x1-x0<18 or y1-y0<10:return {'state':'small_bbox'}
    ratios=[]
    for index in range(min(42,int(max(0,(last-first)+1.0)/interval)+1)):
        t=max(0,first-.35+index*interval)
        if t>last+1:break
        cap.set(cv2.CAP_PROP_POS_MSEC,t*1000)
        ok,frame=cap.read()
        if not ok:continue
        roi=frame[y0:y1,x0:x1]
        hsv=cv2.cvtColor(roi,cv2.COLOR_BGR2HSV)
        # Bright colored pixels are candidate highlight ink. Decorative backgrounds
        # can invalidate this heuristic, so require clear change between frames.
        mask=(hsv[:,:,1]>90)&(hsv[:,:,2]>155)
        ratios.append((round(t,3),float(mask.mean())))
    cap.release()
    if len(ratios)<5:return {'state':'insufficient_frames'}
    baseline=statistics.median(x[1] for x in ratios[:3])
    highest=max(x[1] for x in ratios)
    threshold=max(.045,baseline+.06)
    qualified=[t for i,(t,v) in enumerate(ratios[:-1]) if v>=threshold and ratios[i+1][1]>=threshold]
    if not qualified or highest-baseline<.075:
        return {'state':'no_reliable_color_change','color_delta':round(highest-baseline,3)}
    return {'state':'candidate_color_transition','at':qualified[0],
            'color_delta':round(highest-baseline,3),
            'warning':'Mudanca de cor visual; nao prova o instante real da voz.'}


def scan(chart:dict,video:Path, meta:dict, mode:str='visual') -> dict:
    import cv2
    from rapidocr import RapidOCR
    engine=RapidOCR(params={'Rec.lang_type':'pt'})
    cap=cv2.VideoCapture(str(video))
    if not cap.isOpened(): raise RuntimeError('Nao foi possivel abrir o video; tente outro resultado MP4.')
    duration=float(meta['duration']);
    w=int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)); h=int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    if w<100 or h<100:raise RuntimeError('Dimensoes de video invalidas.')
    # 1 frame/sec keeps CPU bounded. Coarse timestamps are estimated to ~1 second.
    sample_step=.85
    observations=[]
    for ix in range(int(duration/sample_step)+1):
        tm=ix*sample_step
        if tm>MAX_SECONDS:break
        cap.set(cv2.CAP_PROP_POS_MSEC,tm*1000)
        ok,frame=cap.read()
        if not ok:continue
        x0=int(w*.06);x1=int(w*.94);y0=int(h*.28);y1=int(h*.96)
        crop=frame[y0:y1,x0:x1]
        if crop.size==0:continue
        for row in _ocr_texts(engine,crop,y0,x0):
            row['at']=round(tm,3)
            observations.append(row)
    cap.release()
    cues=_fuse(observations)
    matched=match_cues(chart,cues)
    for item in matched['lines']:
        cue=next((c for c in cues if abs(c['start']-item['reference_at'])<.001),None)
        if not cue:
            cue=min(cues,key=lambda x:abs(x['start']-item['reference_at'])+(1-SequenceMatcher(None,_norm(x['text']),_norm(item['text'])).ratio())*10)
        item.update(visual_first_seen=cue['start'],visual_last_seen=cue['end'],
                    ocr_confidence=cue['ocr_conf'],ocr_frames=cue['frames'])
        color=_highlight(video,cue['bbox'],cue['start'],cue['end'])
        item['color_transition']=color
        if color.get('state')=='candidate_color_transition':item['visual_highlight_at']=color['at']
    origdur=float(chart.get('duration') or 0)
    diff=abs(duration-origdur) if origdur else None
    ratio=matched['matched_ratio'];mad=matched['offset_mad_seconds']
    compatible=(diff is not None and diff<=max(3.,origdur*.02) and
                len(matched['lines'])>=6 and ratio>=.55 and mad is not None and mad<=.85)
    matched.update({'url':meta['url'],'video_title':meta['title'],
                    'video_duration':duration,'song_duration':origdur,
                    'duration_difference':round(diff,3) if diff is not None else None,
                    'reference_compatible':compatible,'source':'youtube_video_ocr',
                    'visual_reference_only':True,
                    'status':'visual_reference_compatible' if compatible else 'visual_comparison_only',
                    'caption_available':False,'caption_track':None,
                    'observations':len(observations),'visual_cues':len(cues),
                    'sampling_seconds':sample_step,
                    'highlight_candidates':sum('visual_highlight_at' in x for x in matched['lines']),
                    'warning':'OCR e cor podem indicar entrada visual, nao inicio fonetico. '
                              'Uma versao karaokê pode usar audio diferente. Nunca aprovar automaticamente.'})
    return matched


def main():
    if len(sys.argv)!=5:raise SystemExit('Worker requires chart.json, canonical URL, result path and status path.')
    chartfile=Path(sys.argv[1]);url=youtube_url(sys.argv[2]);output=Path(sys.argv[3]);status=Path(sys.argv[4])
    def update(stage):
        status.write_text(json.dumps({'stage':stage},ensure_ascii=False),encoding='utf-8')
    update('Verificando video e duracao')
    chart=json.loads(chartfile.read_text(encoding='utf8'))
    meta=metadata(url)
    with tempfile.TemporaryDirectory(prefix='neon143_visual_') as work:
        update('Baixando video temporario em resolucao reduzida')
        video=download_video(url,Path(work))
        update('Lendo letras desenhadas nos quadros e analisando mudancas de cor')
        result=scan(chart,video,meta)
    # no chart/audio/notes are modified, only this separate visual reference JSON.
    output.write_text(json.dumps({'song_id':chart.get('id'), 'reference':result},
                ensure_ascii=False,indent=2),encoding='utf-8')
    update('Concluido')
    print(json.dumps({'source':result['source'],'matched_ratio':result['matched_ratio'],
          'matched':len(result['lines']),'highlights':result['highlight_candidates']}))

if __name__=='__main__':main()
