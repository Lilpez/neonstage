"""NeonStage — karaoke local. Run with python app.py."""
from __future__ import annotations
import json, os, re, sys, threading, subprocess, uuid, time, wave, math, struct
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from flask import Flask, jsonify, request, send_from_directory, redirect

ROOT = Path(__file__).resolve().parent
SONGS = ROOT / 'songs'
SONGS.mkdir(exist_ok=True)
app = Flask(__name__, static_folder='static', static_url_path='/static')
POOL = ThreadPoolExecutor(max_workers=1)
JOBS: dict[str, dict] = {}
LOCK = threading.Lock()


def status(job_id, stage, progress, error=None, song_id=None):
    with LOCK:
        JOBS[job_id] = dict(stage=stage, progress=progress, error=error, song_id=song_id)


def make_demo():
    dest = SONGS / 'demo_neonstage'
    dest.mkdir(exist_ok=True)
    jpath = dest / 'chart.json'
    audio = dest / 'audio.wav'
    if jpath.exists() and audio.exists(): return
    bpm = 105
    phrases = [
        ['Vem', 'cantar', 'comigo', 'nessa', 'noite'],
        ['Deixa', 'a', 'voz', 'te', 'levar'],
        ['Cada', 'nota', 'vira', 'um', 'sonho'],
        ['E', 'o', 'palco', 'vai', 'brilhar'],
    ]
    pitches = [[60,62,64,65,67],[67,65,64,62,60],[60,62,64,67,65],[64,62,60,62,60]]
    notes=[]; sections=[]
    for pi,words in enumerate(phrases):
        start=2.0+pi*7.5
        for i, word in enumerate(words):
            st=start+i*1.07; end=st+(0.86 if len(word)>2 else 0.55)
            notes.append(dict(start=round(st,3),end=round(end,3),pitch=pitches[pi][i],text=word,talkie=False,confidence=1.0,phrase=pi))
        sections.append(dict(start=round(start-.18,3),end=round(notes[-1]['end']+.18,3),index=pi))
    dur=34.0; rate=22050
    with wave.open(str(audio),'wb') as f:
        f.setnchannels(1);f.setsampwidth(2);f.setframerate(rate)
        block=[]
        for i in range(int(dur*rate)):
            t=i/rate; v=0.
            for note in notes:
                if note['start']<=t<=note['end']:
                    freq=440*2**((note['pitch']-69)/12)
                    env=min(1,(t-note['start'])*12,(note['end']-t)*12)
                    v+=.17*max(0,env)*math.sin(2*math.pi*freq*t)
                    break
            # restrained chord pad
            if t>1:
                v+=.025*math.sin(2*math.pi*130.81*t)+.02*math.sin(2*math.pi*196*t)
            block.append(struct.pack('<h',int(max(-1,min(1,v))*32767)))
            if len(block)>=4096:
                f.writeframesraw(b''.join(block));block=[]
        if block:f.writeframesraw(b''.join(block))
    jpath.write_text(json.dumps(dict(id='demo_neonstage',title='Uma Noite Neon',artist='NeonStage Originals',duration=dur,bpm=bpm,notes=notes,phrases=sections,source='demo',analysis='verified_demo'),ensure_ascii=False,indent=2),encoding='utf-8')

make_demo()


def read_song(path: Path):
    try:
        chart=json.loads((path/'chart.json').read_text(encoding='utf-8'))
        chart['ready']=True
        chart['audio_url']=f"/api/audio/{path.name}"
        return chart
    except Exception:return None

@app.get('/')
def home():
    if request.remote_addr not in ('127.0.0.1','::1'):return redirect('/party')
    return app.send_static_file('index.html')

@app.get('/hostpanel')
def hostpanel():
    if request.remote_addr not in ('127.0.0.1','::1'):return ('Acesso local apenas',403)
    return app.send_static_file('host.html')

@app.get('/api/party/network')
def party_network():
    import socket
    sk=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    try:
        sk.connect(('192.0.2.1',80))
        ip=sk.getsockname()[0]
    except OSError:ip=socket.gethostbyname(socket.gethostname())
    finally:sk.close()
    return jsonify(ip=ip)

@app.get('/api/library')
def library():
    songs=[x for p in SONGS.iterdir() if p.is_dir() if (x:=read_song(p))]
    return jsonify(songs)

@app.get('/api/audio/<song_id>')
def song_audio(song_id):
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',song_id):return ('Invalid ID',400)
    d=SONGS/song_id
    for ext in ('mp3','wav','m4a','ogg'):
        if (d/f'audio.{ext}').exists():return send_from_directory(d,f'audio.{ext}',conditional=True)
    return ('Audio not found',404)

@app.get('/api/song/<song_id>')
def get_song(song_id):
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',song_id):return ('Invalid ID',400)
    v=read_song(SONGS/song_id)
    resp=jsonify(v) if v else ('Not found',404)
    if v: resp.headers['Cache-Control']='no-store'
    return resp

@app.get('/api/search')
def search():
    query=request.args.get('q','').strip()[:120]
    if len(query)<2:return jsonify([])
    try:
        import yt_dlp
        opts={'quiet':True,'no_warnings':True,'extract_flat':True,'skip_download':True,'socket_timeout':12,'ignoreerrors':True,'noplaylist':True,'default_search':'ytsearch'}
        with yt_dlp.YoutubeDL(opts) as ydl:
            data=ydl.extract_info('ytsearch8:'+query,download=False)
        results=[]
        for item in (data or {}).get('entries',[]):
            if not item or not item.get('id'):continue
            vid=item['id']
            results.append(dict(id=vid,title=item.get('title') or 'Sem título',artist=item.get('channel') or item.get('uploader') or 'YouTube',duration=item.get('duration'),image=f'https://i.ytimg.com/vi/{vid}/hqdefault.jpg',url=f'https://www.youtube.com/watch?v={vid}'))
        return jsonify(results)
    except Exception as exc:
        return jsonify(error='Não foi possível buscar no YouTube. Verifique conexão/yt-dlp: '+str(exc)[:180]),503


def run_job(job_id, video_id, title, artist):
    dest=SONGS / job_id
    dest.mkdir(exist_ok=True)
    try:
        status(job_id,'Baixando áudio da versão escolhida',8)
        import yt_dlp
        options={'format':'bestaudio/best','outtmpl':str(dest/'source.%(ext)s'),'noplaylist':True,'quiet':True,'no_warnings':True,'socket_timeout':25,'retries':2,'postprocessors':[{'key':'FFmpegExtractAudio','preferredcodec':'mp3','preferredquality':'192'}]}
        with yt_dlp.YoutubeDL(options) as ydl:
            ydl.download([f'https://www.youtube.com/watch?v={video_id}'])
        src=dest/'source.mp3'
        if not src.exists():raise RuntimeError('Download de áudio indisponível para este vídeo')
        src.rename(dest/'audio.mp3')
        status(job_id,'Separando voz e analisando afinação',30)
        target=dest/'chart.json'
        ai_py=os.getenv('NEONSTAGE_AI_PYTHON',sys.executable)
        cmd=[ai_py,str(ROOT/'analyze.py'),str(dest/'audio.mp3'),str(target),title,artist]
        proc=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace',bufsize=1)
        lines=[]
        for line in proc.stdout:
            line=line.strip();lines.append(line)
            if len(lines)>40:lines.pop(0)
            if line.startswith('STAGE:'):
                status(job_id,line[6:].strip(),max(33,min(90,JOBS.get(job_id,{}).get('progress',33)+12)))
        code=proc.wait()
        if code or not target.exists():raise RuntimeError('Falha na análise: '+' | '.join(lines[-6:])[-650:])
        chart=json.loads(target.read_text(encoding='utf-8'))
        chart.update(id=job_id,title=title,artist=artist,source='youtube')
        target.write_text(json.dumps(chart,ensure_ascii=False,indent=2),encoding='utf-8')
        status(job_id,'Pronto para cantar!',100,song_id=job_id)
    except Exception as exc:
        status(job_id,'Falha ao preparar',0,error=str(exc)[:650])

@app.post('/api/prepare')
def prepare():
    data=request.get_json(silent=True) or {}
    vid=str(data.get('id',''))
    if not re.fullmatch(r'[\w-]{11}',vid):return jsonify(error='ID de vídeo inválido.'),400
    job_id='music_'+uuid.uuid4().hex[:14]
    title=str(data.get('title','Música'))[:160];artist=str(data.get('artist','Artista'))[:120]
    status(job_id,'Na fila',2)
    POOL.submit(run_job,job_id,vid,title,artist)
    return jsonify(job_id=job_id)

@app.get('/api/job/<job_id>')
def job(job_id):
    with LOCK: j=JOBS.get(job_id)
    return jsonify(j) if j else ('Not found',404)

@app.post('/api/import')
def import_local():
    """Import a personal MP3/WAV audio file, then analyze in background."""
    file=request.files.get('file')
    if not file:return jsonify(error='Selecione um arquivo'),400
    extension=Path(file.filename or '').suffix.lower()
    if extension not in ('.mp3','.wav','.m4a','.ogg','.flac'):
        return jsonify(error='Formato não suportado'),400
    file.stream.seek(0,2);size=file.stream.tell();file.stream.seek(0)
    if size>120*1024*1024:return jsonify(error='Arquivo acima de 120 MB'),413
    ident='music_'+uuid.uuid4().hex[:14]; d=SONGS/ident;d.mkdir()
    local=d/('entrada'+extension)
    file.save(local)
    title=(request.form.get('title') or Path(file.filename).stem)[:160]
    artist=(request.form.get('artist') or 'Arquivo local')[:120]
    status(ident,'Na fila',2)
    def local_job():
        try:
            status(ident,'Convertendo áudio local',15)
            cmd=['ffmpeg','-nostdin','-y','-hide_banner','-loglevel','error','-i',str(local),'-vn','-codec:a','libmp3lame','-b:a','192k',str(d/'audio.mp3')]
            r=subprocess.run(cmd,capture_output=True,text=True)
            if r.returncode:raise RuntimeError(r.stderr[-350:])
            status(ident,'Analisando voz e melodia',35)
            ai_py=os.getenv('NEONSTAGE_AI_PYTHON',sys.executable)
            r=subprocess.run([ai_py,str(ROOT/'analyze.py'),str(d/'audio.mp3'),str(d/'chart.json'),title,artist],capture_output=True,text=True,encoding='utf-8',errors='replace')
            if r.returncode:raise RuntimeError((r.stdout+' '+r.stderr)[-700:])
            chart=json.loads((d/'chart.json').read_text(encoding='utf-8'))
            chart.update(id=ident,title=title,artist=artist,source='local')
            (d/'chart.json').write_text(json.dumps(chart,ensure_ascii=False,indent=2),encoding='utf-8')
            status(ident,'Pronto para cantar!',100,song_id=ident)
        except Exception as e:status(ident,'Falha ao preparar',0,error=str(e)[:650])
    POOL.submit(local_job)
    return jsonify(job_id=ident)

from party import register as register_party
register_party(app, ROOT, SONGS, JOBS, POOL, run_job)

if __name__=='__main__':
    import webbrowser
    print('NeonStage no endereço http://127.0.0.1:8765')
    if os.getenv('NEONSTAGE_NO_BROWSER')!='1':
        threading.Timer(1.2,lambda:webbrowser.open('http://127.0.0.1:8765/host')).start()
    app.run(host='0.0.0.0',port=8765,debug=False,threaded=True)
