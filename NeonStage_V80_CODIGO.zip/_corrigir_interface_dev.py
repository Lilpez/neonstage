﻿from pathlib import Path
import datetime
import re
import shutil
import py_compile

ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"
APP = ROOT / "app.py"
CSS = STATIC / "style.css"

STAMP = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
BACKUP = ROOT / ("backup_correcao_interface_" + STAMP)
BACKUP.mkdir(exist_ok=True)

def backup_file(path):
    if not path.exists():
        return
    dest = BACKUP / path.relative_to(ROOT)
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, dest)

def save(path, content):
    old = path.read_text(encoding="utf-8")
    if old == content:
        return False
    backup_file(path)
    path.write_text(content, encoding="utf-8", newline="")
    return True

# 1. Corrigir textos corrompidos por UTF-8 / Windows-1252
bad_chars = ("Ã", "Â", "â€", "â™", "âœ", "â˜", "ï»")
token = re.compile(r'''[^\s<>"'`=]+''')

def repair_piece(match):
    value = match.group(0)
    if not any(x in value for x in bad_chars):
        return value

    candidate = value

    for _ in range(2):
        try:
            converted = candidate.encode("cp1252").decode("utf-8")
        except (UnicodeEncodeError, UnicodeDecodeError):
            break

        if converted == candidate:
            break

        candidate = converted

    return candidate

def repair_text(text):
    return token.sub(repair_piece, text)

changed_files = []
fixed_count = 0

for path in sorted(STATIC.iterdir()):
    if not path.is_file():
        continue
    if path.suffix.lower() not in (".html", ".js"):
        continue

    try:
        original = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        print("IGNORADO (UTF-8 invalido):", path.name)
        continue

    repaired = repair_text(original)

    if repaired != original:
        if save(path, repaired):
            changed_files.append(path.name)
            fixed_count += 1

# 2. Impedir que a tela de preparacao bloqueie
#    a biblioteca de musicas.
marker = "/* NEONSTAGE_FIX_PARTY_LOADING_2026 */"

if CSS.exists():
    original = CSS.read_text(encoding="utf-8")

    if marker not in original:
        rule = (
            "\n" + marker + "\n"
            "#partyLoadingScreen {\n"
            "    display: none !important;\n"
            "}\n"
        )
        if save(CSS, original + rule):
            changed_files.append("style.css")

# 3. Filtrar exclusivamente o polling multiplayer
log_marker = "# NEONSTAGE_QUIET_PARTY_POLLING_2026"

if APP.exists():
    source = APP.read_text(encoding="utf-8")

    if log_marker not in source:
        logging_patch = '''
# NEONSTAGE_QUIET_PARTY_POLLING_2026
import logging as _neon_logging
import re as _neon_re

class _NeonQuietPolling(_neon_logging.Filter):
    def filter(self, record):
        message = record.getMessage()
        if record.levelno >= _neon_logging.WARNING:
            return True
        return not bool(_neon_re.search(
            r'"(?:GET|HEAD) /api/party/(?:state|network)(?:\\?[^ ]*)? HTTP/',
            message
        ))

_neon_logging.getLogger("werkzeug").addFilter(
    _NeonQuietPolling()
)
'''

        # Inserir apos os imports, antes da criacao da app
        anchor = "ROOT = Path(__file__).resolve().parent"

        if anchor not in source:
            raise RuntimeError(
                "Estrutura do app.py inesperada; nao modifiquei o backend."
            )

        updated = source.replace(
            anchor,
            logging_patch + "\n" + anchor,
            1
        )

        # Validar antes de salvar
        compile(updated, str(APP), "exec")
        if save(APP, updated):
            changed_files.append("app.py")

# 4. Validacao e resultado
py_compile.compile(str(APP), doraise=True)

print()
print("=" * 48)
print(" NEONSTAGE - CORRECAO CONCLUIDA")
print("=" * 48)
print("Arquivos alterados:", len(changed_files))

for name in changed_files:
    print("  OK:", name)

print("Arquivos com texto reparado:", fixed_count)
print("Backup:", BACKUP)
print()
print("Polling multiplayer: filtrado")
print("Tela de preparacao: nao bloqueia a biblioteca")
print("Musicas e charts: preservados")
print()
print("Reinicie o servidor e atualize o navegador.")
