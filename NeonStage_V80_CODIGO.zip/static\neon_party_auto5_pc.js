(()=>{
 'use strict';
 if(window.__NS_AUTO5_PC__)return;window.__NS_AUTO5_PC__=true;
 let current='',pending=false,overlay=null,hasStart=false,previousPhase='';
 if(location.pathname!=='/palco')return;
const id=x=>document.getElementById(x);
 function stageActive(){return !!document.getElementById('ns828Stage')||window.NEON_PARTY?.isPlaying?.()===true}
 function dom(){if(overlay)return overlay;overlay=document.createElement('div');overlay.id='nsAuto5PC';overlay.style.cssText='position:fixed;inset:0;z-index:2147483600;display:none;align-items:center;justify-content:center;background:#050715e3;backdrop-filter:blur(14px);color:#fff;font-family:system-ui,sans-serif;text-align:center;pointer-events:auto';overlay.innerHTML='<section style="max-width:480px;padding:34px;border-radius:24px;background:#10172de8;border:1px solid #8bd7ff44;box-shadow:0 20px 90px #000a"><div style="color:#95eaff;font-size:12px;letter-spacing:.24em;font-weight:800">NEONSTAGE PARTY</div><h2 id="nsAuto5Title" style="font-size:30px;margin:18px 0 10px">MÚSICA ENCERRADA</h2><div id="nsAuto5Subtitle" style="font-size:15px;color:#c5cede"></div><div id="nsAuto5Count" style="font-size:82px;font-weight:900;color:#ffd27c;line-height:1.4">5</div><div style="color:#b0b7c9">Próxima apresentação em instantes</div></section>';document.body.append(overlay);return overlay}
 async function tick(){try{
  const r=await fetch('/api/party/state',{cache:'no-store'});if(!r.ok)return;
  const s=await r.json(),due=Number(s.next_at||0),key=s.phase==='between'?`${s.results?.length||0}|${s.position}`:'';
  if(s.phase!=='between'||!due){if(overlay)overlay.style.display='none';current='';pending=false;previousPhase=s.phase;return}
  if(current!==key){current=key;pending=false}
  const remaining=Math.max(0,Math.ceil((due-Date.now()/1000)));
  const el=dom();el.style.display='flex';
  const prev=s.results?.[s.results.length-1],next=s.queue?.[s.position],name=s.players?.[next?.singer]?.name||'Próximo participante';
  id('nsAuto5Title').textContent=prev?.failed?'VOCÊ PERDEU':prev?.skipped?'MÚSICA PULADA':'MÚSICA CONCLUÍDA';
  id('nsAuto5Subtitle').textContent='Próximo a cantar: '+name;
  id('nsAuto5Count').textContent=String(remaining);
  if(remaining<=0&&!pending){pending=true;const rr=await fetch('/api/party/control',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'start'})});if(!rr.ok){pending=false;const e=await rr.json().catch(()=>({}));console.warn('Party auto5:',e.error||rr.status)}else{el.style.display='none'}}
 }catch(e){if(!tick.warned){console.warn('Party auto5:',e);tick.warned=true}}}
 setInterval(tick,300);tick();
})();