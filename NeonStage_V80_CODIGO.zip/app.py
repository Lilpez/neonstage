"""NeonStage — karaoke local. Run with python app.py."""
from __future__ import annotations
import json, os, re, sys, threading, subprocess, uuid, time, wave, math, struct
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from flask import Flask, jsonify, request, send_from_directory, redirect


# NEONSTAGE_QUIET_PARTY_POLLING_2026
import logging as _neon_logging
import re as _neon_re

class _NeonQuietPolling(_neon_logging.Filter):
    def filter(self, record):
        message = record.getMessage()
        if record.levelno >= _neon_logging.WARNING:
            return True
        return not bool(_neon_re.search(
            r'"(?:GET|HEAD) /api/party/(?:state|network)(?:\?[^ ]*)? HTTP/',
            message
        ))

_neon_logging.getLogger("werkzeug").addFilter(
    _NeonQuietPolling()
)

ROOT = Path(__file__).resolve().parent
# NS_STORAGE_FASE5_BOOT
# NS_STORAGE_FASE53_NO_COPY
import json as _ns_storage_json
_NS_STORAGE_CONFIG = ROOT / 'neon_storage.json'

def _ns_storage_documents_folder():
    try:
        import winreg as _ns_winreg
        with _ns_winreg.OpenKey(_ns_winreg.HKEY_CURRENT_USER,
                r'Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders') as key:
            raw, _ = _ns_winreg.QueryValueEx(key, 'Personal')
            return Path(os.path.expandvars(raw)).resolve()
    except Exception:
        return Path.home() / 'Documents'

def _ns_storage_default_folder():
    return _ns_storage_documents_folder() / 'NeonStage' / 'Musicas'

def _ns_storage_selected():
    try:
        obj = _ns_storage_json.loads(_NS_STORAGE_CONFIG.read_text(encoding='utf-8-sig'))
        raw = str(obj.get('songs_path', '')).strip()
        dest = Path(os.path.expandvars(raw)).expanduser()
        if raw and dest.is_absolute():
            return dest.resolve(strict=False)
    except (OSError, ValueError, TypeError):
        pass
    return _ns_storage_default_folder()

SONGS = _ns_storage_selected()
SONGS.mkdir(parents=True, exist_ok=True)

app = Flask(__name__, static_folder='static', static_url_path='/static')
POOL = ThreadPoolExecutor(max_workers=1)
JOBS: dict[str, dict] = {}
LOCK = threading.Lock()


def status(job_id, stage, progress, error=None, song_id=None):
    with LOCK:
        JOBS[job_id] = dict(stage=stage, progress=progress, error=error, song_id=song_id)


def make_demo():
    dest = SONGS / 'demo_neonstage'
    dest.mkdir(exist_ok=True)
    jpath = dest / 'chart.json'
    audio = dest / 'audio.wav'
    if jpath.exists() and audio.exists(): return
    bpm = 105
    phrases = [
        ['Vem', 'cantar', 'comigo', 'nessa', 'noite'],
        ['Deixa', 'a', 'voz', 'te', 'levar'],
        ['Cada', 'nota', 'vira', 'um', 'sonho'],
        ['E', 'o', 'palco', 'vai', 'brilhar'],
    ]
    pitches = [[60,62,64,65,67],[67,65,64,62,60],[60,62,64,67,65],[64,62,60,62,60]]
    notes=[]; sections=[]
    for pi,words in enumerate(phrases):
        start=2.0+pi*7.5
        for i, word in enumerate(words):
            st=start+i*1.07; end=st+(0.86 if len(word)>2 else 0.55)
            notes.append(dict(start=round(st,3),end=round(end,3),pitch=pitches[pi][i],text=word,talkie=False,confidence=1.0,phrase=pi))
        sections.append(dict(start=round(start-.18,3),end=round(notes[-1]['end']+.18,3),index=pi))
    dur=34.0; rate=22050
    with wave.open(str(audio),'wb') as f:
        f.setnchannels(1);f.setsampwidth(2);f.setframerate(rate)
        block=[]
        for i in range(int(dur*rate)):
            t=i/rate; v=0.
            for note in notes:
                if note['start']<=t<=note['end']:
                    freq=440*2**((note['pitch']-69)/12)
                    env=min(1,(t-note['start'])*12,(note['end']-t)*12)
                    v+=.17*max(0,env)*math.sin(2*math.pi*freq*t)
                    break
            # restrained chord pad
            if t>1:
                v+=.025*math.sin(2*math.pi*130.81*t)+.02*math.sin(2*math.pi*196*t)
            block.append(struct.pack('<h',int(max(-1,min(1,v))*32767)))
            if len(block)>=4096:
                f.writeframesraw(b''.join(block));block=[]
        if block:f.writeframesraw(b''.join(block))
    jpath.write_text(json.dumps(dict(id='demo_neonstage',title='Uma Noite Neon',artist='NeonStage Originals',duration=dur,bpm=bpm,notes=notes,phrases=sections,source='demo',analysis='verified_demo'),ensure_ascii=False,indent=2),encoding='utf-8')

if SONGS.resolve() == (ROOT / 'songs').resolve():
    make_demo()
def read_song(path: Path):
    try:
        chart=json.loads((path/'chart.json').read_text(encoding='utf-8'))
        chart['ready']=True
        chart['audio_url']=f"/api/audio/{path.name}"
        try:
            from neon_next_backend import find_stems
            if find_stems(path):
                chart['mix_stems']={'vocals':f'/api/neon/stem/{path.name}/vocals','instrumental':f'/api/neon/stem/{path.name}/instrumental'}
        except Exception:pass
        return chart
    except Exception:return None

# NS_DEV_ROUTES_V1
@app.get('/placar')
@app.get('/inicio')
@app.get('/descobrir')
@app.get('/biblioteca')
@app.get('/multiplayer')
@app.get('/configuracoes')
def neon_pages():
    if request.remote_addr not in ('127.0.0.1','::1'):
        return redirect('/party')
    return app.send_static_file('index.html')

# NS_PARTY_FIX_CANTAR_ROUTE_V1
@app.get('/palco')
@app.get('/cantar')
def neonstage_cantar_page():
    if request.remote_addr not in ('127.0.0.1','::1'):
        return redirect('/party')
    return app.send_static_file('index.html')

@app.get('/')
def home():
    if request.remote_addr not in ('127.0.0.1','::1'):return redirect('/party')
    return app.send_static_file('index.html')

# NS_PARTY_STUDIO_ROUTE_V2
@app.get('/neonstage-party')
def neon_party_studio():
    if request.remote_addr not in ('127.0.0.1','::1'):
        return redirect('/party')
    return app.send_static_file('party_studio_next.html')

@app.get('/hostpanel')
def hostpanel():
    if request.remote_addr not in ('127.0.0.1','::1'):return ('Acesso local apenas',403)
    return app.send_static_file('host.html')

@app.get('/api/party/network')
def party_network():
    import socket
    sk=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    try:
        sk.connect(('192.0.2.1',80))
        ip=sk.getsockname()[0]
    except OSError:ip=socket.gethostbyname(socket.gethostname())
    finally:sk.close()
    return jsonify(ip=ip)

# NEON_LIBRARY_PHASE4_SERVER
@app.delete('/api/library/<song_id>')
def neon_library_delete(song_id):
    import shutil as _ns_shutil
    if request.remote_addr not in ('127.0.0.1', '::1'):
        return jsonify(error='Exclusao permitida apenas no computador.'),403
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', song_id):
        return jsonify(error='ID invalido.'),400
    if song_id=='demo_neonstage':
        return jsonify(error='A musica de demonstracao e protegida.'),403
    with LOCK:
        if any(j.get('song_id')==song_id or (j.get('song_id') is None and job_id==song_id) for job_id,j in JOBS.items() if j.get('progress',0)<100 and not j.get('error')):
            return jsonify(error='Esta musica ainda esta sendo preparada.'),409
    folder=(SONGS/song_id).resolve()
    if folder.parent != SONGS.resolve() or not folder.is_dir() or not (folder/'chart.json').is_file():
        return jsonify(error='Musica nao encontrada.'),404
    try:
        _ns_shutil.rmtree(folder)
    except OSError as e:
        return jsonify(error='Nao foi possivel excluir: '+str(e)),500
    return jsonify(ok=True, deleted=song_id)

# NS_STORAGE_FASE5_API
# NS_STORAGE_FASE53_SETTINGS
@app.get('/api/neon/storage')
def neon_storage_info():
    if request.remote_addr not in ('127.0.0.1', '::1'):
        return jsonify(error='Apenas no PC do servidor.'), 403
    saved = _ns_storage_selected()
    active = SONGS.resolve()
    return jsonify(path=str(active), selected=str(saved),
        default=str(_ns_storage_default_folder()),
        restart_required=saved != active)

# NS_STORAGE_FOLDER_PICKER_52
@app.post('/api/neon/storage/pick-folder')
def neon_storage_pick_folder():
    # This dialog may only be opened from the PC hosting NeonStage.
    if request.remote_addr not in ('127.0.0.1', '::1'):
        return jsonify(error='Abra Configuracoes no notebook que executa o NeonStage.'), 403
    origin = request.headers.get('Origin', '')
    if origin and origin != (request.scheme + '://' + request.host):
        return jsonify(error='Origem nao autorizada.'), 403
    if request.headers.get('X-NeonStage-Local') != '1':
        return jsonify(error='Solicitacao nao autorizada.'), 403
    if os.name != 'nt':
        return jsonify(error='Selecao de pasta disponivel somente no Windows.'), 501
    import base64 as _nsfp64
    import subprocess as _nsfpsub
    import sys as _nsfpsys
    import threading as _nsfpthr
    if not hasattr(neon_storage_pick_folder, '_lock'):
        neon_storage_pick_folder._lock = _nsfpthr.Lock()
    lock = neon_storage_pick_folder._lock
    if not lock.acquire(blocking=False):
        return jsonify(error='Uma janela de selecao ja esta aberta no Windows.'), 409
    try:
        data = request.get_json(silent=True) or {}
        current = str(data.get('current') or '')[:800]
        if not Path(current).is_dir():
            current = str(SONGS)
        parameter = _nsfp64.b64encode(current.encode('utf-8')).decode('ascii')
        helper = ROOT / '_neon_folder_dialog_v52.py'
        if not helper.is_file():
            return jsonify(error='Modulo do seletor nao encontrado. Reinstale a Fase 5.2.'), 500
        try:
            result = _nsfpsub.run(
                [_nsfpsys.executable, str(helper), parameter],
                stdout=_nsfpsub.PIPE, stderr=_nsfpsub.PIPE,
                timeout=210,
                creationflags=getattr(_nsfpsub, 'CREATE_NO_WINDOW', 0)
            )
        except _nsfpsub.TimeoutExpired:
            return jsonify(error='Selecao expirou. Verifique se a janela abriu atras do navegador.'), 504
        except OSError as exc:
            return jsonify(error='Nao foi possivel iniciar seletor: '+str(exc)[:180]), 500
        for line in result.stdout.decode('ascii', errors='ignore').splitlines():
            line=line.strip()
            if line=='NS_CANCEL':
                return jsonify(ok=True, cancelled=True)
            if line.startswith('NS_PATH:'):
                try:
                    path=_nsfp64.b64decode(line[8:],validate=True).decode('utf-8')
                    if Path(path).is_dir():
                        return jsonify(ok=True, path=path, cancelled=False)
                except (ValueError,UnicodeError,OSError):
                    pass
            if line.startswith('NS_ERR:'):
                try:
                    detail=_nsfp64.b64decode(line[7:],validate=True).decode('utf-8')
                except (ValueError,UnicodeError):
                    detail='Erro ao abrir janela nativa.'
                return jsonify(error='Falha ao abrir pasta: '+detail[:520]), 500
        # Expose a useful error, rather than a generic Windows Forms message.
        stderr=result.stderr.decode('utf-8',errors='replace').strip()
        return jsonify(error=('Falha no seletor: '+stderr[:400]) if stderr else 'Janela nao retornou uma pasta. Verifique outras janelas abertas.'), 500
    finally:
        lock.release()

# NS_STORAGE_FASE53_SAVE_WITHOUT_COPY
@app.post('/api/neon/storage')
def neon_storage_change():
    if request.remote_addr not in ('127.0.0.1', '::1'):
        return jsonify(error='Apenas no PC do servidor.'), 403
    origin = request.headers.get('Origin', '')
    if origin and origin != (request.scheme + '://' + request.host):
        return jsonify(error='Origem nao autorizada.'), 403
    if request.headers.get('X-NeonStage-Local') != '1':
        return jsonify(error='Requisicao local nao autorizada.'), 403
    with LOCK:
        if any(j.get('progress', 0) < 100 and not j.get('error') for j in JOBS.values()):
            return jsonify(error='Aguarde concluir o preparo das musicas.'), 409
    params = request.get_json(silent=True) or {}
    is_default = params.get('restore_default') is True
    requested = str(_ns_storage_default_folder()) if is_default else str(params.get('path') or '').strip()
    if not requested or len(requested) > 550:
        return jsonify(error='Escolha uma pasta valida.'), 400
    try:
        dest = Path(os.path.expandvars(requested)).expanduser()
        if not dest.is_absolute():
            return jsonify(error='Escolha o caminho completo da pasta.'), 400
        dest = dest.resolve(strict=False)
        legacy = SONGS.resolve()
        # Keep the current legacy location usable, but reject selecting a new
        # directory within the application or selecting a drive root.
        if dest != legacy and (dest == ROOT or dest in ROOT.parents or ROOT in dest.parents):
            return jsonify(error='Escolha uma pasta fora do diretorio do programa.'), 400
        if dest == Path(dest.anchor):
            return jsonify(error='Escolha uma pasta dentro do disco, nao a raiz.'), 400
        dest.mkdir(parents=True, exist_ok=True)
        if not dest.is_dir():
            return jsonify(error='O caminho escolhido nao e uma pasta.'), 400
        import tempfile as _ns_tempfile
        with _ns_tempfile.TemporaryFile(dir=str(dest)) as test:
            test.write(b'OK')
            test.flush()
        path = ROOT / 'neon_storage.json'
        temp = path.with_name('neon_storage.json.pending')
        payload = _ns_storage_json.dumps({'songs_path': str(dest)}, ensure_ascii=False, indent=2)
        try:
            temp.write_text(payload, encoding='utf-8')
            temp.replace(path)
        finally:
            temp.unlink(missing_ok=True)
        return jsonify(ok=True, path=str(dest),
            restart_required=(dest != legacy),
            copied=0, restored_default=is_default)
    except (OSError, ValueError, PermissionError) as exc:
        return jsonify(error=str(exc)[:400]), 400

@app.get('/api/library')
def library():
    songs=[x for p in SONGS.iterdir() if p.is_dir() if (x:=read_song(p))]
    return jsonify(songs)

@app.get('/api/audio/<song_id>')
def song_audio(song_id):
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',song_id):return ('Invalid ID',400)
    d=SONGS/song_id
    for ext in ('mp3','wav','m4a','ogg'):
        if (d/f'audio.{ext}').exists():return send_from_directory(d,f'audio.{ext}',conditional=True)
    return ('Audio not found',404)

@app.get('/api/song/<song_id>')
def get_song(song_id):
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',song_id):return ('Invalid ID',400)
    try:
        known=read_song(SONGS/song_id)
        if known and not known.get('lyric_lines') and SONGS.resolve()==(ROOT/'songs').resolve():
            from neon_preplay_lyrics import process as _overlay_lyrics
            _overlay_lyrics(ROOT,song_id)
    except Exception as _overlay_error:
        app.logger.warning('Genius preplay: %s',_overlay_error)
    v=read_song(SONGS/song_id)
    resp=jsonify(v) if v else ('Not found',404)
    if v: resp.headers['Cache-Control']='no-store'
    return resp

@app.get('/api/search')
def search():
    query=request.args.get('q','').strip()[:120]
    if len(query)<2:return jsonify([])
    try:
        import yt_dlp
        opts={'quiet':True,'no_warnings':True,'extract_flat':True,'skip_download':True,'socket_timeout':12,'ignoreerrors':True,'noplaylist':True,'default_search':'ytsearch'}
        with yt_dlp.YoutubeDL(opts) as ydl:
            data=ydl.extract_info('ytsearch8:'+query,download=False)
        results=[]
        for item in (data or {}).get('entries',[]):
            if not item or not item.get('id'):continue
            vid=item['id']
            results.append(dict(id=vid,title=item.get('title') or 'Sem título',artist=item.get('channel') or item.get('uploader') or 'YouTube',duration=item.get('duration'),image=f'https://i.ytimg.com/vi/{vid}/hqdefault.jpg',url=f'https://www.youtube.com/watch?v={vid}'))
        return jsonify(results)
    except Exception as exc:
        return jsonify(error='Não foi possível buscar no YouTube. Verifique conexão/yt-dlp: '+str(exc)[:180]),503


def run_job(job_id, video_id, title, artist):
    dest=SONGS / job_id
    dest.mkdir(exist_ok=True)
    try:
        status(job_id,'Baixando áudio da versão escolhida',8)
        import yt_dlp
        options={'format':'bestaudio/best','outtmpl':str(dest/'source.%(ext)s'),'noplaylist':True,'quiet':True,'no_warnings':True,'socket_timeout':25,'retries':2,'postprocessors':[{'key':'FFmpegExtractAudio','preferredcodec':'mp3','preferredquality':'192'}]}
        # V8.2: tentar audio prioritario e, se YouTube retornar 403,
        # repetir via cliente Android, aceitando MP4 progressivo (format 18).
        video_url=f'https://www.youtube.com/watch?v={video_id}'
        candidates=[options, {**options,
            'format':'18/best[ext=mp4]/best',
            'extractor_args':{'youtube':{'player_client':['android']}},
            'retries':2}]
        download_errors=[]
        for attempt, opts in enumerate(candidates,1):
            if (dest/'source.mp3').exists(): break
            for partial in dest.glob('source.*'):
                if partial.is_file(): partial.unlink()
            try:
                print(f'NeonStage download tentativa {attempt}/{len(candidates)}', flush=True)
                with yt_dlp.YoutubeDL(opts) as ydl:
                    ydl.download([video_url])
                if not (dest/'source.mp3').exists():
                    raise RuntimeError('yt-dlp terminou sem gerar source.mp3')
            except Exception as exc:
                download_errors.append(str(exc))
                if attempt == len(candidates):
                    raise RuntimeError('Falha no download automatico. '+ ' | '.join(download_errors)) from exc
        src=dest/'source.mp3'
        if not src.exists():raise RuntimeError('Download de áudio indisponível para este vídeo')
        src.rename(dest/'audio.mp3')
        status(job_id,'Separando voz e analisando afinação',30)
        target=dest/'chart.json'
        ai_py=os.getenv('NEONSTAGE_AI_PYTHON',sys.executable)
        cmd=[ai_py,str(ROOT/'analyze.py'),str(dest/'audio.mp3'),str(target),title,artist]
        proc=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace',bufsize=1)
        lines=[]
        for line in proc.stdout:
            line=line.strip();lines.append(line)
            if len(lines)>40:lines.pop(0)
            if line.startswith('STAGE:'):
                status(job_id,line[6:].strip(),max(33,min(90,JOBS.get(job_id,{}).get('progress',33)+12)))
        code=proc.wait()
        if code or not target.exists():raise RuntimeError('Falha na análise: '+' | '.join(lines[-6:])[-650:])
        chart=json.loads(target.read_text(encoding='utf-8'))
        chart.update(id=job_id,title=title,artist=artist,source='youtube', image=f'https://i.ytimg.com/vi/{video_id}/hqdefault.jpg', video_id=video_id)
        target.write_text(json.dumps(chart,ensure_ascii=False,indent=2),encoding='utf-8')
        status(job_id,'Pronto para cantar!',100,song_id=job_id)
    except Exception as exc:
        status(job_id,'Falha ao preparar',0,error=str(exc)[:650])

@app.post('/api/prepare')
def prepare():
    data=request.get_json(silent=True) or {}
    vid=str(data.get('id',''))
    if not re.fullmatch(r'[\w-]{11}',vid):return jsonify(error='ID de vídeo inválido.'),400
    job_id='music_'+uuid.uuid4().hex[:14]
    title=str(data.get('title','Música'))[:160];artist=str(data.get('artist','Artista'))[:120]
    status(job_id,'Na fila',2)
    POOL.submit(run_job,job_id,vid,title,artist)
    return jsonify(job_id=job_id)

@app.get('/api/job/<job_id>')
def job(job_id):
    with LOCK: j=JOBS.get(job_id)
    return jsonify(j) if j else ('Not found',404)

@app.post('/api/import')
def import_local():
    """Import a personal MP3/WAV audio file, then analyze in background."""
    file=request.files.get('file')
    if not file:return jsonify(error='Selecione um arquivo'),400
    extension=Path(file.filename or '').suffix.lower()
    if extension not in ('.mp3','.wav','.m4a','.ogg','.flac'):
        return jsonify(error='Formato não suportado'),400
    file.stream.seek(0,2);size=file.stream.tell();file.stream.seek(0)
    if size>120*1024*1024:return jsonify(error='Arquivo acima de 120 MB'),413
    ident='music_'+uuid.uuid4().hex[:14]; d=SONGS/ident;d.mkdir()
    local=d/('entrada'+extension)
    file.save(local)
    title=(request.form.get('title') or Path(file.filename).stem)[:160]
    artist=(request.form.get('artist') or 'Arquivo local')[:120]
    status(ident,'Na fila',2)
    def local_job():
        try:
            status(ident,'Convertendo áudio local',15)
            cmd=['ffmpeg','-nostdin','-y','-hide_banner','-loglevel','error','-i',str(local),'-vn','-codec:a','libmp3lame','-b:a','192k',str(d/'audio.mp3')]
            r=subprocess.run(cmd,capture_output=True,text=True)
            if r.returncode:raise RuntimeError(r.stderr[-350:])
            status(ident,'Analisando voz e melodia',35)
            ai_py=os.getenv('NEONSTAGE_AI_PYTHON',sys.executable)
            r=subprocess.run([ai_py,str(ROOT/'analyze.py'),str(d/'audio.mp3'),str(d/'chart.json'),title,artist],capture_output=True,text=True,encoding='utf-8',errors='replace')
            if r.returncode:raise RuntimeError((r.stdout+' '+r.stderr)[-700:])
            chart=json.loads((d/'chart.json').read_text(encoding='utf-8'))
            chart.update(id=ident,title=title,artist=artist,source='local')
            (d/'chart.json').write_text(json.dumps(chart,ensure_ascii=False,indent=2),encoding='utf-8')
            status(ident,'Pronto para cantar!',100,song_id=ident)
        except Exception as e:status(ident,'Falha ao preparar',0,error=str(e)[:650])
    POOL.submit(local_job)
    return jsonify(job_id=ident)

from neon_next_backend import register as register_neon_next
register_neon_next(app, SONGS, JOBS, POOL, LOCK)
from party_next import register as register_party
register_party(app, ROOT, SONGS, JOBS, POOL, run_job)
from neon10_server import register as register_neon10
register_neon10(app, ROOT)

# NS14_SYNC_LAB_REGISTER
from neon_sync_v2 import register as register_sync_v2
register_sync_v2(app, SONGS)

# SHOWTIME V8.24 local video integration
from showtime_video_v824 import register as _register_showtime_video
_register_showtime_video(app, SONGS)

# SHOWTIME V8.26 local video integration
from showtime_video_v826 import register as _register_showtime_video_v826
_register_showtime_video_v826(app, SONGS)

if __name__=='__main__':
    import webbrowser
    print('NeonStage no endereço http://127.0.0.1:8765')
    if os.getenv('NEONSTAGE_NO_BROWSER')!='1':
        threading.Timer(1.2,lambda:webbrowser.open('http://127.0.0.1:8765/inicio')).start()
    app.run(host='0.0.0.0',port=8765,debug=False,threaded=True)
