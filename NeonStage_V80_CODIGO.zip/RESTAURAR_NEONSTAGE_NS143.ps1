$ErrorActionPreference = 'Stop'
# Feche o servidor antes de executar.
$root = 'C:\Users\freit\Downloads\NeonStage_V80'
$backup = 'C:\Users\freit\Downloads\NeonStage_V80\BACKUP_ANTES_NS143_20261012_195145_970716'
if (!(Test-Path -LiteralPath $backup)) { throw 'Backup NS14.3 nao encontrado.' }
Copy-Item -LiteralPath (Join-Path $backup 'neon_sync_v2.py') -Destination (Join-Path $root 'neon_sync_v2.py') -Force
Remove-Item -LiteralPath (Join-Path $root 'neon_sync_visual.py') -Force -ErrorAction SilentlyContinue
Copy-Item -LiteralPath (Join-Path $backup 'static\sync14.js') -Destination (Join-Path $root 'static\sync14.js') -Force
Copy-Item -LiteralPath (Join-Path $backup 'static\sync14.html') -Destination (Join-Path $root 'static\sync14.html') -Force
Copy-Item -LiteralPath (Join-Path $backup 'static\sync14.css') -Destination (Join-Path $root 'static\sync14.css') -Force
Remove-Item -LiteralPath (Join-Path $root 'CONFIGURAR_NEONSTAGE_OCR_NS143.ps1') -Force -ErrorAction SilentlyContinue
Write-Host 'NS14.2 restaurada. Reinicie o servidor.' -ForegroundColor Green
