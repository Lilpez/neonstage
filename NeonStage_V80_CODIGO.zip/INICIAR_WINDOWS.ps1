$ErrorActionPreference='Stop'
Set-Location $PSScriptRoot
$py=Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (!(Test-Path $py)) { throw 'Execute INSTALAR_WINDOWS.ps1 antes.' }
& $py app.py
