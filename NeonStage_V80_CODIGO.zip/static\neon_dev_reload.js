﻿(() => {
    "use strict";

    if (window.__NEON_DEV_RELOAD__) return;
    window.__NEON_DEV_RELOAD__ = true;

    if (!["localhost", "127.0.0.1"].includes(
        location.hostname
    )) return;

    const endpoint = "http://127.0.0.1:8766/status";
    let baseline = null;
    let pending = false;
    let busy = false;

    function inGame() {
        const game = document.getElementById("gameScreen");
        const legacyStage = document.getElementById("ns828Stage");

        if (legacyStage) return true;

        return !!(
            game &&
            !game.classList.contains("hidden") &&
            getComputedStyle(game).display !== "none"
        );
    }

    function showPending() {
        if (document.getElementById("neon-dev-notice")) return;

        const box = document.createElement("div");
        box.id = "neon-dev-notice";
        box.textContent =
            "Atualizacao pronta — sera aplicada ao sair da musica";

        Object.assign(box.style, {
            position: "fixed",
            right: "18px",
            bottom: "65px",
            zIndex: "2147483647",
            padding: "12px 18px",
            borderRadius: "12px",
            background: "#151327",
            color: "#ffffff",
            border: "1px solid #ae72e8",
            boxShadow: "0 8px 30px #0008",
            font: "600 13px system-ui",
            pointerEvents: "none"
        });

        document.body.appendChild(box);
    }

    async function check() {
        if (busy) return;
        busy = true;

        try {
            const response = await fetch(endpoint, {
                cache: "no-store"
            });

            if (!response.ok) return;

            const data = await response.json();
            if (!data.ok || !data.revision) return;

            if (baseline === null) {
                baseline = data.revision;
                return;
            }

            if (data.revision !== baseline) {
                pending = true;
            }

            if (pending) {
                if (inGame()) {
                    showPending();
                } else {
                    location.reload();
                }
            }
        } catch (err) {
            // O NeonStage continua funcionando
            // mesmo sem o monitor de desenvolvimento.
        } finally {
            busy = false;
        }
    }

    setInterval(check, 1200);
    check();

    console.info("[NeonStage] Dev Mode ativado");
})();
