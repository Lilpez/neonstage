﻿(function () {
  if (window.__nsNoteSmoothingHotfixApplied) return;
  window.__nsNoteSmoothingHotfixApplied = true;

  const proto = CanvasRenderingContext2D && CanvasRenderingContext2D.prototype;
  if (!proto) return;

  const originalFillRect = proto.fillRect;
  const originalStrokeRect = proto.strokeRect;

  function roundRectPath(ctx, x, y, w, h, r) {
    r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
  }

  function normalizeColor(v) {
    try { return String(v || "").toLowerCase(); }
    catch { return ""; }
  }

  function looksLikePitchLaneCanvas(ctx) {
    const c = ctx && ctx.canvas;
    if (!c) return false;

    const w = c.width || 0;
    const h = c.height || 0;

    return (
      w >= 900 &&
      h >= 80 &&
      h <= 260
    );
  }

  function looksLikeNoteColor(fillStyle) {
    const c = normalizeColor(fillStyle);

    return (
      c.includes("00e5ff") ||
      c.includes("00d8ff") ||
      c.includes("00cfff") ||
      c.includes("33ddff") ||
      c.includes("55e6ff") ||
      c.includes("66e6ff") ||
      c.includes("6fe8ff") ||
      c.includes("8befff") ||
      c.includes("cyan") ||
      c.includes("deepskyblue") ||
      c.includes("rgb(0,") ||
      c.includes("rgba(0,")
    );
  }

  function shouldSmoothNote(ctx, x, y, w, h) {
    if (!looksLikePitchLaneCanvas(ctx)) return false;

    if (!(w >= 12 && h >= 4 && h <= 24)) return false;

    const fill = normalizeColor(ctx.fillStyle);

    if (looksLikeNoteColor(fill)) return true;

    return false;
  }

  function drawSmoothNote(ctx, x, y, w, h) {
    const radius = Math.max(2, Math.min(h / 2, 10));

    ctx.save();
    ctx.globalCompositeOperation = "source-over";

    // glow externo
    ctx.shadowColor = "rgba(78, 225, 255, 0.95)";
    ctx.shadowBlur = Math.max(10, h * 1.8);

    // corpo principal com gradiente
    const g = ctx.createLinearGradient(x, y, x, y + h);
    g.addColorStop(0.00, "rgba(184, 248, 255, 0.98)");
    g.addColorStop(0.18, "rgba(145, 239, 255, 0.98)");
    g.addColorStop(0.52, "rgba(71, 222, 255, 0.96)");
    g.addColorStop(1.00, "rgba(28, 180, 247, 0.94)");

    roundRectPath(ctx, x, y, w, h, radius);
    ctx.fillStyle = g;
    ctx.fill();

    // brilho superior interno
    ctx.shadowBlur = 0;
    const topGlowHeight = Math.max(2, Math.min(h * 0.34, h - 1));
    const g2 = ctx.createLinearGradient(x, y, x, y + topGlowHeight);
    g2.addColorStop(0, "rgba(255,255,255,0.42)");
    g2.addColorStop(1, "rgba(255,255,255,0.05)");

    roundRectPath(ctx, x + 1, y + 1, Math.max(2, w - 2), topGlowHeight, Math.max(1, radius - 1));
    ctx.fillStyle = g2;
    ctx.fill();

    // núcleo levemente mais claro para dar volume
    const innerH = Math.max(2, h - 4);
    const innerY = y + 2;
    const g3 = ctx.createLinearGradient(x, innerY, x, innerY + innerH);
    g3.addColorStop(0, "rgba(120, 240, 255, 0.22)");
    g3.addColorStop(1, "rgba(0, 0, 0, 0.00)");

    roundRectPath(ctx, x + 2, innerY, Math.max(2, w - 4), innerH, Math.max(1, radius - 2));
    ctx.fillStyle = g3;
    ctx.fill();

    ctx.restore();
  }

  proto.fillRect = function (x, y, w, h) {
    try {
      if (shouldSmoothNote(this, x, y, w, h)) {
        drawSmoothNote(this, x, y, w, h);
        return;
      }
    } catch (e) {
      // cai no desenho padrao
    }
    return originalFillRect.call(this, x, y, w, h);
  };

  proto.strokeRect = function (x, y, w, h) {
    try {
      if (shouldSmoothNote(this, x, y, w, h)) {
        // evita borda quadrada sobre a nota suavizada
        return;
      }
    } catch (e) {
      // cai no desenho padrao
    }
    return originalStrokeRect.call(this, x, y, w, h);
  };

  console.log("[NeonStage] Hotfix de suavizacao de notas ativo.");
})();
