﻿$ErrorActionPreference = 'Stop'
$root = Join-Path $env:USERPROFILE 'Downloads\NeonStage_V80'
$backupDir = 'C:\Users\freit\Downloads\NeonStage_V80\BACKUP_NS143_OCR_FIX_20261012_195607'
Copy-Item -LiteralPath (Join-Path $backupDir 'CONFIGURAR_NEONSTAGE_OCR_NS143.ps1') -Destination (Join-Path $root 'CONFIGURAR_NEONSTAGE_OCR_NS143.ps1') -Force
Write-Host 'Configurador antigo restaurado.'
