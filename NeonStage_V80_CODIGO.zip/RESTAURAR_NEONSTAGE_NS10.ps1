$ErrorActionPreference = "Stop"
$root = "C:\Users\freit\Downloads\NeonStage_V80"
$backup = "C:\Users\freit\Downloads\NeonStage_V80\BACKUP_ANTES_NS10_20261012_172757_761304"
if (!(Test-Path $backup)) { throw "Backup NS10 nao encontrado." }
Copy-Item -LiteralPath (Join-Path $backup "app.py") -Destination (Join-Path $root "app.py") -Force
Copy-Item -LiteralPath (Join-Path $backup "party_next.py") -Destination (Join-Path $root "party_next.py") -Force
Copy-Item -LiteralPath (Join-Path $backup "static\app.js") -Destination (Join-Path $root "static\app.js") -Force
Copy-Item -LiteralPath (Join-Path $backup "static\index.html") -Destination (Join-Path $root "static\index.html") -Force
Copy-Item -LiteralPath (Join-Path $backup "static\stage832.js") -Destination (Join-Path $root "static\stage832.js") -Force
Copy-Item -LiteralPath (Join-Path $backup "static\neon_next.js") -Destination (Join-Path $root "static\neon_next.js") -Force
Copy-Item -LiteralPath (Join-Path $backup "static\party_next.js") -Destination (Join-Path $root "static\party_next.js") -Force
Copy-Item -LiteralPath (Join-Path $backup "static\neon_party_pc_bridge.js") -Destination (Join-Path $root "static\neon_party_pc_bridge.js") -Force
Copy-Item -LiteralPath (Join-Path $backup "static\neon_party_auto5_pc.js") -Destination (Join-Path $root "static\neon_party_auto5_pc.js") -Force
Remove-Item -LiteralPath (Join-Path $root "neon10_server.py") -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath (Join-Path $root "static\neon10.js") -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath (Join-Path $root "static\neon10.css") -Force -ErrorAction SilentlyContinue
Write-Host "NS9 restaurada. Reinicie o servidor." -ForegroundColor Green
