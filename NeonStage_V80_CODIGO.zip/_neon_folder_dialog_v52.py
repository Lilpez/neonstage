# NeonStage local Windows directory selection - Phase 5.2.
# Executed as a child process so Tk has its own UI thread.
import base64
import os
import sys
import shutil
import subprocess
from pathlib import Path

def emit(tag, value=None):
    if value is None:
        print(tag, flush=True)
    else:
        payload=base64.b64encode(str(value).encode('utf-8')).decode('ascii')
        print(tag+payload, flush=True)

if os.name != 'nt':
    emit('NS_ERR:', 'O seletor so funciona no Windows.')
    raise SystemExit(2)

try:
    initial=base64.b64decode(sys.argv[1],validate=True).decode('utf-8')
except (IndexError,ValueError,UnicodeError):
    initial=str(Path.home())
if not Path(initial).is_dir():
    initial=str(Path.home())

errors=[]
# Tkinter uses Windows' native directory-selection UI.
try:
    import tkinter as tk
    from tkinter import filedialog
    root=tk.Tk()
    root.withdraw()
    root.attributes('-topmost', True)
    root.update()
    try:
        selected=filedialog.askdirectory(
            parent=root,
            initialdir=initial,
            title='NeonStage - selecione uma pasta',
            mustexist=True
        )
    finally:
        root.destroy()
    if selected:
        emit('NS_PATH:', selected)
    else:
        emit('NS_CANCEL')
    raise SystemExit(0)
except SystemExit:
    raise
except Exception as exc:
    errors.append('Tkinter: '+str(exc))

# Fallback for Windows Python installations without tkinter.
try:
    executable=shutil.which('powershell.exe')
    if not executable:
        systemroot=os.environ.get('SystemRoot',r'C:\Windows')
        executable=str(Path(systemroot)/'System32'/'WindowsPowerShell'/'v1.0'/'powershell.exe')
    ps=r'''
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Application]::EnableVisualStyles()
$dialog = New-Object System.Windows.Forms.FolderBrowserDialog
$dialog.Description = 'NeonStage - selecione uma pasta'
$dialog.ShowNewFolderButton = $true
$dialog.RootFolder = [System.Environment+SpecialFolder]::Desktop
$original = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('__B64__'))
if ([IO.Directory]::Exists($original)) { $dialog.SelectedPath = $original }
try {
    $result = $dialog.ShowDialog()
    if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
        $value = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($dialog.SelectedPath))
        [Console]::WriteLine('NS_PATH:'+$value)
    } else {
        [Console]::WriteLine('NS_CANCEL')
    }
} finally {
    $dialog.Dispose()
}
'''
    ps=ps.replace('__B64__',base64.b64encode(initial.encode('utf-8')).decode('ascii'))
    command=base64.b64encode(ps.encode('utf-16le')).decode('ascii')
    p=subprocess.run(
        [executable,'-NoProfile','-STA','-EncodedCommand',command],
        stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180,
        creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0)
    )
    output=p.stdout.decode('utf-8',errors='replace')
    for line in output.splitlines():
        line=line.strip()
        if line.startswith('NS_PATH:') or line=='NS_CANCEL':
            print(line,flush=True)
            raise SystemExit(0)
    errors.append('Windows Forms: '+p.stderr.decode(errors='replace')[-350:])
except SystemExit:
    raise
except Exception as exc:
    errors.append('Windows Forms: '+str(exc))

emit('NS_ERR:', ' | '.join(errors)[:750])
raise SystemExit(2)
