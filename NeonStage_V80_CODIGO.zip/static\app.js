
/* NS_FIRST_VALID_LYRIC_GATE */
function nsFirstValidLyricTime(chart) {
    const lines = chart?.lyric_lines || [];
    const starts = lines
        .filter(line => String(line.text || "").trim())
        .map(line => Number(line.at ?? line.start))
        .filter(Number.isFinite);

    if (starts.length) return Math.min(...starts);

    const notes = chart?.notes || [];
    const noteStarts = notes
        .map(n => Number(n.start))
        .filter(Number.isFinite);

    return noteStarts.length
        ? Math.min(...noteStarts)
        : 0;
}

'use strict';
const $=id=>document.getElementById(id);
const state={partyActive:false,partySong:null,partyLastPing:0,library:[],results:[],selected:null,players:[],chart:null,frame:0,playing:false,lastFrame:0,lastScore:0,lastNote:-1,job:null,jobTimer:null,ctx:null,instances:[],scores:[],totalSample:0};
function toast(msg){let el=$('toast');el.textContent=msg;el.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.remove('show'),4500)}
function safe(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function duration(s){if(!Number.isFinite(+s))return '—';return Math.floor(s/60)+':'+String(Math.floor(s%60)).padStart(2,'0')}
function modal(id,show){$(id).classList.toggle('hidden',!show)}
function navigate(page){document.querySelectorAll('.navbtn').forEach(b=>b.classList.toggle('active',b.dataset.nav===page));$('crumb').textContent=({home:'INÍCIO',search:'DESCOBRIR',library:'BIBLIOTECA',multiplayer:'MULTIPLAYER'})[page];if(page==='home')document.querySelector('.scroller').scrollTo({top:0,behavior:'smooth'});else $(page==='search'?'searchSection':page==='multiplayer'?'multiplayerSection':'librarySection').scrollIntoView({behavior:'smooth',block:'start'})}
async function api(path,options){let r=await fetch(path,options);let obj=await r.json().catch(()=>({error:'Resposta inválida do servidor'}));if(!r.ok)throw Error(obj.error||'Erro de rede');return obj}
async function refreshLibrary(){try{state.library=await api('/api/library');renderLibrary()}catch(e){toast(e.message)}}
function renderLibrary(){const grid=$('libraryGrid');if(!state.library.length){grid.innerHTML='<p class="search-hint">Ainda não há músicas. Escolha uma versão ou importe seu áudio.</p>';return}grid.innerHTML=state.library.map((s,i)=>`<div class="album" data-song="${safe(s.id)}"><div class="album-art"><span>${i%3===0?'♫':i%3===1?'♬':'✦'}</span><div class="album-play">▶</div></div><b title="${safe(s.title)}">${safe(s.title)}</b><small>${safe(s.artist)} · ${duration(s.duration)}</small></div>`).join('');grid.querySelectorAll('.album').forEach(el=>el.onclick=()=>selectSong(state.library.find(s=>s.id===el.dataset.song)))}
let debounce;
async function search(){const q=$('searchInput').value.trim();if(q.length<2){toast('Digite o nome da música ou artista');return}const container=$('searchResults');container.innerHTML='<div class="search-hint">Buscando versões disponíveis...</div>';try{state.results=await api('/api/search?q='+encodeURIComponent(q));if(!state.results.length){container.innerHTML='<div class="search-hint">Nenhuma versão encontrada. Tente outro título ou importe um arquivo.</div>';return}container.innerHTML=state.results.map((v,i)=>`<div class="result"><img alt="" loading="lazy" src="${safe(v.image)}"><div class="result-body"><strong title="${safe(v.title)}">${safe(v.title)}</strong><small>${safe(v.artist)} · ${duration(v.duration)}</small></div><button aria-label="Preparar música" data-index="${i}">＋</button></div>`).join('');container.querySelectorAll('button').forEach(el=>el.onclick=()=>prepareResult(state.results[Number(el.dataset.index)]))}catch(err){container.innerHTML=`<div class="search-hint">${safe(err.message)}</div>`}}
async function prepareResult(item){if(!confirm('Preparar esta gravação para karaoke?\n\n'+item.title+'\n\nA análise por IA pode levar alguns minutos. Use apenas gravações autorizadas.'))return;try{const {job_id}=await api('/api/prepare',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(item)});monitorJob(job_id)}catch(e){toast(e.message)}}
function monitorJob(id){state.job=id;modal('processingOverlay',true);$('processTitle').textContent='Preparando seu palco';$('processStage').textContent='Na fila...';$('processFill').style.width='1%';$('processPercent').textContent='1%';clearInterval(state.jobTimer);state.jobTimer=setInterval(async()=>{try{const info=await api('/api/job/'+id);$('processStage').textContent=info.stage;$('processFill').style.width=info.progress+'%';$('processPercent').textContent=info.progress+'%';if(info.error){clearInterval(state.jobTimer);$('processStage').textContent='Erro: '+info.error;$('processTitle').textContent='Não foi possível preparar';return}if(info.song_id){clearInterval(state.jobTimer);modal('processingOverlay',false);await refreshLibrary();selectSong(state.library.find(s=>s.id===info.song_id))}}catch(e){clearInterval(state.jobTimer);toast(e.message)}},1400)}
function selectSong(song){if(!song)return;state.selected=song;$('setupSong').textContent=song.title;$('setupArtist').textContent=song.artist;$('name1').value=localStorage.getItem('neon_player1')||'Player 1';$('name2').value=localStorage.getItem('neon_player2')||'Player 2';$('duetToggle').checked=false;toggleDuet();$('setupError').textContent='';modal('setupOverlay',true);loadMics()}
function toggleDuet(){const on=$('duetToggle').checked;$('name2').disabled=!on;$('mic2').disabled=!on;$('player2Config').style.opacity=on?'1':'.55'}
async function loadMics(){try{const devices=await navigator.mediaDevices.enumerateDevices();let mics=devices.filter(d=>d.kind==='audioinput');for(let key of ['mic1','mic2']){let old=$(key).value;$(key).innerHTML='<option value="">Microfone padrão</option>'+mics.map((d,i)=>`<option value="${safe(d.deviceId)}">${safe(d.label||'Microfone '+(i+1))}</option>`).join('');if([...$(key).options].some(o=>o.value===old))$(key).value=old}}catch(e){console.warn(e)}}
// Time-domain autocorrelation, with noise gate and clarity estimate.
function findPitch(buffer,sampleRate){const n=buffer.length;let energy=0;for(let i=0;i<n;i++)energy+=buffer[i]*buffer[i];const rms=Math.sqrt(energy/n);if(rms<.012)return {midi:null,rms,confidence:0};const minlag=Math.max(2,Math.floor(sampleRate/1000)),maxlag=Math.min(n-1,Math.floor(sampleRate/65));let bestLag=0,best=-Infinity;for(let lag=minlag;lag<=maxlag;lag++){let corr=0,e1=0,e2=0;for(let i=0;i<n-lag;i+=2){const a=buffer[i],b=buffer[i+lag];corr+=a*b;e1+=a*a;e2+=b*b}const normalized=corr/Math.sqrt(e1*e2+1e-10);if(normalized>best){best=normalized;bestLag=lag}}if(best<.65||bestLag===0)return{midi:null,rms,confidence:best};let freq=sampleRate/bestLag;const midi=69+12*Math.log2(freq/440);return{midi,rms,confidence:best}}
async function initializeMicrophones(){await cleanupMics();const ctx=new (window.AudioContext||window.webkitAudioContext)();state.ctx=ctx;await ctx.resume();let configs=[{name:$('name1').value.trim()||'Player 1',id:$('mic1').value,color:'#ef59bb'}];if($('duetToggle').checked)configs.push({name:$('name2').value.trim()||'Player 2',id:$('mic2').value,color:'#37dbdc'});let players=[];for(let p of configs){let stream=await navigator.mediaDevices.getUserMedia({audio:{deviceId:p.id?{exact:p.id}:undefined,echoCancellation:false,noiseSuppression:false,autoGainControl:false},video:false});let source=ctx.createMediaStreamSource(stream),analyser=ctx.createAnalyser();analyser.fftSize=2048;analyser.smoothingTimeConstant=0;source.connect(analyser);players.push({...p,stream,source,analyser,buffer:new Float32Array(analyser.fftSize),score:0,combo:0,hits:0,attempts:0,mid:null,confidence:0,rms:0})}state.players=players;localStorage.setItem('neon_player1',configs[0].name);if(configs[1])localStorage.setItem('neon_player2',configs[1].name);await loadMics()}
async function cleanupMics(){for(const p of state.players){try{p.source.disconnect();p.stream.getTracks().forEach(t=>t.stop())}catch{}}state.players=[];if(state.ctx){try{await state.ctx.close()}catch{}state.ctx=null}}
async function beginSong(){const song=state.selected;if(!song)return;const err=$('setupError');err.textContent='';try{await initializeMicrophones();state.chart=await api('/api/song/'+song.id);const audio=$('gameAudio');audio.pause();audio.src=state.chart.mix_stems?.instrumental || state.chart.audio_url;audio.currentTime=0;await new Promise((resolve,reject)=>{if(audio.readyState>=1)return resolve();audio.onloadedmetadata=resolve;audio.onerror=()=>reject(Error('Falha ao carregar o áudio'))});state.players.forEach(p=>{p.score=0;p.combo=0;p.hits=0;p.attempts=0});state.lastScore=0;state.lastFrame=0;state.lastNote=-1;state.playing=true;modal('setupOverlay',false);$('gameScreen').classList.remove('hidden');$('gameSong').textContent=song.title;$('gameArtist').textContent=song.artist;$('timeTotal').textContent=duration(audio.duration);$('p1label').textContent=state.players[0].name.toUpperCase();$('p2score').style.visibility=state.players.length===2?'visible':'hidden';if(state.players[1])$('p2label').textContent=state.players[1].name.toUpperCase();refreshScore();await audio.play();cancelAnimationFrame(state.frame);state.frame=requestAnimationFrame(renderFrame)}catch(e){err.textContent='Não foi possível iniciar: '+e.message;await cleanupMics()}}
function refreshScore(){state.players.forEach((p,i)=>{const idx=i+1;$('score'+idx).textContent=Math.round(p.score).toLocaleString('pt-BR');$('combo'+idx).textContent=p.combo+' COMBO';$('scoreBar'+idx).style.width=Math.min(100,p.combo*5)+'%';$('feedback'+idx).textContent=p.feedback||'CANTANDO'})}
function scoreFrame(t,delta){const chart=state.chart;if(!chart)return;const notes=chart.notes.filter(n=>Number(n.start)>=nsFirstValidLyricTime(chart)-0.02);const currentIndex=notes.findIndex(n=>t>=n.start && t<=n.end);const target=notes[currentIndex];for(let p of state.players){p.analyser.getFloatTimeDomainData(p.buffer);let det=findPitch(p.buffer,state.ctx.sampleRate);p.mid=det.midi;p.confidence=det.confidence;p.rms=det.rms;if(!target||delta<=0||delta>.16)continue;const accuracy=target.talkie?(det.rms>.023?.82:0):(det.midi==null?0:Math.max(0,1-(Math.min(Math.abs(det.midi-(target.pitch+(Number(window.NEON_TRANSPOSE?.()||0))))%12,12-(Math.abs(det.midi-(target.pitch+(Number(window.NEON_TRANSPOSE?.()||0))))%12)) / 2.5)));p.score+=accuracy*delta*240;p.attempts+=delta;if(accuracy>.56)p.hits+=delta;p.feedback=accuracy>.88?'PERFEITO ✦':accuracy>.65?'ÓTIMO!':accuracy>.32?'BOM':'AJUSTE A VOZ';}
if(currentIndex!==state.lastNote){if(state.lastNote>=0){for(let p of state.players){if(p.attempts>.02){const ratio=p.hits/p.attempts;p.combo=ratio>.56?p.combo+1:0}p.attempts=0;p.hits=0}}state.lastNote=currentIndex}}
function getPhrase(t){const phrases=state.chart.phrases||[];return phrases.findIndex(p=>t>=p.start&&t<=p.end)}
function renderLyrics(t){
 const chart=state.chart||{}, raw=Array.isArray(chart.lyric_lines)?chart.lyric_lines:[];
 const lines=raw.filter(x=>String(x.text||'').trim()&&!/^(\[|.* lyrics(?:\[|$)|letra de |contributors|read more)/i.test(String(x.text||'').trim()))
   .map(x=>({at:Number(x.at??x.start??0),text:String(x.text||'').trim()})).sort((a,b)=>a.at-b.at);
 if(lines.length){
  let i=-1;for(let j=0;j<lines.length;j++){if(lines[j].at<=t+.04)i=j;else break}
  $('lyricPrevious').textContent=i>0?lines[i-1].text:'';
  $('lyricCurrent').textContent=i>=0?lines[i].text:'INTRODUÇÃO';
  $('lyricNext').textContent=lines[i+1]?.text||'';
  $('phraseCounter').textContent=i<0?'INTRODUÇÃO':`VERSO ${i+1} / ${lines.length}`;
 }else if(chart.source==='demo'){
  const notes=chart.notes||[], phrases=chart.phrases||[];let i=getPhrase(t);if(i<0)i=phrases.findIndex(p=>p.start>t);
  if(i<0)i=phrases.length-1;
  const line=p=>notes.filter(n=>n.phrase===p).map(n=>n.text||'').join(' ');
  $('lyricPrevious').textContent=i>0?line(i-1):'';
  $('lyricCurrent').textContent=i>=0?line(i):'INTRODUÇÃO';
  $('lyricNext').textContent=i+1<phrases.length?line(i+1):'';
  $('phraseCounter').textContent=`FRASE ${Math.max(1,i+1)} / ${phrases.length}`;
 }else{
  $('lyricPrevious').textContent='';$('lyricCurrent').textContent='LETRA NÃO DISPONÍVEL';
  $('lyricNext').textContent='A música e a pontuação continuam disponíveis.';
  $('phraseCounter').textContent='MODO FESTA';
 }
 const pitch=state.players[0]?.mid;
 const labels=['Dó','Dó♯','Ré','Ré♯','Mi','Fá','Fá♯','Sol','Sol♯','Lá','Lá♯','Si'];
 $('pitchLabel').textContent=pitch==null?'CANTE PARA DETECTAR SUA VOZ':`AFINAÇÃO · ${labels[((Math.round(pitch)%12)+12)%12]} · OITAVAS LIVRES`;
}
function renderFrame(now){if(!state.playing)return;const audio=$('gameAudio');const t=audio.currentTime,delta=state.lastFrame?Math.min(.14,Math.max(0,(now-state.lastFrame)/1000)):0;state.lastFrame=now;if(!audio.paused&&!audio.ended)scoreFrame(t,delta);renderLyrics(t);$('timeElapsed').textContent=duration(t);$('timelineFill').style.width=(100*t/(audio.duration||state.chart.duration||1))+'%';if(now-state.lastScore>200){refreshScore();state.lastScore=now}if(state.partyActive && now-state.partyLastPing>900){state.partyLastPing=now;api('/api/party/control',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'heartbeat',time:t,playing:!audio.paused,score:Math.round(state.players[0]?.score||0),live_scores:window.NEON_DUET?.live?.()||[]})}).catch(()=>{})}state.frame=requestAnimationFrame(renderFrame)}
async function stopGame(){state.playing=false;cancelAnimationFrame(state.frame);$('gameAudio').pause();$('gameScreen').classList.add('hidden');await cleanupMics()}
async function finishGame(){if(!state.playing)return;const partyScore=state.partyActive?Math.round(state.players[0]?.score||0):null;const scores=state.players.map(p=>({name:p.name,score:Math.round(p.score)}));const existing=JSON.parse(localStorage.getItem('neon_records')||'{}');const id=state.chart.id;existing[id]=Math.max(existing[id]||0,...scores.map(s=>s.score));localStorage.setItem('neon_records',JSON.stringify(existing));if(!state.partyActive){fetch('/api/neon10/score',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:state.players?.[0]?.name||'Convidado',points:Math.round(state.players?.[0]?.score||0),song_id:state.chart?.id,profile_id:localStorage.getItem('neon10_profile_id')||'local-pc'})}).catch(()=>{})}$('finishSong').textContent=state.chart.title;$('finishScores').innerHTML=scores.map((p,i)=>`<div class="finish-item"><small>${safe(p.name)}</small><b>${p.score.toLocaleString('pt-BR')}</b><span>${i===0?'✦ VOCALISTA':'✧ VOCALISTA'}</span></div>`).join('');await stopGame();modal('finishOverlay',true);if(partyScore!==null){state.partyActive=false;try{await api('/api/party/control',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'complete',score:partyScore,score_split:window.NEON_DUET?.split?.()||null})});parent.postMessage({type:'neon-party-complete'},location.origin)}catch(e){toast(e.message)}}}
function setupEvents(){document.querySelectorAll('.navbtn').forEach(b=>b.onclick=()=>navigate(b.dataset.nav));$('heroSearch').onclick=()=>navigate('search');$('heroDemo').onclick=()=>selectSong(state.library.find(s=>s.id==='demo_neonstage'));$('refreshLibrary').onclick=refreshLibrary;$('searchButton').onclick=search;$('searchInput').onkeydown=e=>{if(e.key==='Enter')search()};$('duetToggle').onchange=toggleDuet;$('startGame').onclick=beginSong;$('exitGame').onclick=stopGame;$('pauseGame').onclick=()=>{const a=$('gameAudio');if(a.paused){a.play();$('pauseGame').textContent='Ⅱ'}else{a.pause();$('pauseGame').textContent='▶'}};$('restartGame').onclick=()=>{let a=$('gameAudio');a.currentTime=0;state.players.forEach(p=>{p.score=0;p.combo=0;p.hits=0;p.attempts=0});state.lastFrame=0;state.lastNote=-1;refreshScore();a.play()};$('fullGame').onclick=()=>{if(document.fullscreenElement)document.exitFullscreen();else $('gameScreen').requestFullscreen?.()};$('gameAudio').onended=finishGame;$('finishHome').onclick=()=>modal('finishOverlay',false);$('finishReplay').onclick=()=>{modal('finishOverlay',false);selectSong(state.selected)};document.querySelectorAll('[data-close]').forEach(el=>el.onclick=()=>modal(el.dataset.close,false));$('processClose').onclick=()=>{modal('processingOverlay',false);toast('A preparação continuará em segundo plano enquanto o servidor estiver aberto.')};$('timeline').onclick=e=>{const a=$('gameAudio'),rect=$('timeline').getBoundingClientRect();if(Number.isFinite(a.duration))a.currentTime=a.duration*Math.max(0,Math.min(1,(e.clientX-rect.left)/rect.width))};$('importButton').onclick=()=>$('fileInput').click();$('fileInput').onchange=async e=>{const f=e.target.files[0];if(!f)return;let data=new FormData;data.append('file',f);data.append('title',f.name.replace(/\.[^.]+$/,''));try{let r=await api('/api/import',{method:'POST',body:data});monitorJob(r.job_id)}catch(err){toast(err.message)}e.target.value=''};$('profileButton').onclick=()=>toast('Seu perfil é configurado em “Prepare seu palco”, ao iniciar uma música.');}
setupEvents();refreshLibrary();

// Party bridge: session controller on the notebook reuses the original scoring engine.
window.NEON_PARTY={
  async begin(songId,playerName){
    let song=await api('/api/song/'+encodeURIComponent(songId));
    state.partyActive=true;
    state.partyLastPing=0;
    state.partySong=songId;
    state.selected=song;
    $('name1').value=playerName;
    $('duetToggle').checked=false;
    toggleDuet();
    $('setupError').textContent='';
    await loadMics();
    await beginSong();
    if(!state.playing){state.partyActive=false;throw Error($('setupError').textContent||'Microfone indisponível')}
  },
  async stop(){state.partyActive=false;await stopGame()},
  isPlaying(){return state.playing}
};

// Global preparation screen on the notebook; no overlay during the song itself.
(function(){
  const el=document.getElementById('partyLoadingScreen');
  document.getElementById('partyLoadingOpen').onclick=()=>navigate('multiplayer');
  async function update(){
    try {
      const r=await fetch('/api/party/state',{cache:'no-store'});
      if(!r.ok)return;
      const s=await r.json();
      el.classList.toggle('hidden',s.phase!=='preparing');
      if(s.phase==='preparing'){
        const pct=Math.max(0,Math.min(100,Number(s.preparation_percent)||0));
        document.getElementById('partyLoadingNumber').textContent=pct+'%';
        document.getElementById('partyLoadingBar').style.width=pct+'%';
        document.getElementById('partyLoadingCount').textContent=(s.preparation_ready||0)+' de '+(s.preparation_total||0)+' gravações prontas';
        const error=s.queue?.find(x=>x.job?.error);
        document.getElementById('partyLoadingStage').textContent=error ? 'Uma música falhou: '+error.title+'. Abra Multiplayer para tentar novamente.' : 'Analisando áudio, letra e afinação para a festa';
      }
    }catch(e){}
  }
  setInterval(update,1000);update();
})();

/* NeonStage V8.20: read-only gamification on top of existing scoring. */
(function(){
'use strict';
if(window.__neonGameV820)return;window.__neonGameV820=true;
const CSS=`#ng820Hud{position:absolute;z-index:70;top:70px;right:22px;pointer-events:none;display:flex;flex-direction:column;gap:9px;align-items:flex-end;font-family:inherit} .ng820card{background:rgba(11,12,29,.85);backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,.15);border-radius:15px;padding:9px 15px;color:white;box-shadow:0 9px 35px #0006;min-width:170px} .ng820name{font-size:11px;letter-spacing:.09em;opacity:.8} .ng820level{font-weight:900;font-size:19px} .ng820track{width:170px;height:6px;border-radius:9px;background:#ffffff2b;margin-top:6px;overflow:hidden}.ng820progress{height:100%;width:0;background:linear-gradient(90deg,#5de1fb,#ff62c7);transition:width .25s} #ng820Pop{position:absolute;z-index:80;left:50%;top:28%;transform:translateX(-50%);color:#fff;font-size:clamp(24px,3.4vw,54px);font-weight:900;text-shadow:0 4px 22px #e843b9;pointer-events:none;opacity:0;transition:opacity .15s,transform .2s;white-space:nowrap} #ng820Pop.show{opacity:1;transform:translate(-50%,-15px)}.ng820Spark{position:absolute;z-index:79;left:50%;top:38%;height:8px;width:8px;border-radius:50%;background:var(--c,#ff78da);pointer-events:none;animation:ng820burst .65s ease-out forwards}@keyframes ng820burst{to{transform:translate(var(--dx),var(--dy)) scale(.3);opacity:0}}@media(max-width:650px){#ng820Hud{top:66px;right:8px}.ng820card{min-width:112px;padding:7px 9px}.ng820track{width:110px}.ng820level{font-size:15px}#ng820Pop{top:23%;font-size:27px}}@media(prefers-reduced-motion:reduce){.ng820Spark{display:none}#ng820Pop{transition:none}}`;
let root,css,pop,timer=0,ledger=[],lastId=-1,seekGuard=false;
const levels=[0,100,260,520,880,1350,2000,2850,3900,5200];
function mount(){root=document.getElementById('gameScreen');if(!root)return;css=document.getElementById('ng820Style');if(!css){css=document.createElement('style');css.id='ng820Style';css.textContent=CSS;document.head.appendChild(css)}if(getComputedStyle(root).position==='static')root.style.position='relative';let hud=document.getElementById('ng820Hud');if(!hud){hud=document.createElement('div');hud.id='ng820Hud';root.appendChild(hud)}pop=document.getElementById('ng820Pop');if(!pop){pop=document.createElement('div');pop.id='ng820Pop';root.appendChild(pop)}hud.replaceChildren();ledger=state.players.map((p,i)=>({xp:0,streak:0,best:0,perfect:0,great:0,good:0,miss:0,achievement:new Set(),element:null}));ledger.forEach((l,i)=>{let card=document.createElement('div');card.className='ng820card';card.innerHTML='<div class="ng820name"></div><div class="ng820level"></div><div class="ng820track"><div class="ng820progress"></div></div>';card.querySelector('.ng820name').textContent=state.players[i]?.name||('Jogador '+(i+1));hud.appendChild(card);l.element=card});lastId=-1;update()}
function update(){ledger.forEach(l=>{if(!l.element)return;let lv=1;while(lv<levels.length&&l.xp>=levels[lv])lv++;let base=levels[lv-1]||0,upper=levels[lv]||base+1600;let progress=Math.min(100,(l.xp-base)/(upper-base)*100);l.element.querySelector('.ng820level').textContent='NV '+lv+' · '+l.streak+'x COMBO';l.element.querySelector('.ng820progress').style.width=progress+'%'})}
function flash(s,burst=false){if(!pop)return;pop.textContent=s;pop.classList.add('show');clearTimeout(timer);timer=setTimeout(()=>pop?.classList.remove('show'),850);if(burst&&!matchMedia('(prefers-reduced-motion: reduce)').matches){for(let i=0;i<12;i++){let node=document.createElement('i');node.className='ng820Spark';let angle=i*Math.PI/6;node.style.setProperty('--dx',Math.round(Math.cos(angle)*130)+'px');node.style.setProperty('--dy',Math.round(Math.sin(angle)*90)+'px');node.style.setProperty('--c',i%2?'#79f9ec':'#ff69d1');root.appendChild(node);node.addEventListener('animationend',()=>node.remove(),{once:true})}}}
function outcome(p,i){let l=ledger[i];if(!l)return;let ratio=p.attempts>.045?p.hits/p.attempts:-1;if(ratio<0)return;let grade=ratio>=.9?'PERFEITO':ratio>=.74?'EXCELENTE':ratio>=.56?'BOM':'ERROU';let xp=ratio>=.9?40:ratio>=.74?26:ratio>=.56?12:0;l.xp+=xp;if(xp){l.streak++;l.best=Math.max(l.best,l.streak);if(ratio>=.9)l.perfect++;else if(ratio>=.74)l.great++;else l.good++}else{l.streak=0;l.miss++}let reward='';for(const [n,tag] of [[5,'PRIMEIRO COMBO'],[10,'EM CHAMAS'],[20,'ESTRELA DO PALCO'],[35,'LENDÁRIO']])if(l.streak===n&&!l.achievement.has(tag)){l.achievement.add(tag);l.xp+=n*4;reward=tag}if(reward)flash('✦ '+reward+' ✦',true);else if(xp&&l.streak%8===0)flash(grade+' · '+l.streak+' COMBO',true);else if(ratio>=.9)flash('PERFEITO ✦');update()}
function tally(){return ledger.map((l,i)=>({name:state.players[i]?.name||'Jogador',xp:l.xp,best:l.best,perfect:l.perfect,great:l.great,good:l.good,miss:l.miss,achievements:[...l.achievement]}))}
// Existing scoreFrame owns audio pitch, score and combo. Observe its transition without changing it.
const originalScore=scoreFrame;scoreFrame=function(t,delta){const old=state.lastNote, snaps=state.players.map(p=>({attempts:p.attempts,hits:p.hits}));originalScore(t,delta);if(old>=0&&state.lastNote!==old){snaps.forEach((p,i)=>outcome(p,i))}};
const originalBegin=beginSong;beginSong=async function(){await originalBegin.apply(this,arguments);if(state.playing&&state.chart)mount()};
const originalFinish=finishGame;finishGame=async function(){const result=tally();await originalFinish.apply(this,arguments);let scores=document.getElementById('finishScores');if(scores&&result.length){const extra=document.createElement('div');extra.style.cssText='margin-top:16px;display:grid;gap:10px';for(let r of result){let entry=document.createElement('div');entry.className='ng820card';entry.textContent=r.name+' · +'+r.xp+' XP · '+r.best+'x melhor combo · '+r.perfect+' perfeitos · '+r.achievements.join(', ');extra.appendChild(entry)}scores.appendChild(extra)}};
const originalStop=stopGame;stopGame=async function(){await originalStop.apply(this,arguments);if(pop)pop.classList.remove('show')};
const restart=document.getElementById('restartGame');if(restart)restart.addEventListener('click',()=>{if(state.playing)mount()});
})();
