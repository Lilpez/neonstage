(()=>{
'use strict';
if(window.__NS_LIBRARY_PHASE4__)return;window.__NS_LIBRARY_PHASE4__=true;
const grid=document.getElementById('libraryGrid');if(!grid)return;
let running=false;
function getSongs(){try{return state.library||[]}catch{return []}}
function attach(){
 if(running)return;running=true;
 try{
   const songs=getSongs();
   for(const card of grid.querySelectorAll('.album[data-song]')){
     const id=card.dataset.song;
     if(!id||card.querySelector('.ns-lib-del'))continue;
     const song=songs.find(x=>x.id===id);if(!song)continue;
     card.classList.add('ns-lib-card');
     const art=card.querySelector('.album-art');
     const thumb=song.image||song.thumbnail||song.thumb||(song.video_id&&/^[\w-]{11}$/.test(song.video_id)?'https://i.ytimg.com/vi/'+song.video_id+'/hqdefault.jpg':'');
     if(art&&thumb&&/^https?:\/\//i.test(thumb)){
       const img=document.createElement('img');img.className='ns-lib-cover';img.alt='Capa de '+song.title;img.loading='lazy';img.referrerPolicy='no-referrer';img.src=thumb;
       img.onerror=()=>img.remove();art.prepend(img);
     }
     if(id==='demo_neonstage')continue;
     const btn=document.createElement('button');btn.type='button';btn.className='ns-lib-del';btn.textContent='Excluir';btn.title='Apagar esta musica do NeonStage';
     btn.onclick=async(ev)=>{
       ev.preventDefault();ev.stopPropagation();
       if(!confirm('Excluir "'+song.title+'"? Todos os arquivos desta musica serao apagados do PC. Esta acao nao pode ser desfeita.'))return;
       btn.disabled=true;btn.textContent='Excluindo...';
       try{
         const response=await fetch('/api/library/'+encodeURIComponent(id),{method:'DELETE'});
         const data=await response.json();if(!response.ok)throw Error(data.error||'Erro ao excluir');
         if(window.state&&window.state.selected?.id===id)window.state.selected=null;
         if(typeof refreshLibrary==='function')await refreshLibrary();else location.reload();
       }catch(e){alert('Nao foi possivel excluir: '+e.message);btn.disabled=false;btn.textContent='Excluir';}
     };
     card.appendChild(btn);
   }
 }finally{running=false;}
}
new MutationObserver(()=>attach()).observe(grid,{childList:true});
attach();
})();