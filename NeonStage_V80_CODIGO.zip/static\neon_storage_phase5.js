(()=>{
'use strict';
if(window.__NS_STORAGE_53__)return;
window.__NS_STORAGE_53__=true;
const mount=()=>{
 const slot=document.querySelector('#settingsSection #nsDevStorage');
 if(!slot)return;
 const card=slot.closest('.ns-dev-card');if(!card)return;
 const existing=card.querySelector('#nsStoragePicker');if(existing)existing.remove();
 const hint=card.querySelector('.search-hint');
 if(hint)hint.textContent='Escolha a pasta onde as proximas musicas ficarao salvas. Nao copia nem remove musicas de outras pastas.';
 const box=document.createElement('div');box.id='nsStoragePicker';
 const label=document.createElement('label');label.htmlFor='nsStorageFolder';label.textContent='Local das musicas';
 const field=document.createElement('input');field.type='text';field.id='nsStorageFolder';field.spellcheck=false;field.placeholder='Escolha uma pasta no computador';
 const actions=document.createElement('div');actions.className='ns-storage-actions';
 const button=(id,title,cls)=>{const b=document.createElement('button');b.type='button';b.id=id;b.textContent=title;b.className=cls;actions.appendChild(b);return b};
 const browse=button('nsStorageBrowse','Procurar pasta...','ghost');
 const save=button('nsStorageSave','Salvar','primary');
 const reset=button('nsStorageDefault','Restaurar local padrao','ghost');
 const info=document.createElement('p');info.id='nsStorageMessage';info.setAttribute('role','status');
 const note=document.createElement('p');note.className='ns-storage-note';
 note.textContent='Uma pasta nova comeca vazia. As musicas da pasta anterior continuam la; para ve-las novamente, selecione aquela pasta.';
 box.append(label,field,actions,info,note);card.appendChild(box);
 let activePath='',savedPath='',defaultPath='';
 const status=(s,isError=false)=>{info.textContent=s;info.dataset.error=isError?'1':'0'};
 const load=async()=>{
  const r=await fetch('/api/neon/storage',{cache:'no-store'});const d=await r.json();
  if(!r.ok)throw Error(d.error||'Nao foi possivel ler o armazenamento.');
  activePath=d.path||'';savedPath=d.selected||activePath;defaultPath=d.default||'';
  field.value=savedPath;slot.textContent='Pasta ativa: '+activePath;
  if(d.restart_required)status('Alteracao salva. Reinicie o NeonStage para ativar a pasta selecionada.');
  else status('Armazenamento pronto.');
 };
 const commit=async(restore=false)=>{
  save.disabled=reset.disabled=browse.disabled=true;
  status('Salvando o local escolhido...');
  try{
   const r=await fetch('/api/neon/storage',{
    method:'POST',headers:{'Content-Type':'application/json','X-NeonStage-Local':'1'},
    body:JSON.stringify(restore?{restore_default:true}:{path:field.value})
   });
   const d=await r.json();if(!r.ok)throw Error(d.error||'Falha ao salvar.');
   savedPath=d.path;field.value=savedPath;
   if(d.restart_required)status('Local salvo. Reinicie o NeonStage para utilizar esta pasta. Nenhuma musica foi copiada.');
   else status('Local ja esta ativo. Nenhuma musica foi copiada.');
  }catch(e){status('Erro ao salvar: '+e.message,true)}
  finally{save.disabled=reset.disabled=browse.disabled=false}
 };
 browse.onclick=async()=>{
  browse.disabled=true;status('Escolha a pasta na janela do Windows.');
  try{
   const r=await fetch('/api/neon/storage/pick-folder',{
    method:'POST',headers:{'Content-Type':'application/json','X-NeonStage-Local':'1'},
    body:JSON.stringify({current:field.value})
   });
   const d=await r.json();if(!r.ok)throw Error(d.error||'Falha ao abrir o explorador.');
   if(d.cancelled){status('Selecao cancelada.');return}
   if(!d.path)throw Error('O seletor nao retornou uma pasta.');
   field.value=d.path;status('Pasta escolhida. Clique em Salvar para ativar.');
  }catch(e){status('Erro ao escolher pasta: '+e.message,true)}
  finally{browse.disabled=false}
 };
 save.onclick=()=>commit(false);
 reset.onclick=()=>{
  if(!defaultPath){status('Nao foi possivel identificar Documentos.',true);return}
  field.value=defaultPath;commit(true);
 };
 load().catch(e=>status('Erro: '+e.message,true));
};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount);else mount();
})();
