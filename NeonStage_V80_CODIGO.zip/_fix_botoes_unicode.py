from pathlib import Path
import re
import shutil
import datetime

root = Path(__file__).resolve().parent
js = root / "static" / "stage832.js"

if not js.exists():
    raise SystemExit("ERRO: stage832.js nao encontrado.")

source = js.read_text(encoding="utf-8")

buttons = {
    "ns828Back": "\\u2190",
    "ns828Pause": "\\u2161",
    "ns828Restart": "\\u21bb",
}

updated = source

for element_id, symbol in buttons.items():
    pattern = (
        r'(<button\\s+id="' + re.escape(element_id) +
        r'"[^>]*>).*?(</button>)'
    )

    updated, count = re.subn(
        pattern,
        lambda m: m.group(1) + symbol + m.group(2),
        updated,
        count=1,
        flags=re.S
    )

    if count != 1:
        raise SystemExit(
            "ERRO: botao nao encontrado: " + element_id
        )

# Corrigir tambem o simbolo que muda ao pausar.
pattern = r"(\$\('ns828Pause'\)\.textContent\s*=\s*a\.paused\s*\?).*?;"
updated, count = re.subn(
    pattern,
    lambda m: m.group(1) +
              "'\\u25b6':'\\u2161';",
    updated,
    count=1
)

if count != 1:
    raise SystemExit("ERRO: controle de pausa nao encontrado.")

# Validar bloco antes de alterar arquivo.
backup = root / (
    "stage832_unicode_backup_" +
    datetime.datetime.now().strftime("%Y%m%d_%H%M%S") +
    ".js"
)

shutil.copy2(js, backup)
js.write_text(updated, encoding="utf-8")

print("BOTOES CORRIGIDOS")
print("Voltar: U+2190")
print("Pausar: U+2161")
print("Reiniciar: U+21BB")
print("Backup:", backup)
