"""V8.18 preplay wrapper: run pre-existing V8.17 pipeline, then regroup presentation."""
import importlib.util
from pathlib import Path

def process(root,song_id,force=False):
    root=Path(root)
    previous=root/'neon_preplay_v817_backup.py'
    if not previous.exists():return {'state':'missing_v817_engine'}
    spec=importlib.util.spec_from_file_location('_v817_preplay',str(previous))
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    prior=mod.process(root,song_id,force=force)
    # Only regroup after pipeline completes; reuse existing chart if prior reports cache.
    if isinstance(prior,dict) and prior.get('state') not in ('done',):return prior
    from neon_v818_group import regroup
    group=regroup(root,song_id,force=False)
    return {'state':'done','previous':prior,'grouping':group}
