/* NeonStage V8.29 - isolated stage with Rock Band inspired crowd meter */
(()=>{
'use strict';
if(window.__NS_STAGE829__)return;window.__NS_STAGE829__=true;
const $=id=>document.getElementById(id),clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
let root=null,canvas=null,ctx=null,video=null,uid='',lines=[],lastIndex=-99, raf=0,lastFrame=0,videoTimer=0,lastNote=-1;
let streak=0,good=0,awarded=0,pastNote=null,anchorBase=60,rangeLow=45,rangeHigh=81;
let progressEl,scoreEl,comboEl,ratioEl,topLeft=null;
let crowd=100,lastCrowdTime=null,failPending=false,failed=false,failOverlay=null,prevMeterNote=-1,hitIndicatorAt=0;
let leadMs=0,lastDrawError=false;
const targetGame=$('gameScreen');if(!targetGame)return;
const getEngine=()=>{try{return state}catch{return null}};
const frameSong=()=>getEngine()?.chart||null;
const audio=()=> $('gameAudio');
const visualLines=chart=>((chart?.lyric_lines)||[]).filter(x=>String(x.text||'').trim()).map(x=>({at:Number(x.at??x.start??0),text:String(x.text).trim()})).sort((a,b)=>a.at-b.at);
const fmt=n=>Math.round(n||0).toLocaleString('pt-BR');
function cleanOverlay(){
 if(raf){cancelAnimationFrame(raf);raf=0;}if(videoTimer){clearInterval(videoTimer);videoTimer=0;}
 if(video){video.pause();video.removeAttribute('src');video.load();video=null;}
 targetGame.classList.remove('ns828-active');
 root?.remove();root=null;canvas=null;ctx=null;uid='';lastIndex=-99;failed=false;failPending=false;
}
function isStagePlaying(){const s=getEngine();return Boolean(s?.playing&&s?.chart&&!targetGame.classList.contains('hidden')&&audio()?.src);}
function fit(){if(!canvas||!root)return;const dpr=Math.min(devicePixelRatio||1,2),r=canvas.getBoundingClientRect();let w=Math.max(1,Math.round(r.width*dpr)),h=Math.max(1,Math.round(r.height*dpr));if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;ctx.setTransform(dpr,0,0,dpr,0,0);}}
function mount(){
 const s=getEngine(),ch=s?.chart;if(!ch)return;
 cleanOverlay(); uid=ch.id||s.selected?.id||'song';lines=visualLines(ch);lastIndex=-99;lastNote=-1;streak=0;good=0;awarded=0;crowd=100;lastCrowdTime=null;failed=false;failPending=false;prevMeterNote=-1;lastDrawError=false;
 const pitches=(ch.notes||[]).filter(n=>!n.talkie&&Number.isFinite(n.pitch)).map(n=>n.pitch).sort((a,b)=>a-b);
 if(pitches.length){const p=(q)=>pitches[Math.min(pitches.length-1,Math.floor(q*(pitches.length-1)))];const mid=p(.5);rangeLow=Math.floor((p(.06)-4)/6)*6;rangeHigh=Math.ceil((p(.94)+4)/6)*6;if(rangeHigh-rangeLow<18){rangeLow=mid-12;rangeHigh=mid+12;}anchorBase=mid;}
 targetGame.classList.add('ns828-active');
 root=document.createElement('div');root.id='ns828Stage';
 root.innerHTML=`<div class="ns828-bg"><div class="ns828-gradient"></div><video class="ns828-video" muted playsinline preload="metadata"></video><div class="ns828-vignette"></div></div>
 <div class="ns828-topline"><div class="ns828-stage-tag">✦ NEONSTAGE <b>LIVE</b></div><div class="ns828-track-title"></div><div class="ns828-controls"><button id="ns828Back" type="button" title="Sair">←</button><button id="ns828Pause" type="button" title="Pausar">Ⅱ</button><button id="ns828Restart" type="button" title="Recomeçar">↺</button></div></div>
 <section class="ns828-highway"><canvas id="ns828Canvas"></canvas><div class="ns828-fadeleft"></div><div class="ns828-faderight"></div><div class="ns828-highway-caption">ACERTE O TOM <span>✦</span> MANTENHA A MULTIDÃO</div></section>
 <aside class="ns828-left"><div class="ns828-crowd-title">MULTIDÃO</div><div id="ns828Pname"></div><div class="ns828-vertical"><div id="ns828Level"></div><div class="ns828-danger"></div></div><div class="ns828-combo" id="ns828Combo">x1</div><div id="ns828MeterLabel">100%</div></aside>
 <aside class="ns828-right"><div class="ns828-points" id="ns828Points">0</div><div class="ns828-stars" id="ns828Stars">☆☆☆☆☆</div><div class="ns828-accuracy" id="ns828Accuracy">CANTE PARA GANHAR ESTRELAS</div></aside>
 <div class="ns828-centerlyrics" id="ns828Lyrics"><div class="ns828-sideverse" id="ns828Prev"></div><div class="ns828-mainverse" id="ns828Current"><span class="ns828-white"></span></div><div class="ns828-sideverse" id="ns828Next"></div></div>
 <div class="ns828-burst" id="ns828Burst"></div>
 <div class="ns829-fail-overlay hidden" id="ns829Fail"><div class="ns829-fail-box"><div class="ns829-fail-kicker">O SHOW ACABOU</div><h2>A multidão foi embora</h2><p>Você ficou sem energia. Tente novamente e mantenha o ritmo!</p><div class="ns829-fail-actions"><button type="button" id="ns829Retry">↻ TENTAR NOVAMENTE</button><button type="button" id="ns829Exit">SAIR DO PALCO</button></div></div></div>
 <footer class="ns828-bottom"><span id="ns828Time">0:00</span><div class="ns828-timebar"><i id="ns828Progress"></i></div><span id="ns828Total">0:00</span><div id="ns828Status">● MICROFONE PRONTO</div></footer>`;
 targetGame.appendChild(root);
 const rawTitle=String(ch.title||'');const rawArtist=String(ch.artist||'');
 root.querySelector('.ns828-track-title').textContent=(rawTitle.toLowerCase().startsWith(rawArtist.toLowerCase()+' - ') ? rawTitle : [rawArtist,rawTitle].filter(Boolean).join(' — '));
 root.querySelector('#ns828Pname').textContent=(s.players?.[0]?.name||'PLAYER 1').toUpperCase();
 canvas=$('ns828Canvas');ctx=canvas.getContext('2d');video=root.querySelector('video');
 progressEl=$('ns828Progress');scoreEl=$('ns828Points');comboEl=$('ns828Combo');ratioEl=$('ns828Accuracy');
 $('ns828Back').onclick=()=>$('exitGame')?.click(); $('ns828Pause').onclick=()=>$('pauseGame')?.click(); $('ns828Restart').onclick=()=>$('restartGame')?.click();
 $('ns829Retry').onclick=()=>{ $('ns829Fail')?.classList.add('hidden'); $('restartGame')?.click(); };
 $('ns829Exit').onclick=()=>{ $('ns829Fail')?.classList.add('hidden'); $('exitGame')?.click(); };
 setupVideo(uid);raf=requestAnimationFrame(render);
}
function setupVideo(id){
 if(!id||!video)return;
 const v=video;let attempts=0,done=false;
 async function poll(){if(!root||done)return;try{const r=await fetch('/api/showtime/video/'+encodeURIComponent(id),{cache:'no-store'});if(!r.ok)return;const j=await r.json();if(j.ready&&j.url){done=true;v.src=j.url;v.addEventListener('loadedmetadata',syncVideo,{once:true});syncVideo();return;}if(j.state==='error'){done=true;return;}}catch{}if(++attempts>=85)done=true;}
 fetch('/api/showtime/video/'+encodeURIComponent(id),{method:'POST'}).catch(()=>{}).finally(()=>poll());
 videoTimer=setInterval(()=>{if(!root)return;if(!done)poll();syncVideo();},1800);
}
function syncVideo(){if(!video?.src)return;const a=audio();if(!a)return;try{if(video.readyState>=1&&Math.abs(video.currentTime-a.currentTime)>.4)video.currentTime=a.currentTime;if(a.paused){video.pause();}else if(video.paused)video.play().catch(()=>{});}catch{}}
function getIndex(t){let lo=0,hi=lines.length-1,best=-1;while(lo<=hi){const mid=(lo+hi)>>1;if(lines[mid].at<=t+.12){best=mid;lo=mid+1;}else hi=mid-1;}return best;}
function lyricUpdate(t){const idx=getIndex(t);if(idx!==lastIndex){lastIndex=idx;const line=idx>=0?lines[idx].text:'INTRODUÇÃO';const display=$('ns828Current');display.classList.remove('ns828-enter');void display.offsetWidth;display.classList.add('ns828-enter');display.querySelector('.ns828-white').textContent=line;$('ns828Prev').textContent=idx>0?lines[idx-1].text:'';$('ns828Next').textContent=lines[idx+1]?.text||'';}

}
function syllables(token){
 const punctuation=token.match(/[.,!?;:]+$/)?.[0]||'';const word=punctuation?token.slice(0,-punctuation.length):token;
 if(word.length<5)return[word+punctuation];const vowels=/[aeiouáéíóúâêôãõà]/i;
 let out=[],carry='';for(let i=0;i<word.length;i++){carry+=word[i];if(i>=word.length-2)continue;const a=word[i],b=word[i+1],c=word[i+2];if(vowels.test(a)&&!vowels.test(b)&&vowels.test(c)&&!/[rlh]/i.test(b)){out.push(carry+'-');carry='';}}
 if(carry)out.push(carry+punctuation);return out.length?out:[word+punctuation];
}
function formatTime(t){if(!Number.isFinite(t))return'0:00';return Math.floor(t/60)+':'+String(Math.floor(t%60)).padStart(2,'0');}
function draw(t){
 if(!ctx||!canvas)return;
 // Always size the canvas to the actual visible highway, independently of legacy style rules.
 const box=canvas.getBoundingClientRect();
 const cw=Math.max(10,box.width||root?.querySelector('.ns828-highway')?.clientWidth||900);
 const ch=Math.max(10,box.height||root?.querySelector('.ns828-highway')?.clientHeight||170);
 const dpr=Math.min(window.devicePixelRatio||1,2);
 const bw=Math.round(cw*dpr),bh=Math.round(ch*dpr);
 if(canvas.width!==bw||canvas.height!==bh){canvas.width=bw;canvas.height=bh;}
 const g=ctx,W=cw,H=ch;
 g.setTransform(dpr,0,0,dpr,0,0);g.clearRect(0,0,W,H);
 g.fillStyle='rgba(4,10,25,.65)';g.fillRect(0,0,W,H);
 const yTop=17,yBottom=Math.max(45,H-29),lanes=8;
 for(let k=0;k<=lanes;k++){
   const y=yTop+(yBottom-yTop)*k/lanes;
   g.beginPath();g.strokeStyle=k===4?'rgba(255,109,202,.65)':'rgba(131,183,236,.25)';g.lineWidth=k===4?2:1;
   g.moveTo(0,y);g.lineTo(W,y);g.stroke();
 }
 for(let k=0;k<=16;k++){
   let x=W*k/16;g.beginPath();g.strokeStyle='rgba(255,255,255,.045)';g.lineWidth=1;g.moveTo(x,yTop);g.lineTo(x,yBottom);g.stroke();
 }
 const s=getEngine(), notes=s?.chart?.notes||[], p=s?.players?.[0];
 const cursorX=W*.22,secScale=(W-cursorX-24)/6.2;
 const yy=pit=>yBottom-(clamp(pit,rangeLow,rangeHigh)-rangeLow)/Math.max(1,rangeHigh-rangeLow)*(yBottom-yTop);
 const active=[];
 for(const n of notes){
   if(n.talkie)continue;
   const st=Number(n.start),en=Number(n.end),pit=Number(n.pitch);
   if(!Number.isFinite(st)||!Number.isFinite(en)||!Number.isFinite(pit))continue;
   if(en<t-.8||st>t+6.2)continue;
   active.push(n);
   const x=cursorX+(st-t)*secScale,xe=cursorX+(en-t)*secScale,y=yy(pit);
   if(x>W||xe<0)continue;
   g.fillStyle=st<=t&&en>=t?'#a4f8ff':'#38cfff';
   g.shadowBlur=11;g.shadowColor='#00d2ff';
   const left=Math.max(-50,x),width=Math.max(4,Math.min(W+80,xe)-left);
   g.fillRect(left,y-5,width,10);
 }
 g.shadowBlur=0;
 g.strokeStyle='rgba(238,248,255,.96)';g.lineWidth=3;
 g.beginPath();g.moveTo(cursorX,7);g.lineTo(cursorX,H-7);g.stroke();
 const target=active.find(n=>Number(n.start)<=t&&Number(n.end)>=t)||active.find(n=>Number(n.start)>t)||null;
 const actual=Number(p?.mid),voice=Number.isFinite(actual)&&p?.mid!=null?actual:Number(target?.pitch??anchorBase);
 const arrowY=yy(voice),ax=cursorX-18;
 g.save();g.shadowColor='#ffcf67';g.shadowBlur=18;g.fillStyle='#ffd267';g.strokeStyle='#fff2c3';g.lineWidth=1.5;
 g.beginPath();g.moveTo(ax-29,arrowY);g.lineTo(ax-5,arrowY-12);g.lineTo(ax+11,arrowY-12);g.lineTo(ax+29,arrowY);g.lineTo(ax+11,arrowY+12);g.lineTo(ax-5,arrowY+12);g.closePath();g.fill();g.stroke();g.restore();
 // Syllables are an optional guide: invalid text must never blank the notes.
 try{
   const ix=getIndex(t),line=ix>=0?lines[ix]:null;
   if(line){
     const chunks=line.text.split(/\s+/).flatMap(syllables).slice(0,32);
     const from=line.at,to=(lines[ix+1]?.at??from+4),dur=Math.max(.5,to-from);
     g.textAlign='center';g.font='700 12px system-ui';g.textBaseline='middle';
     chunks.forEach((part,i)=>{
       const x=cursorX+((from+(i+.5)/chunks.length*dur)-t)*secScale;
       if(x<0||x>W)return;
       g.lineWidth=3;g.strokeStyle='#020815';g.strokeText(part,x,H-12);
       g.fillStyle=(t>=from+(i+.5)/chunks.length*dur)?'#ff97d5':'#ffffff';g.fillText(part,x,H-12);
     });
   }
 }catch(e){if(!draw.syllableWarned){console.warn('Guia silabica:',e);draw.syllableWarned=true;}}
}
function judgment(dt,t){
 const s=getEngine(), a=audio(),p=s?.players?.[0];if(!p||!a||a.paused||failed||!Number.isFinite(dt)||dt<=0)return;
 const notes=s.chart?.notes||[];
 const active=notes.find(n=>!n.talkie && t>=n.start && t<=n.end);
 if(!active || t<7)return; // silence, interludes and intro never drain the meter
 // Meter updates from actual vocal frame confidence. Does not change game score.
 const diff=Number.isFinite(p.mid)?Math.abs(((p.mid-active.pitch+6)%12+12)%12-6):null;
 const quality=diff===null?0:clamp(1-diff/2.5,0,1);
 crowd=clamp(crowd+(quality>=.77?2.7:quality>=.55?0.25:-4.0)*dt,0,100);
 if(crowd<26 && !failPending){failPending=true;root.classList.add('ns829-danger-mode');}
 if(crowd>32 && failPending){failPending=false;root.classList.remove('ns829-danger-mode');}
 if(crowd<=0 && !failed){
   failed=true;crowd=0;a.pause();root.classList.remove('ns829-danger-mode');$('ns829Fail')?.classList.remove('hidden');
   $('ns828Burst').textContent='SHOW ENCERRADO';$('ns828Burst').classList.remove('ns828-pop');void $('ns828Burst').offsetWidth;$('ns828Burst').classList.add('ns828-pop');
 }
}
function particleOnNote(){const s=getEngine();let i=s?.lastNote??-1;if(i===lastNote)return;const p=s?.players?.[0];if(lastNote>=0&&p){if(p.combo>streak){streak=p.combo;good++;if(streak>0&&streak%5===0){const e=$('ns828Burst');e.textContent=streak+'x COMBO';e.classList.remove('ns828-pop');void e.offsetWidth;e.classList.add('ns828-pop');}}else streak=p.combo||0;}lastNote=i;}
function render(now){if(!isStagePlaying()){cleanOverlay();return;}const s=getEngine(),a=audio(),t=a.currentTime;
 const dt=lastCrowdTime===null?0:clamp((now-lastCrowdTime)/1000,0,.12);lastCrowdTime=now;
 if(!failed)judgment(dt,t);
 lyricUpdate(t);
 try{draw(t);lastDrawError=false;}catch(e){if(!lastDrawError){console.warn('SHOWTIME pista:',e);lastDrawError=true;}}
 particleOnNote();scoreEl.textContent=fmt(s.players[0]?.score||0);comboEl.textContent='x'+Math.max(1,Math.min(4,1+Math.floor((s.players[0]?.combo||0)/8)));
 const fraction=clamp((s.players[0]?.score||0)/Math.max(2000, (s.chart?.notes?.length||50)*220),0,1),stars=Math.min(5,Math.floor(fraction*5));$('ns828Stars').textContent='★'.repeat(stars)+'☆'.repeat(5-stars);$('ns828Level').style.height=crowd.toFixed(1)+'%';
 $('ns828MeterLabel').textContent=Math.round(crowd)+'%';ratioEl.textContent=s.players[0]?.feedback||'AJUSTE SUA VOZ';
 $('ns828Time').textContent=formatTime(t);$('ns828Total').textContent=formatTime(a.duration||s.chart.duration);progressEl.style.width=(100*t/(a.duration||s.chart.duration||1))+'%';$('ns828Pause').textContent=a.paused?'▶':'Ⅱ';
 raf=requestAnimationFrame(render);
}
function reconcile(){if(isStagePlaying()){if(!root)mount();}else if(root)cleanOverlay();}
const obs=new MutationObserver(reconcile);obs.observe(targetGame,{attributes:true,attributeFilter:['class']});
$('startGame')?.addEventListener('click',()=>{setTimeout(reconcile,0);setTimeout(reconcile,500);setTimeout(reconcile,1600);});
$('exitGame')?.addEventListener('click',()=>setTimeout(reconcile,50));
reconcile();
})();
