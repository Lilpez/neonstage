"""Run prior V8.19 analysis first, then conservative V8.20 final audit."""
import importlib.util,json
from pathlib import Path
def process(root,song_id,force=False):
 root=Path(root)
 from neon_v820_sequence import run
 chart_path=root/'songs'/song_id/'chart.json'
 if chart_path.exists():
  current=json.loads(chart_path.read_text(encoding='utf8'))
  if current.get('lyrics_sequence_version')=='v819-20261012a' and current.get('lyric_lines'):
   return {'state':'done','preserved_existing_v819':True,'sequence_validation':run(root,song_id,force=force)}
 prev=root/'neon_preplay_v819_backup.py'
 if not prev.exists():return {'state':'missing_v819_backup'}
 spec=importlib.util.spec_from_file_location('_preplay_v819',str(prev));module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 result=module.process(root,song_id,force=force)
 if not isinstance(result,dict) or result.get('state') not in ('done','already_processed'):
  return result
 from neon_v820_sequence import run
 return {'state':'done','previous':result,'sequence_validation':run(root,song_id,force=force)}
