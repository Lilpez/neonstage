/* NeonStage SHOWTIME V8.21 - game layer. Never modifies chart, notes, or lyric timestamps. */
(function(){
'use strict';
if(window.__neonShowtime822)return;
window.__neonShowtime822=true;
const by=id=>document.getElementById(id);
const limit=(v,a,b)=>Math.max(a,Math.min(b,v));
const reduce=window.matchMedia?.('(prefers-reduced-motion: reduce)');
const unlocks=[{at:4,label:'AQUECIMENTO'},{at:10,label:'EM CHAMAS'},{at:20,label:'VOZ DE OURO'},{at:35,label:'LENDÁRIO'},{at:60,label:'SUPERSTAR'}];
let hud,stage,canvas,ctx,lyricsHost,live,summary,clock,stars,meterWrap,fx=[],playing=false,activeNote=-1,barCache=-1,lastLine='',lastTimestamp=0,frameId=0,round=[],resultsPending=null,superButton=null;
const level=x=>1+Math.floor(Math.sqrt(x/180));
const fmt=n=>Math.round(n).toLocaleString('pt-BR');
const saved=()=>{try{return JSON.parse(localStorage.getItem('neon_showtime_profile_v821')||'{}')}catch{return {}}};
function mount(){
 stage=by('gameScreen');if(!stage || !state.playing || !state.chart)return;
 stage.classList.add('ns-showtime');
 stage.dataset.showtimeVersion='8.22';
 stage.querySelector('#nsShowLayer')?.remove();
 const layer=document.createElement('div');layer.id='nsShowLayer';layer.innerHTML=`
 <div class="ns-atmosphere" aria-hidden="true"><div class="ns-aurora ns-a"></div><div class="ns-aurora ns-b"></div><div class="ns-beam ns-beam1"></div><div class="ns-beam ns-beam2"></div><div class="ns-beam ns-beam3"></div></div>
 <canvas id="nsParticles" aria-hidden="true"></canvas>
 <div class="ns-upper"><div class="ns-round-logo"><span class="ns-logo-dot"></span> SHOWTIME <span class="ns-live">LIVE</span></div><div class="ns-stars" id="nsStars">☆ ☆ ☆ ☆ ☆</div></div>
 <div class="ns-players" id="nsPlayers"></div>
 <div class="ns-energy"><div class="ns-energy-kicker">PODER DE PALCO</div><div class="ns-meter"><i id="nsEnergyBar"></i></div><button type="button" class="ns-super" id="nsSuperBtn" disabled>✦ ATIVAR SUPERSTAR <small>ESPAÇO</small></button><span id="nsEnergyInfo">Cante para carregar</span></div>
 <div class="ns-lyrics-accent" aria-hidden="true"></div>
 <div class="ns-burst-area" id="nsBurstArea" aria-live="polite"></div>
 <div class="ns-events" id="nsEvents" aria-live="polite"></div>
 <div class="ns-side-title">YOUR VOICE · YOUR STAGE</div>`;
 stage.appendChild(layer);canvas=by('nsParticles');ctx=canvas.getContext('2d');hud=by('nsPlayers');clock=by('nsEnergyInfo');stars=by('nsStars');superButton=by('nsSuperBtn');
 const profiles=saved();round=(state.players||[]).map((p,i)=>({id:i,name:p.name,streak:0,best:0,perfect:0,great:0,good:0,miss:0,total:0,xp:0,scoreBonus:0,energy:0,superUntil:0,awards:new Set(),profile:(profiles[p.name]||0),totalAccuracy:0}));
 hud.replaceChildren();for(let r of round){let el=document.createElement('div');el.className='ns-player';el.innerHTML=`<div class="ns-pheader"><span class="ns-pname"></span><span class="ns-pbadge">NV 1</span></div><div class="ns-score">0</div><div class="ns-pdetail"><b class="ns-combo">0 COMBO</b><strong class="ns-multi">x1</strong></div><div class="ns-ptrack"><i></i></div><div class="ns-pfeedback">PREPARE A VOZ</div>`;el.querySelector('.ns-pname').textContent=r.name;hud.appendChild(el);r.element=el;}
 superButton.onclick=()=>activate(0);
 round.forEach(updatePlayer);playing=true;activeNote=-1;lastLine='';fx.length=0;lastTimestamp=0;
 by('lyricCurrent')?.classList.remove('ns-line-enter');
 cancelAnimationFrame(frameId);frameId=requestAnimationFrame(animation);
}
function updatePlayer(r){if(!r.element)return;const p=state.players[r.id];let multi=multiplier(r);r.element.querySelector('.ns-pbadge').textContent='NV '+level(r.profile+r.xp);r.element.querySelector('.ns-score').textContent=fmt(p?.score||0);r.element.querySelector('.ns-combo').textContent=r.streak+' COMBO';r.element.querySelector('.ns-multi').textContent='x'+multi;r.element.querySelector('.ns-ptrack i').style.width=limit(r.streak/25*100,0,100)+'%';r.element.querySelector('.ns-pfeedback').textContent=p?.feedback||'CANTANDO';r.element.classList.toggle('ns-hot',r.streak>=10);r.element.classList.toggle('ns-star-active',r.superUntil>performance.now());}
function multiplier(r){return Math.min(4,1+Math.floor(r.streak/8));}
function pop(title,subtitle='',kind='good'){const box=by('nsBurstArea');if(!box)return;let item=document.createElement('div');item.className='ns-judgement '+kind;let main=document.createElement('strong');main.textContent=title;let detail=document.createElement('span');detail.textContent=subtitle;item.append(main,detail);box.appendChild(item);setTimeout(()=>item.remove(),1120);while(box.children.length>3)box.firstChild.remove();}
function event(label){let box=by('nsEvents');if(!box)return;let el=document.createElement('div');el.className='ns-achievement';el.textContent='✦ '+label;box.appendChild(el);setTimeout(()=>el.remove(),2500);while(box.children.length>3)box.firstChild.remove();}
function burst(n=20){if(reduce?.matches)return;const rect=stage.getBoundingClientRect();const x=rect.width*.5,y=rect.height*.52;for(let i=0;i<n;i++){let angle=(i/n)*Math.PI*2+(Math.random()*.4),v=1.5+Math.random()*4;fx.push({x,y,vx:Math.cos(angle)*v,vy:Math.sin(angle)*v-1,life:55+Math.random()*25,r:1.6+Math.random()*3,hue:i%3===0?185:i%3===1?315:48});}if(fx.length>240)fx.splice(0,fx.length-240)}
function onNote(i,snap){if(i<0||!round.length)return;round.forEach((r,k)=>{let p=snap[k];if(!p||p.attempts<.055)return;const q=limit(p.hits/p.attempts,0,1);r.total++;r.totalAccuracy+=q;const cls=q>=.9?'perfect':q>=.72?'great':q>=.54?'good':'miss';r[cls]++;if(cls==='miss'){if(r.streak>=5)pop('COMBO QUEBRADO','Continue cantando','miss');r.streak=0;r.energy=limit(r.energy-6,0,100);}else{r.streak++;r.best=Math.max(r.best,r.streak);r.xp+=cls==='perfect'?45:cls==='great'?28:14;r.energy=limit(r.energy+(cls==='perfect'?13:cls==='great'?9:5),0,100);if(k===0){if(cls==='perfect')pop('PERFECT!',`+45 XP  ·  x${multiplier(r)}`,'perfect');else if(cls==='great'&&r.streak%2===0)pop('GREAT!','SEGURA O COMBO','great');if(cls==='perfect'||r.streak%7===0)burst(cls==='perfect'?24:15);}}
 for(let u of unlocks){if(r.streak>=u.at&&!r.awards.has(u.label)){r.awards.add(u.label);r.xp+=u.at*12;if(k===0){event(u.label+' · +'+u.at*12+' XP');burst(40);}}}updatePlayer(r);});renderEnergy();}
function renderEnergy(){const r=round[0];if(!r)return;const now=performance.now(),isSuper=r.superUntil>now;by('nsEnergyBar').style.width=(isSuper?100:r.energy)+'%';const can=r.energy>=100&&!isSuper;superButton.disabled=!can;superButton.textContent=isSuper?'✦ SUPERSTAR ATIVO':can?'✦ ATIVAR SUPERSTAR':'✦ CARREGANDO...';clock.textContent=isSuper?'PODER '+Math.ceil((r.superUntil-now)/1000)+'s':can?'APERTE ESPAÇO PARA ATIVAR':'Cante bem para carregar';stage.classList.toggle('ns-super-active',isSuper);}
function activate(i){const r=round[i];if(!playing||!state.playing||!r||r.energy<100||r.superUntil>performance.now())return;r.energy=0;r.superUntil=performance.now()+13000;event('SUPERSTAR MODE • 13 SEGUNDOS');pop('SHOWTIME!','BÔNUS x2 NA PONTUAÇÃO','perfect');burst(75);renderEnergy();}
function animation(t){if(!playing||!stage?.isConnected)return;const dpr=Math.min(2,window.devicePixelRatio||1),w=stage.clientWidth,h=stage.clientHeight;if(w>0&&h>0){if(canvas.width!==Math.ceil(w*dpr)||canvas.height!==Math.ceil(h*dpr)){canvas.width=Math.ceil(w*dpr);canvas.height=Math.ceil(h*dpr)}ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);for(let j=fx.length-1;j>=0;j--){let p=fx[j];p.x+=p.vx;p.y+=p.vy;p.vy+=.045;p.life-=1;ctx.beginPath();ctx.fillStyle=`hsla(${p.hue},100%,75%,${limit(p.life/65,0,1)})`;ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fill();if(p.life<=0)fx.splice(j,1);}}
 if(t-lastTimestamp>160){lastTimestamp=t;let r=round[0];if(r){renderEnergy();const max=Math.max(1,state.chart?.notes?.length||1),sum=round.reduce((v,a)=>v+a.perfect+a.great+a.good,0);const accuracy=sum/max;const st=limit(Math.round(accuracy*5),0,5);stars.textContent='★ '.repeat(st)+'☆ '.repeat(5-st);const rms=limit((state.players[0]?.rms||0)*6,0,1);stage.style.setProperty('--ns-beat',rms.toFixed(3));round.forEach(updatePlayer);}}
 frameId=requestAnimationFrame(animation);
}
function finish(){if(!playing)return;const r=round[0];if(!r)return;const idx=state.lastNote;if(idx>=0&&idx!==activeNote){activeNote=idx;}const rows=round.map(q=>({name:q.name,xp:q.xp,perfect:q.perfect,great:q.great,good:q.good,miss:q.miss,best:q.best,accuracy:q.total?Math.round(q.totalAccuracy/q.total*100):0,stars:Math.min(5,Math.round((q.totalAccuracy/Math.max(1,q.total))*5)),score:Math.round(state.players[q.id]?.score||0),achievements:[...q.awards]}));const data=saved();for(let q of round)data[q.name]=(data[q.name]||0)+q.xp;try{localStorage.setItem('neon_showtime_profile_v821',JSON.stringify(data))}catch{}resultsPending=rows;}
function presentResults(){if(!resultsPending)return;const root=by('finishScores');if(!root)return;root.querySelector('.ns-results')?.remove();let wrap=document.createElement('section');wrap.className='ns-results';let title=document.createElement('div');title.className='ns-finish-title';title.textContent='RESULTADO DO SHOW';wrap.appendChild(title);for(let r of resultsPending){let row=document.createElement('div');row.className='ns-finish-card';const name=document.createElement('div');name.className='ns-finish-name';name.textContent=r.name;const score=document.createElement('strong');score.textContent=fmt(r.score)+' PTS';const star=document.createElement('div');star.className='ns-finish-stars';star.textContent='★'.repeat(r.stars)+'☆'.repeat(5-r.stars);const stats=document.createElement('div');stats.className='ns-finish-metrics';for(let t of [`${r.accuracy}% PRECISÃO`,`${r.best}x COMBO`,`+${r.xp} XP`,`${r.perfect} PERFECTS`]){let span=document.createElement('span');span.textContent=t;stats.appendChild(span);}row.append(name,score,star,stats);wrap.appendChild(row)}root.appendChild(wrap);resultsPending=null;}
// Hook the native scoring engine. Scores remain derived from mic pitch; this adds real earned multiplier points.
const nativeScore=scoreFrame;
scoreFrame=function(t,dt){const prePlayers=state.players.map(p=>({attempts:p.attempts,hits:p.hits,score:p.score}));const preIndex=state.lastNote;nativeScore.apply(this,arguments);if(playing){for(let i=0;i<round.length;i++){let p=state.players[i],r=round[i];if(!p||!r)continue;const earned=Math.max(0,p.score-prePlayers[i].score),factor=multiplier(r)*(r.superUntil>performance.now()?2:1);const bonus=earned*(factor-1);if(Number.isFinite(bonus)&&bonus>0){p.score+=bonus;r.scoreBonus+=bonus;}}
 if(preIndex>=0&&preIndex!==state.lastNote)onNote(preIndex,prePlayers);
 activeNote=state.lastNote;}}
const nativeLyrics=renderLyrics;
renderLyrics=function(t){nativeLyrics.apply(this,arguments);if(!playing)return;const el=by('lyricCurrent');if(!el)return;const text=el.textContent||'';if(text!==lastLine){lastLine=text;el.classList.remove('ns-line-enter');void el.offsetWidth;el.classList.add('ns-line-enter');const parts=(state.chart?.lyric_lines||[]).filter(x=>String(x.text||'').trim());const match=parts.findIndex(x=>String(x.text||'').trim()===text);let next=parts[match+1];el.style.setProperty('--ns-lyric-progress','0%');el.dataset.nsFrom=match>=0?String(parts[match].at):String(t);el.dataset.nsTo=next?String(next.at):String(t+4);}
 const from=Number(el.dataset.nsFrom),to=Number(el.dataset.nsTo);if(Number.isFinite(from)&&Number.isFinite(to)&&to>from){el.style.setProperty('--ns-lyric-progress',limit(100*(t-from)/(to-from),0,100)+'%');}}
const nativeBegin=beginSong;
beginSong=async function(){const v=await nativeBegin.apply(this,arguments);if(state.playing&&state.chart)mount();return v;};
const nativeStop=stopGame;
stopGame=async function(){playing=false;cancelAnimationFrame(frameId);stage?.classList.remove('ns-super-active');return nativeStop.apply(this,arguments)};
const nativeFinish=finishGame;
finishGame=async function(){if(state.playing)finish();const v=await nativeFinish.apply(this,arguments);presentResults();return v;};
// Activation fix: setupEvents assigned startGame.onclick BEFORE this module loaded.
// Observe the screen lifecycle rather than relying only on wrapping beginSong.
const gameScreen=by('gameScreen');
if(gameScreen){
  const syncStage=()=>{
    if(state.playing && state.chart && !gameScreen.classList.contains('hidden')){
      if(!gameScreen.querySelector('#nsShowLayer')) mount();
    }else if(!gameScreen.classList.contains('hidden')){
      // wait until beginSong finishes preparing the chart
    }else if(playing){
      playing=false;cancelAnimationFrame(frameId);gameScreen.querySelector('#nsShowLayer')?.remove();
      gameScreen.classList.remove('ns-showtime');
    }
  };
  new MutationObserver(syncStage).observe(gameScreen,{attributes:true,attributeFilter:['class']});
  by('startGame')?.addEventListener('click',()=>{setTimeout(syncStage,0);setTimeout(syncStage,700);setTimeout(syncStage,2000)});
  syncStage();
}
window.addEventListener('keydown',e=>{if(e.code==='Space'&&!e.repeat&&state.playing&&!/INPUT|TEXTAREA|BUTTON/.test(document.activeElement?.tagName||'')){if(round[0]?.energy>=100){e.preventDefault();activate(0);}}});
})();
