"""Optional, non-authoritative YouTube karaoke caption reference for NS14.2.

Does NOT OCR/download video, guess words, or update the approved chart.
Requires yt-dlp, downloads caption files only, validates duration and ordered lyric text.
"""
from __future__ import annotations
import html
import json
import math
import re
import statistics
import subprocess
import sys
import tempfile
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

VIDEO_ID = re.compile(r'^[A-Za-z0-9_-]{11}$')
TIME = re.compile(r'(\d{2,}):(\d{2}):(\d{2})[.,](\d{3})')
CUE = re.compile(r'(?m)^\s*((?:\d{2,}:)?\d\d:\d\d[.,]\d{3})\s*-->\s*((?:\d{2,}:)?\d\d:\d\d[.,]\d{3})')


def youtube_url(url: str) -> str:
    """Exact canonical YouTube watch URL; no arbitrary URL forwarding."""
    if not isinstance(url, str) or len(url) > 350:
        raise ValueError('URL de video invalida.')
    u = urlsplit(url.strip())
    if u.scheme != 'https' or u.username or u.password or u.port not in (None, 443):
        raise ValueError('Use um link HTTPS do YouTube.')
    host = (u.hostname or '').lower()
    if host in ('youtube.com', 'www.youtube.com', 'm.youtube.com', 'music.youtube.com'):
        if u.path != '/watch':
            raise ValueError('Use a URL de um video do YouTube, nao playlists ou canais.')
        ids = parse_qs(u.query).get('v') or []
        video_id = ids[0] if len(ids) == 1 else ''
    elif host == 'youtu.be':
        video_id = u.path.lstrip('/')
    else:
        raise ValueError('Somente videos do YouTube sao aceitos.')
    if not VIDEO_ID.fullmatch(video_id):
        raise ValueError('ID do video invalido.')
    return 'https://www.youtube.com/watch?v=' + video_id


def _run_yt_dlp(args: list[str], timeout=40) -> str:
    cmd = [sys.executable, '-m', 'yt_dlp', '--no-warnings', '--no-playlist', *args]
    try:
        res = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=timeout)
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError('YouTube demorou para responder.') from exc
    if res.returncode != 0:
        raise RuntimeError('yt-dlp falhou ao consultar o YouTube. Atualize yt-dlp ou confira a rede: '+res.stderr.strip()[-220:])
    return res.stdout


def search(chart: dict, max_results=8) -> list[dict]:
    artist = str(chart.get('artist') or '').strip()[:90]
    title = str(chart.get('title') or '').strip()[:120]
    title = re.sub(r'\([^)]*(?:Registro|Ao Vivo|Live|Official|Clipe)[^)]*\)', ' ', title, flags=re.I)
    query = f'{artist} {title} karaoke letra'.strip()
    result = _run_yt_dlp(['--flat-playlist', '--dump-single-json', f'ytsearch{min(max_results,10)}:{query}'], timeout=40)
    try:
        body = json.loads(result)
    except ValueError as exc:
        raise RuntimeError('Resultado de busca inesperado do yt-dlp.') from exc
    found = []
    for item in body.get('entries') or []:
        if not isinstance(item, dict):
            continue
        ident = str(item.get('id') or '')
        if not VIDEO_ID.fullmatch(ident):
            continue
        found.append({'id': ident, 'url':'https://www.youtube.com/watch?v='+ident,
                      'title': str(item.get('title') or '')[:180],
                      'duration': item.get('duration'), 'uploader':str(item.get('uploader') or '')[:90]})
    return found


def _seconds(value: str) -> float:
    chunks = value.replace(',', '.').split(':')
    if len(chunks) not in (2, 3):
        raise ValueError(value)
    if len(chunks) == 2:
        return round(int(chunks[0]) * 60 + float(chunks[1]), 3)
    return round(int(chunks[0]) * 3600 + int(chunks[1]) * 60 + float(chunks[2]), 3)


def parse_vtt(data: str) -> list[dict]:
    lines = re.split(r'\r?\n\s*\r?\n', data)
    cues = []
    for block in lines:
        match = CUE.search(block)
        if not match:
            continue
        try:
            start, end = _seconds(match.group(1)), _seconds(match.group(2))
        except (ValueError, OverflowError):
            continue
        if not (end > start >= 0 and end-start < 120):
            continue
        raw = block[match.end():]
        raw = re.sub(r'<[^>]*>', ' ', raw)
        raw = re.sub(r'\{\\[^}]+\}', '', raw)
        raw = html.unescape(raw)
        raw = re.sub(r'\s+', ' ', raw).strip()
        raw = re.sub(r'^\[(music|applause|musica|música)\]$', '', raw, flags=re.I)
        if not raw or len(raw) > 300:
            continue
        if cues and cues[-1]['text'].casefold() == raw.casefold() and start - cues[-1]['end'] < 0.5:
            cues[-1]['end'] = end
        else:
            cues.append({'start':start, 'end':end, 'text':raw})
    return cues[:1000]


def _similarity(a: str, b: str) -> float:
    from difflib import SequenceMatcher
    import unicodedata
    def norm(x):
        v = ''.join(c for c in unicodedata.normalize('NFKD', x.casefold()) if not unicodedata.combining(c))
        return re.findall('[a-z0-9]+', v)
    aa, bb = norm(a), norm(b)
    if not aa or not bb:
        return 0.0
    joined_a, joined_b = ' '.join(aa), ' '.join(bb)
    score = SequenceMatcher(None, joined_a, joined_b, autojunk=False).ratio()
    # Caption cue may combine two lyric lines; an entire verified line within it is meaningful.
    if len(aa) >= 3 and joined_a in joined_b:
        score = max(score, 0.90)
    return score


def match_cues(chart: dict, cues: list[dict]) -> dict:
    """Monotonic order, one cue per matched lyric; repeated refrains can't reuse cues."""
    lines = [{'index':i, 'text':x['text'], 'at':float(x['at'])}
             for i,x in enumerate(chart.get('lyric_lines') or [])
             if isinstance(x,dict) and x.get('text') and x.get('at') is not None]
    n, m = len(lines), min(len(cues), 750)
    dp = [[0.]*(m+1) for _ in range(n+1)]
    route = [[None]*(m+1) for _ in range(n+1)]
    for i in range(1,n+1):
        for j in range(1,m+1):
            score = _similarity(lines[i-1]['text'], cues[j-1]['text'])
            best = dp[i-1][j]; prev = (i-1,j,'skip_line')
            if dp[i][j-1] > best:
                best = dp[i][j-1]; prev = (i,j-1,'skip_cue')
            if score >= .78:
                # Preference for stable chronology and nearby recordings without forbidding intro differences.
                proximity = min(.20, abs(lines[i-1]['at']-cues[j-1]['start'])*.004)
                matchscore = dp[i-1][j-1] + 1.0 + score - proximity
                if matchscore > best:
                    best = matchscore; prev=(i-1,j-1,'match')
            dp[i][j] = best; route[i][j]=prev
    matches=[];i=n;j=m
    while i>0 and j>0:
        prev=route[i][j]
        if prev is None: break
        if prev[2]=='match':
            item=lines[i-1];cue=cues[j-1]
            matches.append({'index':item['index'],'text':item['text'], 'reference_at':cue['start'],
                            'reference_end':cue['end'], 'old_at':item['at'],
                            'similarity':round(_similarity(item['text'],cue['text']),3)})
        i,j=prev[:2]
    matches.reverse()
    deltas=[r['reference_at']-r['old_at'] for r in matches]
    offset=statistics.median(deltas) if deltas else None
    residuals=[abs(x-offset) for x in deltas] if deltas else []
    mad=statistics.median(residuals) if residuals else None
    matched_ratio=len(matches)/max(1,len(lines))
    try: duration=float(chart.get('duration') or 0)
    except (ValueError,TypeError):duration=0.
    return {'lines':matches,'matched_ratio':round(matched_ratio,4),
            'reference_offset_seconds':round(offset,3) if offset is not None else None,
            'offset_mad_seconds':round(mad,3) if mad is not None else None,
            'reference_lyric_lines':len(lines), 'reference_cues':len(cues)}


def inspect(song: Path, url: str, chart: dict) -> dict:
    """Downloads only subtitle tracks into tempdir, never YouTube media streams."""
    safe = youtube_url(url)
    with tempfile.TemporaryDirectory(prefix='neon_sync142_ref_') as folder:
        output = str(Path(folder)/'karaoke.%(ext)s')
        stdout=_run_yt_dlp(['--dump-single-json','--no-simulate','--skip-download','--write-subs',
                             '--write-auto-subs','--sub-langs','pt.*,en.*',
                             '--sub-format','vtt','-o',output,safe], timeout=75)
        lines=[s for s in stdout.splitlines() if s.startswith('{')]
        if not lines:
            raise RuntimeError('Video indisponivel para consulta.')
        try: meta=json.loads(lines[-1])
        except ValueError as exc: raise RuntimeError('Metadados invalidos.') from exc
        tracks = sorted(Path(folder).glob('*.vtt'), key=lambda p: ('pt' not in p.name.lower(), 'en' not in p.name.lower()))
        captions=[];trackname=None
        for path in tracks[:12]:
            if path.stat().st_size>2_000_000:
                continue
            parsed=parse_vtt(path.read_text(encoding='utf-8-sig',errors='replace'))
            if len(parsed)>len(captions):
                captions=parsed;trackname=path.name
    result=match_cues(chart,captions)
    try: ref_duration=float(meta.get('duration') or 0)
    except (TypeError,ValueError): ref_duration=0.
    try: original_duration=float(chart.get('duration') or 0)
    except (TypeError,ValueError): original_duration=0.
    difference=abs(ref_duration-original_duration) if ref_duration and original_duration else None
    compatible=(difference is not None and difference<=max(3.,original_duration*.02)
                and result['matched_ratio']>=.55 and len(result['lines'])>=6
                and result['offset_mad_seconds'] is not None and result['offset_mad_seconds']<=.65)
    result.update({'url':safe,'video_title':str(meta.get('title') or '')[:180],
                   'video_duration':ref_duration,'song_duration':original_duration,
                   'duration_difference':round(difference,2) if difference is not None else None,
                   'caption_track':trackname,'caption_available':bool(captions),
                   'reference_compatible':compatible,
                   'status': ('consistent_caption_reference' if compatible else
                              'captions_unavailable' if not captions else 'comparison_only'),
                   'warning': ('Legendas sao referencia auxiliar, nao sao prova de audio identico. '
                               'Videos com letras desenhadas na imagem exigem OCR e nao sao lidos nesta versao.')})
    return result


def atomic_json(path: Path, obj: dict):
    import os
    temp=path.with_name('.'+path.name+'.tmp')
    try:
        temp.write_text(json.dumps(obj, ensure_ascii=False,indent=2),encoding='utf-8')
        os.replace(temp,path)
    finally:
        temp.unlink(missing_ok=True)

LRC_LINE = re.compile(r'^\[(\d{1,3}):(\d{2})(?:[.,](\d{1,3}))?\]\s*(.*?)\s*$')


def parse_lrc(text: str) -> list[dict]:
    parsed=[]
    for line in text.splitlines():
        m=LRC_LINE.match(line.strip())
        if m is None or not m.group(4):
            continue
        fraction=(m.group(3) or '0').ljust(3,'0')[:3]
        start=int(m.group(1))*60+int(m.group(2))+int(fraction)/1000
        if start < 0 or start>3600 or len(m.group(4))>250:continue
        parsed.append({'start':round(start,3),'end':round(start+1.,3),
                       'text':m.group(4)})
    parsed.sort(key=lambda x:x['start'])
    return parsed[:700]


def lookup_lrclib(chart: dict) -> dict|None:
    """Optional free public LRC; no user-controlled host; one request, respect rate limits."""
    from urllib.parse import urlencode
    from urllib.request import Request, urlopen
    from urllib.error import HTTPError, URLError
    title=str(chart.get('title') or '').strip()
    artist=str(chart.get('artist') or '').strip()
    if not title or not artist:
        return None
    title=re.sub(r'\([^)]*(?:Registro|Ao Vivo|Live|Official|Clipe)[^)]*\)','',title,flags=re.I).strip()
    if title.casefold().startswith(artist.casefold()+' - '):
        title=title[len(artist)+3:].strip()
    try:dur=round(float(chart.get('duration') or 0))
    except (TypeError,ValueError):dur=0
    query={'track_name':title[:120], 'artist_name':artist[:100]}
    if 1<=dur<=3600:query['duration']=dur
    url='https://lrclib.net/api/get?'+urlencode(query)
    req=Request(url,headers={'User-Agent':'NeonStage-SyncLab/14.2 (https://github.com/tranxuanthang/lrclib)',
                             'Accept':'application/json'})
    try:
        with urlopen(req,timeout=12) as connection:
            contents=connection.read(450000)
        record=json.loads(contents)
    except HTTPError as exc:
        if exc.code==404:return None
        if exc.code==429:
            raise RuntimeError('LRCLIB limitou as consultas. Aguarde antes de tentar novamente.')
        raise RuntimeError('Falha ao consultar LRCLIB: HTTP '+str(exc.code))
    except (URLError,TimeoutError) as exc:
        raise RuntimeError('LRCLIB indisponivel: '+str(exc)[:120])
    lrc=record.get('syncedLyrics') or ''
    cues=parse_lrc(lrc)
    if not cues:return None
    match=match_cues(chart,cues)
    duration=record.get('duration')
    try:
        duration=float(duration)
        original=float(chart.get('duration') or 0)
        diff=abs(duration-original)
    except (ValueError,TypeError):
        diff=None;original=0
    compatible=(diff is not None and diff<=2.5 and match['matched_ratio']>=.55
                and len(match['lines'])>=6 and match['offset_mad_seconds'] is not None
                and match['offset_mad_seconds']<=.65)
    match.update({'url':'https://lrclib.net/api/get/'+str(int(record['id'])),
                  'video_title':str(record.get('trackName') or title)+' — LRCLIB',
                  'source':'lrclib_synced_lyrics', 'caption_track':'syncedLyrics (LRC)',
                  'caption_available':True,'video_duration':duration,'song_duration':original,
                  'duration_difference':diff,'reference_compatible':compatible,
                  'status':'consistent_synced_lyrics_reference' if compatible else 'comparison_only',
                  'warning':'LRC pode vir de outra gravacao. Compare os versos; nada modifica o chart aprovado.'})
    return match
