"""NeonStage 10 local stage lifecycle, LAN discovery and durable score ledger."""
from __future__ import annotations
import ipaddress
import json
import os
from pathlib import Path
import socket
import threading
import time
import webbrowser
from flask import jsonify, request

_LOCK=threading.RLock()
_STAGE_SEEN=0.0
_STAGE_OPENED=0.0
_STAGE_KEY=''
_SCORES=None

def _is_host():
    return request.remote_addr in ('127.0.0.1','::1')

def local_network_client(remote):
    """PIN-free entry only for devices on the same /24 LAN as this notebook."""
    try:
        if ipaddress.ip_address(remote).is_loopback:return True
        with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as s:
            s.connect(('192.0.2.1',80))
            host=s.getsockname()[0]
        remoteip=ipaddress.ip_address(remote);localip=ipaddress.ip_address(host)
        if remoteip.version!=4 or not remoteip.is_private:return False
        return remoteip in ipaddress.ip_network(host+'/24',strict=False) and localip.is_private
    except (OSError,ValueError):return False

def _db(root):return Path(root)/'neon10_placar_global.json'

def _load(root):
    path=_db(root)
    try:
        raw=json.loads(path.read_text(encoding='utf-8'))
        return raw if isinstance(raw,dict) else {}
    except (OSError,ValueError):return {}

def _commit(root,items):
    path=_db(root);tmp=path.with_suffix('.tmp')
    tmp.write_text(json.dumps(items,ensure_ascii=False,indent=2),encoding='utf-8')
    os.replace(tmp,path)

def add_points(root,profile_id,name,avatar,points):
    score=max(0,min(5000000,int(points or 0)))
    if score<=0:return
    pid=str(profile_id or '')[:100]
    if not pid:pid='name:'+str(name or 'Convidado').strip().casefold()
    if not (pid.startswith('ns10-') or pid.startswith('name:') or pid=='local-pc'):
        pid='name:'+str(name or 'Convidado').strip().casefold()
    with _LOCK:
        data=_load(root)
        entry=data.get(pid,{'name':'Convidado','avatar':'','points':0,'performances':0})
        entry['name']=str(name or 'Convidado')[:40]
        if isinstance(avatar,str) and len(avatar)<65000 and avatar.startswith('data:image/'):
            entry['avatar']=avatar
        entry['points']=int(entry.get('points',0))+score
        entry['performances']=int(entry.get('performances',0))+1
        data[pid]=entry;_commit(root,data)

def register(app,root):
    root=Path(root)
    @app.post('/api/neon10/stage/ping')
    def stage_ping():
        global _STAGE_SEEN
        if not _is_host():return jsonify(error='Somente notebook'),403
        with _LOCK:_STAGE_SEEN=time.monotonic()
        return jsonify(ok=True)

    @app.get('/api/neon10/discover')
    def discover():
        ok=local_network_client(request.remote_addr)
        return jsonify(ok=ok,lan=ok,pin_optional=ok,server='NeonStage',player_limit=10)

    @app.get('/api/neon10/leaderboard')
    def leaderboard():
        with _LOCK:
            entries=sorted(_load(root).values(),key=lambda e:int(e.get('points',0)),reverse=True)
        return jsonify(players=entries[:250])

    @app.post('/api/neon10/score')
    def local_score():
        if not _is_host():return jsonify(error='Somente notebook'),403
        payload=request.get_json(silent=True) or {}
        try:
            add_points(root,payload.get('profile_id','local-pc'),payload.get('name','Convidado'),'',payload.get('points',0))
        except (ValueError,TypeError):return jsonify(error='Pontuacao invalida'),400
        return jsonify(ok=True)

    @app.after_request
    def open_stage_from_phone(response):
        global _STAGE_OPENED,_STAGE_KEY
        if request.method!='POST' or request.path not in ('/api/party/control','/api/party/next','/api/party/host-action') or response.status_code>=300:
            return response
        try:
            payload=response.get_json(silent=True)
            # Some actions return {ok:true}, not the full state; their action is harmless.
            state=payload.get('state') if isinstance(payload,dict) and 'state' in payload else payload
            if not isinstance(state,dict) or state.get('phase')!='singing':return response
            playback=state.get('playback') or {}
            key=str(state.get('position',''))+'|'+str(playback.get('song_id',''))
            now=time.monotonic()
            with _LOCK:
                should_open=now-_STAGE_SEEN>4 and (key!=_STAGE_KEY or now-_STAGE_OPENED>15)
                if should_open:
                    _STAGE_OPENED=now;_STAGE_KEY=key
            if should_open:
                threading.Timer(.35,lambda:webbrowser.open('http://127.0.0.1:8765/palco')).start()
        except Exception:
            app.logger.exception('Falha ao solicitar palco')
        return response
