﻿from pathlib import Path
import os, sys, json, re, shutil, hashlib, datetime, subprocess
ROOT=Path(sys.argv[1]).resolve()
APP=ROOT/'app.py'; HTML=ROOT/'static'/'index.html'; JS=ROOT/'static'/'neon_storage_phase5.js'; CSS=ROOT/'static'/'neon_storage_phase5.css'
if not APP.is_file() or not HTML.is_file(): raise SystemExit('NeonStage invalido')
app=APP.read_text(encoding='utf-8-sig'); html=HTML.read_text(encoding='utf-8-sig')
prelude='''# NS_STORAGE_FASE5_BOOT
import json as _ns_storage_json
_NS_STORAGE_CONFIG = ROOT / 'neon_storage.json'
def _ns_storage_selected():
    try:
        obj = _ns_storage_json.loads(_NS_STORAGE_CONFIG.read_text(encoding='utf-8'))
        dest = Path(obj.get('songs_path', '')).expanduser()
        if dest.is_absolute() and dest.is_dir():
            return dest.resolve()
    except (OSError, ValueError, TypeError):
        pass
    return ROOT / 'songs'
SONGS = _ns_storage_selected()
SONGS.mkdir(parents=True, exist_ok=True)
'''
if '# NS_STORAGE_FASE5_BOOT' not in app:
    target="SONGS = ROOT / 'songs'\nSONGS.mkdir(exist_ok=True)"
    if target not in app: raise SystemExit('Localizacao da pasta SONGS nao reconhecida. Nada alterado.')
    app=app.replace(target,prelude,1)
route='''# NS_STORAGE_FASE5_API
@app.get('/api/neon/storage')
def neon_storage_info():
    if request.remote_addr not in ('127.0.0.1', '::1'): return jsonify(error='Apenas local'),403
    return jsonify(path=str(SONGS),default=str(_ns_storage_documents()/'NeonStage'/'Musicas'),restart_required=False)

def _ns_storage_documents():
    try:
        import winreg as _wr
        with _wr.OpenKey(_wr.HKEY_CURRENT_USER, r'Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\User Shell Folders') as key:
            raw,_ = _wr.QueryValueEx(key, 'Personal')
            return Path(os.path.expandvars(raw)).resolve()
    except Exception:
        return Path.home()/'Documents'

def _ns_storage_sha(path):
    import hashlib as _h
    h=_h.sha256()
    with path.open('rb') as f:
        while True:
            buf=f.read(2*1024*1024)
            if not buf: break
            h.update(buf)
    return h.digest()

def _ns_storage_migrate(src, dest):
    import shutil as _shutil
    # Preserve existing songs. Abort if any destination song differs.
    folders=[p for p in src.iterdir() if p.is_dir() and (p/'chart.json').is_file()]
    for folder in folders:
        target=dest/folder.name
        if target.exists():
            if not target.is_dir(): raise ValueError('Conflito no destino: '+folder.name)
            for f in folder.rglob('*'):
                if not f.is_file(): continue
                other=target/f.relative_to(folder)
                if not other.is_file() or _ns_storage_sha(f)!=_ns_storage_sha(other):
                    raise ValueError('Musica diferente no destino: '+folder.name+' (nada substituido)')
    for folder in folders:
        target=dest/folder.name
        if target.exists(): continue
        stage=dest/('.neon_transfer_'+folder.name)
        if stage.exists(): _shutil.rmtree(stage)
        try:
            _shutil.copytree(folder,stage)
            for f in folder.rglob('*'):
                if not f.is_file(): continue
                other=stage/f.relative_to(folder)
                if not other.is_file() or _ns_storage_sha(f)!=_ns_storage_sha(other):
                    raise OSError('Falha ao verificar: '+f.name)
            stage.rename(target)
        finally:
            if stage.exists(): _shutil.rmtree(stage)
    return len(folders)

@app.post('/api/neon/storage')
def neon_storage_change():
    if request.remote_addr not in ('127.0.0.1','::1'): return jsonify(error='Apenas local'),403
    with LOCK:
        if any(j.get('progress',0)<100 and not j.get('error') for j in JOBS.values()):
            return jsonify(error='Aguarde terminar o preparo de musicas.'),409
    requested=str((request.get_json(silent=True) or {}).get('path','')).strip()
    if not requested or len(requested)>550: return jsonify(error='Informe um caminho de pasta valido.'),400
    raw=Path(os.path.expandvars(requested)).expanduser()
    if not raw.is_absolute(): return jsonify(error='Use um caminho absoluto (C:\\\\...)'),400
    try:
        dest=raw.resolve(strict=False); src=SONGS.resolve()
        if dest==src: return jsonify(ok=True,path=str(src),copied=0,restart_required=False)
        # Avoid moving into app itself or into an ancestor of the app.
        if dest==ROOT or dest in ROOT.parents or ROOT in dest.parents:
            return jsonify(error='Escolha uma pasta fora do diretorio do aplicativo.'),400
        if dest==Path(dest.anchor):return jsonify(error='Escolha uma subpasta, nao a raiz do disco.'),400
        dest.mkdir(parents=True,exist_ok=True)
        copied=_ns_storage_migrate(src,dest)
        config=ROOT/'neon_storage.json'
        payload=json.dumps({'songs_path':str(dest)},ensure_ascii=False,indent=2)
        temporary=config.with_name('neon_storage.json.tmp')
        temporary.write_text(payload,encoding='utf-8')
        temporary.replace(config)
        return jsonify(ok=True,path=str(dest),copied=copied,restart_required=True,legacy=str(src))
    except (OSError,ValueError) as exc:
        return jsonify(error=str(exc)),400
'''
if '# NS_STORAGE_FASE5_API' not in app:
    anchor="@app.get('/api/library')"
    if anchor not in app:raise SystemExit('API /api/library nao encontrada')
    app=app.replace(anchor,route+'\n'+anchor,1)
# simple settings UI augment exact prior card
js=r'''(()=>{
'use strict';if(window.__NS_STORAGE_5__)return;window.__NS_STORAGE_5__=true;
const mount=()=>{
 const slot=document.querySelector('#settingsSection #nsDevStorage');
 if(!slot || document.getElementById('nsStoragePicker'))return;
 const card=slot.closest('.ns-dev-card');if(!card)return;
 const old=card.querySelector('.search-hint');if(old)old.textContent='Escolha onde guardar as musicas preparadas. A migracao copia e verifica os arquivos. A pasta antiga nao e apagada.';
 slot.textContent='Carregando caminho atual...';
 const box=document.createElement('div');box.id='nsStoragePicker';box.innerHTML=`<label for="nsStorageFolder">Pasta de destino no computador</label><input id="nsStorageFolder" type="text" spellcheck="false" placeholder="C:\\Users\\...\\Documents\\NeonStage\\Musicas"><div class="ns-storage-actions"><button type="button" class="primary" id="nsStorageSave">Copiar musicas e salvar pasta</button><button type="button" class="ghost" id="nsStorageDefault">Usar Documentos</button></div><p id="nsStorageMessage" role="status"></p>`;
 card.appendChild(box);
 const field=box.querySelector('#nsStorageFolder'),info=box.querySelector('#nsStorageMessage'),save=box.querySelector('#nsStorageSave');
 let defaultPath='';
 fetch('/api/neon/storage',{cache:'no-store'}).then(r=>r.json()).then(d=>{slot.textContent='Pasta ativa: '+d.path;field.value=d.path;defaultPath=d.default;}).catch(e=>info.textContent='Nao foi possivel ler a pasta: '+e.message);
 box.querySelector('#nsStorageDefault').onclick=()=>{if(defaultPath)field.value=defaultPath;};
 save.onclick=async()=>{
   if(!confirm('Copiar as musicas para a pasta escolhida? Os originais serao mantidos. Apos copiar sera necessario reiniciar o NeonStage.'))return;
   save.disabled=true; info.textContent='Copiando e verificando arquivos. Nao feche o servidor...';
   try{const r=await fetch('/api/neon/storage',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path:field.value})});const d=await r.json();if(!r.ok)throw Error(d.error||'Erro');
     info.textContent=d.restart_required?'Pronto: '+d.copied+' pasta(s) verificadas. REINICIE O NEONSTAGE para usar o novo local. Os originais foram mantidos.':'Pasta ja esta ativa.';
     slot.textContent='Pasta selecionada: '+d.path;
   }catch(e){info.textContent='Nao foi possivel migrar: '+e.message;}finally{save.disabled=false;}
 };
};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount);else mount();
})();'''
css='''#nsStoragePicker{margin-top:18px;max-width:780px;color:#d8dbf1}#nsStorageFolder{width:100%;box-sizing:border-box;padding:14px 15px;margin-top:6px;border:1px solid #ffffff40;border-radius:10px;color:#fff;background:#101321;font:500 14px system-ui}#nsStoragePicker .ns-storage-actions{display:flex;gap:12px;flex-wrap:wrap;margin-top:15px}#nsStoragePicker .ns-storage-actions button{padding:12px 16px;border-radius:10px;cursor:pointer}#nsStorageMessage{margin-top:12px;font-size:13px;line-height:1.5;color:#bde9d4}'''
if 'neon_storage_phase5.js' not in html:
    html=re.sub(r'</body\s*>','<script src="/static/neon_storage_phase5.js?v=501"></script></body>',html,count=1,flags=re.I)
if 'neon_storage_phase5.css' not in html:
    html=re.sub(r'</head\s*>','<link rel="stylesheet" href="/static/neon_storage_phase5.css?v=501"></head>',html,count=1,flags=re.I)
compile(app,str(APP),'exec')
backup=ROOT/('backup_armazenamento_fase5_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f'));backup.mkdir()
files=[APP,HTML,JS,CSS]
for p in files:
    if p.exists():shutil.copy2(p,backup/p.name)
try:
    APP.write_text(app,encoding='utf-8',newline='')
    HTML.write_text(html,encoding='utf-8',newline='')
    JS.write_text(js,encoding='utf-8',newline='')
    CSS.write_text(css,encoding='utf-8',newline='')
except BaseException:
    for p in files:
        orig=backup/p.name
        if orig.exists():shutil.copy2(orig,p)
        else:p.unlink(missing_ok=True)
    raise
print('FASE 5 INSTALADA: escolha de pasta e migracao verificada')
print('Backup dos arquivos de codigo:',backup)
print('Acesse Configuracoes > Armazenamento para selecionar a pasta.')
print('O servidor deve ser reiniciado apos a migracao.')

