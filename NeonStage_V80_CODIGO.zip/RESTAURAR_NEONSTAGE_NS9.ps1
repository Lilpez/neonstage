$ErrorActionPreference = 'Stop'
$root = Join-Path $env:USERPROFILE 'Downloads\NeonStage_V80'
$backup = Get-ChildItem -LiteralPath $root -Directory -Filter 'BACKUP_ANTES_NEONSTAGE_NS9_*' |
    Sort-Object Name | Select-Object -First 1
if (-not $backup) { throw 'Nenhum backup NS9 encontrado.' }
$manifestPath = Join-Path $backup.FullName 'manifest.json'
if (!(Test-Path $manifestPath)) { throw 'Manifesto do backup ausente.' }
$manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
Write-Host "Backup escolhido: $($backup.FullName)"
$confirm = Read-Host 'Feche o servidor. Digite RESTAURAR para voltar a esta versao'
if ($confirm -cne 'RESTAURAR') { Write-Host 'Cancelado.'; exit 0 }
foreach ($rel in $manifest.written) {
    $path = Join-Path $root $rel
    $prior = Join-Path $backup.FullName $rel
    if ($manifest.existing -contains $rel) {
        $parent = Split-Path $path -Parent
        if (!(Test-Path $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
        Copy-Item -LiteralPath $prior -Destination $path -Force
    } else {
        if (Test-Path $path) { Remove-Item -LiteralPath $path -Force }
    }
}
Write-Host 'Codigo restaurado. Musicas e configs atuais nao foram alteradas.' -ForegroundColor Green
Write-Host 'Reinicie o NeonStage para concluir.'
