"""Automatic Genius discovery for known lyrics pages; no ASR lyrics."""
import json,re,time,unicodedata,urllib.request,urllib.parse,hashlib
from pathlib import Path

def norm(s):
    return ' '.join(re.sub(r'[^a-z0-9]+',' ',''.join(c for c in unicodedata.normalize('NFKD',str(s).casefold()) if not unicodedata.combining(c))).split())

def identity(title,artist):
    # A origem costuma ser "Canal - Artista - Faixa (Album) [Video Oficial]".
    # O titulo real e o segmento que tem musica, nao o album ou o canal.
    t=str(title or '').strip(); a=str(artist or '').strip()
    t=re.sub(r'\s*[\[【][^\]】]*(?:video|audio|official|oficial|lyric|clipe|4k|hd)[^\]】]*[\]】]', '',t,flags=re.I)
    parts=[x.strip() for x in re.split(r'\s+[-–—|]\s+',t) if x.strip()]
    def artistpart(x):
        xx=norm(x).replace(' and ',' ').replace(' e ',' ').replace(' oficial','').strip()
        aa=norm(a).replace(' and ',' ').replace(' e ',' ').replace(' oficial','').strip()
        return bool(xx and aa and (xx==aa or xx in aa or aa in xx))
    while len(parts)>1 and artistpart(parts[0]):parts.pop(0)
    if len(parts)>1 and ('oficial' in norm(parts[0]) or 'official' in norm(parts[0])):parts.pop(0)
    t=parts[0] if parts else t
    # Parenteses de album, gravação e tags de video não são parte do titulo-base.
    t=re.sub(r'\s*[\(\[][^(\[]*(?:album|ao vivo|live|dvd|audio|official|oficial|video|acustic|acústic|os anjos cantam|remaster|na praia|camarim)[^)\]]*[\)\]]','',t,flags=re.I)
    # Albums, documentary labels and editions commonly appear in YouTube titles.
    t=re.sub(r'\s*\([^)]*(?:registro\s+historico|registro\s+hist[oó]rico|hist[oó]rico|grava[cç][aã]o|vers[aã]o|show|dvd|clipe|oficial)[^)]*\)', '', t, flags=re.I)
    t=re.sub(r'\s*\[[^]]*(?:registro\s+historico|hist[oó]rico|dvd|clipe|oficial)[^]]*\]', '', t, flags=re.I)
    t=re.sub(r'\s+',' ',t).strip(' -–—:|')
    if not t and parts:t=parts[0]
    return t,a

def _request(url,token=''):
    hdr={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/125 Safari/537.36','Accept':'application/json'}
    if token:hdr['Authorization']='Bearer '+token
    with urllib.request.urlopen(urllib.request.Request(url,headers=hdr),timeout=14) as r:return json.load(r)

def candidates(title,artist,token):
    title,artist=identity(title,artist)
    queries=list(dict.fromkeys([f'{artist} {title}',title,f'{title} {artist}',f'{artist} {title} lyrics']))
    urls=[]; seen=set()
    def add(song):
        if not isinstance(song,dict):return
        uri=song.get('url','')
        if not uri.startswith('https://genius.com/') or uri in seen:return
        seen.add(uri)
        urls.append((uri,song.get('title',''),(song.get('primary_artist') or {}).get('name','')))
    for query in queries:
        encoded=urllib.parse.quote(query)
        endpoints=[]
        if token:endpoints.append(('https://api.genius.com/search?q='+encoded,token))
        endpoints.append(('https://genius.com/api/search/multi?q='+encoded,''))
        for url,auth in endpoints:
            try:
                data=_request(url,auth)
                for h in data.get('response',{}).get('hits',[]):add(h.get('result'))
                for section in data.get('response',{}).get('sections',[]):
                    for h in section.get('hits',[]):add(h.get('result'))
            except Exception as exc:
                print('GENIUS AUTO busca:',str(exc)[:110],flush=True)
    tn=norm(title); an=norm(artist)
    def artmatch(x):
        n=norm(x); aa=set(an.replace(' and ',' ').replace(' e ',' ').split());bb=set(n.replace(' and ',' ').replace(' e ',' ').split())
        return bool(aa and bb and (aa==bb or aa.issubset(bb) or bb.issubset(aa)))
    ranked=sorted(urls,key=lambda x:(tn in norm(x[1]) if tn else False,artmatch(x[2]),norm(x[1])==tn),reverse=True)
    # Não eliminar títulos por prefixos/sufixos; manter apenas título-base e artista compatível.
    return [c for c in ranked if tn and tn in norm(c[1]) and (artmatch(c[2]) or (an and an in norm(c[1])))]


# NS9: broader title discovery, still requiring an artist/title confidence floor.
def candidates(title,artist,token):
    from difflib import SequenceMatcher
    original_title,artist=identity(title,artist)
    base=norm(original_title)
    variants=[original_title]
    # Live/album labels and duplicated artist fields need not match literally.
    for separator in (' | ',' - ',' – ',' — ',':'):
        if separator in original_title:
            variants += [x.strip() for x in original_title.split(separator) if len(norm(x))>2]
    variants=list(dict.fromkeys(variants))[:5]
    seen={}
    queries=list(dict.fromkeys(
        [f'{artist} {x}'.strip() for x in variants]+variants+[f'{original_title} lyrics']
    ))[:7]
    for query in queries:
        endpoints=[]
        encoded=urllib.parse.quote(query)
        if token:endpoints.append(('https://api.genius.com/search?q='+encoded,token))
        endpoints.append(('https://genius.com/api/search/multi?q='+encoded,''))
        for url,auth in endpoints:
            try:
                response=_request(url,auth)
                hits=list(response.get('response',{}).get('hits',[]))
                for section in response.get('response',{}).get('sections',[]):
                    hits += section.get('hits',[])
                for hit in hits:
                    song=hit.get('result') or {}
                    target=str(song.get('url') or '')
                    if not target.startswith('https://genius.com/') or target in seen:continue
                    seen[target]=(target,str(song.get('title') or ''),str((song.get('primary_artist') or {}).get('name') or ''))
            except Exception as exc:
                print('GENIUS BUSCA:',str(exc)[:90],flush=True)
    def similarity(x,y):
        a,b=norm(x),norm(y)
        if not a or not b:return 0.0
        return 1.0 if a==b else max(0.87 if a in b or b in a else 0.0,SequenceMatcher(None,a,b).ratio())
    def score(candidate):
        _,title_found,artist_found=candidate
        sim=max(similarity(v,title_found) for v in variants)
        artist_sim=similarity(artist,artist_found) if artist else 0.7
        return (.76*sim+.24*artist_sim,sim,artist_sim)
    ranked=sorted(seen.values(),key=lambda x:score(x)[0],reverse=True)
    # Avoid unrelated similarly named recordings even when the artist is absent.
    confident=[]
    for result in ranked:
        total,match,artist_match=score(result)
        if match>=.74 and (artist_match>=.49 or not norm(artist)) and total>=.70:
            confident.append(result)
    print('GENIUS NS9:',repr(original_title),repr(artist),'opcoes confiaveis:',len(confident),flush=True)
    return confident[:20]

def lookup(title,artist,duration,token,root):
    import neon_genius_engine as g
    title,artist=identity(title,artist)
    cache_dir=Path(root)/'genius_lyrics_cache';cache_dir.mkdir(exist_ok=True)
    key=hashlib.sha256((norm(title)+'|'+norm(artist)).encode()).hexdigest()[:24]
    cp=cache_dir/(key+'.json')
    if cp.exists():
        try:
            data=json.loads(cp.read_text(encoding='utf-8'))
            if data.get('lyric_lines') and time.time()-data.get('lyrics_verified_at',0)<86400*30:return data
        except Exception:pass
    # Preservar fontes diretas confirmadas em diagnosticos anteriores.
    # Buscar automaticamente primeiro; links conhecidos ajudam se API não retornar.
    # Explicit fallback for URL user already verified to be readable.
    found=candidates(title,artist,token)
    print('GENIUS V7.3:',repr(title),repr(artist),'candidatos:',len(found),flush=True)
    if norm(title)=='rancorosa' and 'henrique' in norm(artist) and 'juliano' in norm(artist):
        known='https://genius.com/Henrique-and-juliano-rancorosa-ao-vivo-em-brasilia-lyrics'
        found=[(known,'Rancorosa (Ao Vivo em Brasília)','Henrique & Juliano')]+[c for c in found if c[0]!=known]
    for url,track,performer in found[:50]:
        try:
            html=g.read_page(url)
            lyrics=g.parse_genius_html(html) if html else ''
            lines=[x.strip() for x in lyrics.splitlines() if x.strip() and not re.fullmatch(r'\[[^]]+\]',x.strip())]
            if len(re.findall(r'\w+',lyrics,re.U))<40:continue
            # Zero timestamps are placeholders. Alignment engine sets them using vocals.
            result={'lyric_lines':[{'at':0,'text':x} for x in lines],
              'lyrics_verified_source':'Genius (auto)', 'lyrics_verified_track':track,
              'lyrics_verified_artist':performer,'lyrics_verified_url':url,
              'lyrics_verified_mode':'unsynced','lyrics_verified_at':time.time()}
            cp.write_text(json.dumps(result,ensure_ascii=False),encoding='utf-8')
            print('GENIUS AUTO OK:',title,'->',url,'linhas:',len(lines),flush=True)
            return result
        except Exception as exc:
            print('GENIUS AUTO candidato falhou:',str(exc)[:100],flush=True)
    print('GENIUS AUTO: nenhum resultado com letra para',repr(title),repr(artist),flush=True)
    return None
