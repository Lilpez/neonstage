"""NeonStage Party v6: 10 authenticated phones, persistent queue and duet turns."""
import json, os, secrets, threading, time
from pathlib import Path
from flask import request, jsonify, redirect


def register(app, root, songs, jobs, pool, run_job):
    lock=threading.RLock()
    file=Path(root)/'party_session.json'
    def fresh():
        return dict(version=6,preparations={},pin=f'{secrets.randbelow(900000)+100000}',players=[None]*10,mode='solo',per_player=3,team_chorus=False,advanced_mics=False,mic_assignments={},phase='lobby',host_index=None,queue=[],position=0,ready=[],scores=[0]*10,playback=dict(song_id=None,time=0,playing=False,started_at=0),results=[],created=time.time())
    # Room tokens/players/queue are deliberately ephemeral across process restarts.
    # The global leaderboard remains persisted by neon10_server.py.
    state=fresh()
    state.update(team_chorus=False,advanced_mics=False,mic_assignments={})
    # Invalidate stale tokens and pending queues immediately at startup.
    # Use a private session file only for the currently running process.
    
    def save():
        tmp=file.with_suffix('.tmp')
        tmp.write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf-8')
        os.replace(tmp,file)
    save()  # reset any old persisted session immediately at process startup
    def host():return request.remote_addr in ('127.0.0.1','::1')
    def player():
        token=(request.headers.get('X-Player-Token') or '')[:128]
        if not token:return None
        for idx,p in enumerate(state['players']):
            if p and secrets.compare_digest(p['token'],token):return idx
        return None
    def ensure_preparation(ch):
        ident=ch['id']
        if ident=='demo_neonstage' or (songs/ident/'chart.json').exists():
            return dict(song_id=ident,stage='Pronta',progress=100,error=None)
        cache=state.setdefault('preparations',{})
        previous=cache.get(ident)
        if previous:
            job=jobs.get(previous.get('job_id'),{})
            if job:return previous
            # Jobs from before a server restart cannot be resumed; start them again.
            # Restart interrupted background jobs after server restart / explicit retry
        from uuid import uuid4
        job_id='music_'+uuid4().hex[:14]
        jobs[job_id]=dict(stage='Aguardando processamento',progress=2,error=None,song_id=None)
        cache[ident]=dict(job_id=job_id)
        pool.submit(run_job,job_id,ident,ch['title'],ch['artist'])
        return cache[ident]

    def prep_info(ch):
        ident=ch['id']
        prep=state.setdefault('preparations',{}).get(ident)
        if ident=='demo_neonstage' or (songs/ident/'chart.json').exists():
            return dict(progress=100,stage='Pronta',song_id=ident,error=None)
        if not prep:return dict(progress=0,stage='Aguardando',song_id=None,error=None)
        job=jobs.get(prep.get('job_id'),{})
        return dict(progress=int(job.get('progress',0)),stage=job.get('stage','Na fila'),song_id=job.get('song_id'),error=job.get('error'))

    def duet_segments(entry):
        if not entry or not entry.get('duet'):return []
        sid=prep_info(dict(id=entry['video_id'])).get('song_id')
        if not sid:return []
        try:
            chart=json.loads((songs/sid/'chart.json').read_text(encoding='utf-8'))
            lines=sorted([(float(x.get('at',x.get('start',0))),str(x.get('text') or '').strip()) for x in (chart.get('lyric_lines') or []) if str(x.get('text') or '').strip()])
            singers=entry.get('singers') or [entry['singer']]
            if not lines:return []
            import unicodedata
            def norm(text):
                return ''.join(c for c in unicodedata.normalize('NFD',text.lower()) if unicodedata.category(c)!='Mn' and (c.isalnum() or c.isspace())).strip()
            from collections import Counter
            counts=Counter(norm(text) for _,text in lines if len(norm(text))>=11)
            chorus=state.get('mode')=='duet' and state.get('team_chorus',False)
            # A chorus is indicated conservatively by a repeated lyric line.
            # Never infer a chorus simply from the time elapsed.
            
            # All singers get a turn when enough distinct lyric lines are available.
            total=max(1.0,lines[-1][0]-lines[0][0]);n=len(singers)
            target=max(10.0,min(78.0,total/max(n+0.35,2.8)))
            # Use musical phrase boundaries, not arbitrary 30-second cuts.
            segment=0;last_switch=lines[0][0];out=[]
            for i,(at,lyric) in enumerate(lines):
                remaining=len(lines)-i
                others=max(0,n-1-segment)
                if segment < n-1 and i>0 and ((at-last_switch>=target) or (remaining<=others+1)):
                    segment+=1;last_switch=at
                elif segment>=n-1 and at-last_switch>=target and n>1:
                    segment+=1;last_switch=at
                out.append(dict(at=round(at,3),text=lyric,singer=singers[segment%n],all_sing=bool(chorus and counts.get(norm(lyric),0)>1)))
            return out
        except (OSError,ValueError,TypeError,KeyError,IndexError):return []
    def view(include_pin=False):
        players=[]
        for i,p in enumerate(state['players']):
            players.append(dict(id=i,name=p['name'],avatar=p.get('avatar',''),choices=p['choices'],ready=p['ready']) if p else None)
        q=[]
        for item in state['queue']:
            job=prep_info(dict(id=item['video_id']))
            q.append({**item,'job':job,'song_id':job.get('song_id')})
        for pp in state['players']:
            if pp:
                for ch in pp['choices']:
                    if ch['id']!='demo_neonstage' and not (songs/ch['id']/'chart.json').exists():ensure_preparation(ch)
        unique={ch['id']:prep_info(ch) for pp in state['players'] if pp for ch in pp['choices']}
        progress=int(sum(x['progress'] for x in unique.values())/len(unique)) if unique else 0
        return dict(max_players=10,active_count=sum(bool(p) for p in state['players']),duet_segments=duet_segments(state['queue'][state['position']]) if state['phase']=='singing' and state['position']<len(state['queue']) else [],preparation=unique,preparation_percent=progress,preparation_total=len(unique),preparation_ready=sum(bool(x.get('song_id')) for x in unique.values()),host_index=state.get('host_index'),colors=['#ba82ff','#65d9f0','#fa92a4','#f8ce74','#8de5a2','#b4a6ff','#ffb981','#ec9de0','#83e8da','#afcbff'],players=players,mode=state['mode'],team_chorus=state.get('team_chorus',False),advanced_mics=state.get('advanced_mics',False),mic_assignments=state.get('mic_assignments',{}),per_player=state['per_player'],phase=state['phase'],next_at=state.get('next_at'),queue=q,position=state['position'],scores=state['scores'],playback=state['playback'],results=state['results'],pin=state['pin'] if include_pin else None)
    # NS_PARTY_PRESENCE_V1
    PRESENCE_TIMEOUT=25.0
    def touch_player():
        who=player()
        if who is not None:
            state['players'][who]['last_seen']=time.time()
        return who
    def expire_absent():
        # Only release slots in the lobby / choosing phase; never mid-song.
        if state.get('phase') not in ('lobby','choosing'):
            return False
        changed=False
        now=time.time()
        for i,p in enumerate(state['players']):
            if p and now-float(p.get('last_seen',now))>PRESENCE_TIMEOUT:
                state['players'][i]=None
                changed=True
                if state.get('host_index')==i:
                    state['host_index']=next((j for j,v in enumerate(state['players']) if v),None)
        if changed:save()
        return changed
    @app.post('/api/party/leave')
    def leave_party():
        with lock:
            who=player()
            if who is None:return jsonify(ok=True,already_left=True)
            state['players'][who]=None
            if state.get('host_index')==who:
                state['host_index']=next((j for j,p in enumerate(state['players']) if p),None)
            # Keep an active song running. Future choices owned by the user
            # who left are excluded, so remaining players can continue.
            if state['phase'] in ('preparing','between','singing'):
                pos=int(state.get('position',0))
                keep_current=pos+1 if state['phase']=='singing' else pos
                old_queue=state['queue']
                state['queue']=old_queue[:keep_current]+[e for e in old_queue[keep_current:] if e.get('owner')!=who]
                for entry in state['queue']:
                    entry['singers']=[i for i in entry.get('singers',[]) if state['players'][i] is not None]
                    if entry.get('singer')==who and entry['singers']:
                        entry['singer']=entry['singers'][0]
                    if len(entry['singers'])<2:entry['duet']=False
                if state['phase']=='between' and pos>=len(state['queue']):
                    state['phase']='completed';state['next_at']=None
            # The departing user's token can no longer control this room.
            save()
            return jsonify(ok=True,player=who,state=view(include_pin=False))

    @app.post('/api/party/presence')
    def presence_ping():
        with lock:
            expire_absent()
            who=touch_player()
            if who is None:return jsonify(error='Sessao expirada. Entre novamente.'),401
            return jsonify(ok=True,player=who)
    @app.post('/api/party/kick')
    def kick_player():
        with lock:
            who=player()
            if not (host() or (who is not None and who==state.get('host_index'))):return forbidden()
            target=data().get('player')
            if type(target)!=int or not 0<=target<len(state['players']):return jsonify(error='Jogador invalido.'),400
            victim=state['players'][target]
            if not victim:return jsonify(error='Vaga ja esta vazia.'),409
            if state.get('phase') not in ('lobby','choosing'):
                return jsonify(error='So e possivel expulsar jogadores antes de iniciar as apresentacoes.'),409
            if who==target and not host():return jsonify(error='O anfitriao nao pode expulsar a si mesmo.'),400
            state['players'][target]=None
            if state.get('host_index')==target:
                state['host_index']=next((i for i,p in enumerate(state['players']) if p),None)
            save()
            return jsonify(ok=True,player=target,state=view())
    def data():return request.get_json(silent=True) or {}
    def forbidden():return jsonify(error='Acesso negado.'),403
    def is_phone_host():return player() is not None and player()==state.get('host_index')
    def authorized_host():return host() or is_phone_host()
    @app.get('/party')
    def phone_page():return app.send_static_file('party_next.html')
    @app.get('/host')
    def host_page():
        if not authorized_host():return forbidden()
        return redirect('/neonstage-party')
    @app.get('/api/party/state')
    def state_api():
        with lock:
            expire_absent();touch_player()
            return jsonify(view(include_pin=host()))
    @app.get('/api/party/me')
    def me():
        with lock:
            expire_absent();who=touch_player()
            return jsonify(player=who if who is not None else -1)
    @app.post('/api/party/join')
    def join():
        inp=data();pin=str(inp.get('pin',''))
        name=str(inp.get('name','')).strip()[:25]
        if not name:return jsonify(error='Escolha um nome.'),400
        with lock:
            from neon10_server import local_network_client
            if pin!=state['pin'] and not (not pin and local_network_client(request.remote_addr)):return jsonify(error='Código da sala incorreto; use o PIN manual.'),403
            expire_absent()
            existing=player()
            if existing is not None:
                touch_player()
                return jsonify(token=state['players'][existing]['token'],player=existing,state=view())
            if state['phase'] not in ('lobby','choosing'):return jsonify(error='A sessão já foi iniciada.'),409
            slot=next((i for i,p in enumerate(state['players']) if p is None),None)
            if slot is None:return jsonify(error='A sala está cheia (10 participantes).'),409
            token=secrets.token_urlsafe(32)
            profile_id=str(inp.get('profile_id') or '')[:80]
            if not __import__('re').fullmatch(r'ns10-[a-f0-9-]{8,60}',profile_id):profile_id='name:'+name.casefold()
            state['players'][slot]=dict(name=name,profile_id=profile_id,token=token,choices=[],ready=False,last_seen=time.time())
            if state.get('host_index') is None:state['host_index']=slot
            save();return jsonify(token=token,player=slot,state=view())
    @app.post('/api/party/avatar')
    def avatar_upload():
        with lock:
            who=player()
            if who is None:return forbidden()
            avatar=data().get('avatar','')
            if not isinstance(avatar,str) or len(avatar)>65000:
                return jsonify(error='Imagem muito grande.'),400
            if avatar and not __import__('re').fullmatch(r'data:image/(?:jpeg|png|webp);base64,[A-Za-z0-9+/=]+',avatar):
                return jsonify(error='Formato de imagem invalido.'),400
            state['players'][who]['avatar']=avatar
            save()
            return jsonify(ok=True)

    @app.post('/api/party/open-choices')
    def open_choices():
        with lock:
            if not is_phone_host():return forbidden()
            if state['phase']!='lobby':return jsonify(error='Escolhas já iniciadas.'),409
            if not any(state['players']):return jsonify(error='Aguardando participantes.'),409
            state['phase']='choosing';save();return jsonify(view())
    @app.post('/api/party/transfer')
    def transfer():
        with lock:
            if not is_phone_host():return forbidden()
            target=data().get('player')
            if type(target)!=int or not 0 <= target < len(state['players']) or not state['players'][target]:
                return jsonify(error='Jogador inválido.'),400
            state['host_index']=target;save();return jsonify(view())
    @app.post('/api/party/launch')
    def launch():
        with lock:
            if not is_phone_host():return forbidden()
            if state['phase']!='choosing':return jsonify(error='As escolhas ainda não foram abertas.'),409
            if not all(p['ready'] and 1<=len(p['choices'])<=state['per_player'] for p in state['players'] if p) or not any(state['players']):
                return jsonify(error='Todos os participantes precisam confirmar as três músicas.'),409
            _assemble_queue();save();return jsonify(view())
    @app.post('/api/party/host-action')
    def host_action():
        with lock:
            if not is_phone_host():return forbidden()
            action=data().get('action')
            if action=='next':
                if state['phase'] not in ('preparing','between'):return jsonify(error='Não é hora de iniciar.'),409
                if state['position']>=len(state['queue']):return jsonify(error='Fila concluída.'),409
                if not all(prep_info(dict(id=x['video_id'])).get('song_id') for x in state['queue']):
                    return jsonify(error='Aguardando preparação das músicas.'),409
                entry=state['queue'][state['position']]
                sid=prep_info(dict(id=entry['video_id'])).get('song_id')
                state['phase']='singing';state.pop('next_at',None);state['playback']=dict(song_id=sid,time=0,playing=False,started_at=time.time(),live_score=0)
            elif action=='reset':
                old=state['players'];new=fresh()
                new['host_index']=state.get('host_index')
                for i,x in enumerate(old):
                    if x:new['players'][i]=dict(name=x['name'],avatar=x.get('avatar',''),profile_id=x.get('profile_id','name:'+x['name'].casefold()),token=x['token'],choices=[],ready=False,last_seen=time.time())
                state.clear();state.update(new)
            else:return jsonify(error='Ação desconhecida.'),400
            save();return jsonify(view())
    @app.post('/api/party/choices')
    def choices():
        inp=data()
        with lock:
            who=player()
            if who is None:return forbidden()
            if state['phase']!='choosing':return jsonify(error='Aguarde o anfitrião abrir a escolha de músicas.'),409
            p=state['players'][who]
            if p['ready']:return jsonify(error='Você já confirmou sua lista.'),409
            song=inp.get('song') or {}
            vid=str(song.get('id',''))
            if not (__import__('re').fullmatch(r'[A-Za-z0-9_-]{11}',vid) or (vid.startswith('music_') and (songs/vid/'chart.json').exists()) or vid=='demo_neonstage'):
                return jsonify(error='Versão inválida.'),400
            if len(p['choices'])>=state['per_player']:return jsonify(error='Você atingiu o limite de músicas.'),409
            choice=dict(id=vid,title=str(song.get('title','Música'))[:150],artist=str(song.get('artist','Artista'))[:120])
            p['choices'].append(choice)
            ensure_preparation(choice)
            save();return jsonify(view())
    @app.post('/api/party/remove')
    def remove():
        with lock:
            who=player()
            if who is None:return forbidden()
            p=state['players'][who]
            if state['phase']!='choosing' or p['ready']:return jsonify(error='Lista bloqueada.'),409
            idx=data().get('index')
            if not isinstance(idx,int) or not 0<=idx<len(p['choices']):return jsonify(error='Índice inválido.'),400
            p['choices'].pop(idx);save();return jsonify(view())
    @app.post('/api/party/ready')
    def ready():
        with lock:
            who=player()
            if who is None:return forbidden()
            if state['phase']!='choosing':return jsonify(error='As escolhas ainda não estão abertas.'),409
            p=state['players'][who]
            if not 1<=len(p['choices'])<=state['per_player']:return jsonify(error='Escolha de 1 até 3 músicas antes de confirmar.'),400
            p['ready']=True
            save();return jsonify(view())
    @app.post('/api/party/config')
    def config():
        if not authorized_host():return forbidden()
        with lock:
            if state['phase'] not in ('lobby','choosing'):return jsonify(error='Configuração bloqueada.'),409
            inp=data();mode=inp.get('mode',state['mode'])
            if mode not in ('solo','shared','duet'):return jsonify(error='Modo inválido.'),400
            if any(p and p['ready'] for p in state['players']):return jsonify(error='Jogadores já confirmaram escolhas.'),409
            state['mode']=mode
            if 'team_chorus' in inp:state['team_chorus']=bool(inp['team_chorus'])
            if 'advanced_mics' in inp:state['advanced_mics']=bool(inp['advanced_mics'])
            save();return jsonify(view(include_pin=True))
    @app.post('/api/party/mic-assignments')
    def mic_assignments():
        if not host():return forbidden()
        with lock:
            if state['phase'] not in ('lobby','choosing'):return jsonify(error='Disponível somente no lobby.'),409
            if not state.get('advanced_mics'):return jsonify(error='Habilite microfones separados antes.'),409
            raw=data().get('assignments') or {}
            if not isinstance(raw,dict):return jsonify(error='Formato inválido.'),400
            assignments={}
            for key,value in raw.items():
                if not str(key).isdigit() or not 0<=int(key)<10:continue
                if state['players'][int(key)] and isinstance(value,str) and len(value)<=256:
                    assignments[str(int(key))]=value
            state['mic_assignments']=assignments
            save();return jsonify(ok=True,state=view(include_pin=True))

    def prepare_all(queue):
        for entry in queue:
            ch=dict(id=entry['video_id'],title=entry['title'],artist=entry['artist'])
            prep=ensure_preparation(ch)
            if prep.get('song_id'):entry['song_id']=prep['song_id']
            if prep.get('job_id'):entry['job_id']=prep['job_id']
    def _assemble_queue():
        ps=state['players'];queue=[]
        active=[i for i,p in enumerate(ps) if p]
        for roundno in range(state['per_player']):
            for pos,owner in enumerate(active):
                if roundno>=len(ps[owner]['choices']):continue
                ch=ps[owner]['choices'][roundno]
                mode=state['mode']
                # Every submitted song is performed exactly once.
                # PADRAO: owner alone; EQUIPE/PASSA MIC: one rotating stage with all participants.
                grouped=mode in ('duet','shared') and len(active)>1
                queue.append(dict(video_id=ch['id'],title=ch['title'],artist=ch['artist'],
                    owner=owner,singer=owner,round=roundno+1,duet=grouped,
                    group_mode=mode if grouped else 'solo',singers=active[:] if grouped else [owner]))
        state.update(phase='preparing',queue=queue,position=0,results=[],scores=[0]*10,playback=dict(song_id=None,time=0,playing=False,started_at=0))
        prepare_all(state['queue'])

    @app.post('/api/party/mode')
    def player_mode():
        with lock:
            who=player()
            if who!=state.get('host_index'):return forbidden()
            mode=data().get('mode')
            if mode not in ('solo','shared','duet'):return jsonify(error='Modo inválido.'),400
            if state['phase'] not in ('lobby','choosing') or any(p and p['ready'] for p in state['players']):return jsonify(error='Modo bloqueado após a confirmação.'),409
            state['mode']=mode;save();return jsonify(view())

    @app.post('/api/party/next')
    def player_next():
        with lock:
            who=player()
            if who is None:return forbidden()
            if state['phase'] not in ('preparing','between'):return jsonify(error='Aguardando o turno.'),409
            if state['position']>=len(state['queue']):return jsonify(error='Playlist concluída.'),409
            entry=state['queue'][state['position']]
            if who!=state.get('host_index'):return jsonify(error='Somente o anfitrião inicia o turno.'),403
            if not all(prep_info(dict(id=x['video_id'])).get('song_id') for x in state['queue']):
                return jsonify(error='A playlist ainda está sendo preparada.'),409
            sid=prep_info(dict(id=entry['video_id'])).get('song_id')
            state['phase']='singing';state.pop('next_at',None);state['playback']=dict(song_id=sid,time=0,playing=False,started_at=time.time(),live_score=0)
            save();return jsonify(view())

    @app.post('/api/party/lock')
    def lock_playlist():
        if not authorized_host():return forbidden()
        with lock:
            if state['phase']!='choosing':return jsonify(error='Primeiro abra as escolhas.'),409
            ps=state['players']
            if not any(ps) or not all(p['ready'] and 1<=len(p['choices'])<=state['per_player'] for p in ps if p):return jsonify(error='Cada participante precisa confirmar entre 1 e 3 músicas.'),409
            _assemble_queue()
            save();return jsonify(view(include_pin=True))
    @app.post('/api/party/retry')
    def retry():
        if not authorized_host():return forbidden()
        with lock:
            if state['phase']!='preparing':return jsonify(error='Preparação não está ativa.'),409
            failed={x['video_id'] for x in state['queue'] if prep_info(dict(id=x['video_id'])).get('error')}
            if not failed:return jsonify(error='Nenhuma música com erro; as demais continuam carregando.'),400
            for ident in failed:state['preparations'].pop(ident,None)
            prepare_all([x for x in state['queue'] if x['video_id'] in failed])
            save();return jsonify(view(include_pin=True))
    @app.post('/api/party/control')
    def control():
        if not authorized_host():return forbidden()
        inp=data();action=inp.get('action')
        with lock:
            if action=='start':
                if state['phase'] not in ('preparing','between'):return jsonify(error='A fila não está pronta.'),409
                if state['position']>=len(state['queue']):return jsonify(error='Playlist concluída.'),409
                entry=state['queue'][state['position']]
                sid=prep_info(dict(id=entry['video_id'])).get('song_id')
                if not sid:return jsonify(error='Essa música ainda está sendo preparada.'),409
                state['phase']='singing';state.pop('next_at',None);state['playback']=dict(song_id=sid,time=0,playing=False,started_at=time.time(),live_score=0)
            elif action=='heartbeat':
                if state['phase']!='singing':return jsonify(error='Não há música em execução.'),409
                try:t=max(0,min(36000,float(inp.get('time',0))))
                except (ValueError,TypeError):t=0
                state['playback'].update(time=t,playing=bool(inp.get('playing')),started_at=time.time(),live_score=max(0,int(inp.get('score') or 0)),live_scores=inp.get('live_scores') if isinstance(inp.get('live_scores'),list) else [])
                return jsonify(ok=True)
            elif action=='complete':
                if state['phase']!='singing':return jsonify(error='Não há música ativa.'),409
                singer=state['queue'][state['position']]['singer']
                score=max(0,min(5000000,int(inp.get('score') or 0)))
                entry=state['queue'][state['position']]
                split=inp.get('score_split')
                if entry.get('duet') and isinstance(split,list) and len(split)==len(state['scores']):
                    for participant in entry.get('singers',[]):
                        state['scores'][participant]+=max(0,min(5000000,int(split[participant] or 0)))
                else:
                    state['scores'][singer]+=score
                from neon10_server import add_points
                for participant in (entry.get('singers',[]) if entry.get('duet') else [singer]):
                    pp=state['players'][participant]
                    if pp:
                        achieved=max(0,min(5000000,int((split or [0]*len(state['scores']))[participant] or 0))) if entry.get('duet') and isinstance(split,list) and len(split)==len(state['scores']) else (score if participant==singer else 0)
                        if achieved:
                            try:add_points(root,pp.get('profile_id'),pp['name'],pp.get('avatar',''),achieved)
                            except OSError:app.logger.exception('Nao foi possivel salvar placar')
                state['results'].append(dict(index=state['position'],singer=singer,score=score,failed=bool(inp.get('failed',False)),skipped=bool(inp.get('skipped',False)),duet=bool(entry.get('duet'))))
                state['position']+=1;state['phase']='completed' if state['position']>=len(state['queue']) else 'between'
                state['next_at']=time.time()+5 if state['phase']=='between' else None  # NS_PARTY_AUTO5_V1
                state['playback'].update(playing=False)
            elif action=='reset':
                old=state['players'];new=fresh()
                for i,p in enumerate(old):
                    if p:new['players'][i]=dict(name=p['name'],avatar=p.get('avatar',''),profile_id=p.get('profile_id','name:'+p['name'].casefold()),token=p['token'],choices=[],ready=False,last_seen=time.time())
                new['host_index']=state.get('host_index')
                state.clear();state.update(new)
            else:return jsonify(error='Ação desconhecida.'),400
            save();return jsonify(view(include_pin=True))
    return state
