(()=>{
'use strict';
if(window.__NS_PRESENCE_V1__)return;window.__NS_PRESENCE_V1__=true;
const token=()=>localStorage.getItem('neon_party_token')||localStorage.getItem('ns_party_token')||'';
const post=async(path,payload)=>{const r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json','X-Player-Token':token()},body:JSON.stringify(payload||{})});const data=await r.json();if(!r.ok)throw Error(data.error||'Falha');return data;};
const css=document.createElement('style');css.textContent='#nsPresencePanel{margin:14px 0;padding:16px;border:1px solid #ffffff29;border-radius:16px;background:#141528dc;color:#faf7ff}#nsPresencePanel h3{margin:0 0 12px;font-size:15px}#nsPresencePanel .nsPr{display:flex;align-items:center;justify-content:space-between;gap:9px;margin:8px 0;font-size:13px}#nsPresencePanel button{padding:7px 12px;border:1px solid #ff92cb88;border-radius:9px;background:#3b214a;color:#fff;cursor:pointer}#nsPresencePanel small{opacity:.7}';document.head.appendChild(css);
let self=-1;
async function tick(){
 try{
  const t=token();if(!t)return;
  const state=await(await fetch('/api/party/state',{cache:'no-store',headers:{'X-Player-Token':t}})).json();
  const r=await fetch('/api/party/me',{cache:'no-store',headers:{'X-Player-Token':t}});if(!r.ok)return;self=(await r.json()).player;
  if(self<0){localStorage.removeItem('neon_party_token');localStorage.removeItem('ns_party_token');const panel=document.getElementById('nsPresencePanel');if(panel)panel.remove();return;}
  const isHost=self===state.host_index;
  let panel=document.getElementById('nsPresencePanel');
  if(!isHost||!['lobby','choosing'].includes(state.phase)){if(panel)panel.remove();return;}
  if(!panel){panel=document.createElement('div');panel.id='nsPresencePanel';const holder=document.getElementById('hostTools')||document.getElementById('roster')||document.querySelector('main');holder.appendChild(panel);}
  panel.replaceChildren();const heading=document.createElement('h3');heading.textContent='Gerenciar participantes';panel.appendChild(heading);
  for(let i=0;i<state.players.length;i++){
   const p=state.players[i];if(!p||i===self)continue;
   const row=document.createElement('div');row.className='nsPr';const name=document.createElement('span');name.textContent=p.name+' (P'+(i+1)+')';const btn=document.createElement('button');btn.textContent='Expulsar';btn.onclick=async()=>{if(!confirm('Expulsar '+p.name+' e liberar a vaga?'))return;try{await post('/api/party/kick',{player:i});await tick()}catch(e){alert(e.message)}};row.append(name,btn);panel.appendChild(row);
  }
  const foot=document.createElement('small');foot.textContent='Celulares desconectados liberam a vaga apos cerca de 25 segundos no lobby.';panel.appendChild(foot);
 }catch(e){console.warn('Party presence:',e.message)}
}
setInterval(tick,3200);tick();
})();