(()=>{
'use strict';
if(window.__neonKickCardsV2)return;
window.__neonKickCardsV2=true;
const panel=document.getElementById('players');
if(!panel)return;
const style=document.createElement('style');
style.textContent=`
#players .nk-card{display:flex;align-items:center;gap:12px;padding:10px 12px;min-width:175px;max-width:290px;min-height:60px;background:rgba(255,255,255,.035);border:1px solid rgba(255,255,255,.09);border-radius:12px;color:#f4f1ff;box-sizing:border-box}
#players .nk-avatar{width:35px;height:35px;border-radius:10px;display:grid;place-items:center;background:linear-gradient(135deg,#b766dd,#6374d7);font-weight:900;color:white;flex-shrink:0}
#players .nk-meta{min-width:0;flex:1;display:flex;flex-direction:column;gap:4px}
#players .nk-name{font-size:13px;font-weight:800;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
#players .nk-choices{font-size:10px;color:#bcb8d2}
#players .nk-kick{font-family:Arial,sans-serif;font-size:20px;line-height:1;font-weight:900;appearance:none;border:0;background:transparent;color:#ff334c;cursor:pointer;padding:5px 3px;margin-left:auto;transition:transform .14s,filter .14s}
#players .nk-kick:hover{transform:scale(1.16);filter:drop-shadow(0 0 5px #ff334c88)}
#players .nk-kick:disabled{opacity:.3;cursor:wait}
#players .nk-error{color:#ffacb5;font-size:12px;margin:6px}
`;
document.head.appendChild(style);
let lastSignature=''; let busy=false; let latest=null;
const make=(tag,cls,text)=>{const e=document.createElement(tag);e.className=cls;if(text!==undefined)e.textContent=text;return e;};
async function refresh(){
  if(busy)return;
  try{
    const r=await fetch('/api/party/state',{cache:'no-store'});
    if(!r.ok)return;
    const s=await r.json();latest=s;
    // NS_STABLE_ROSTER_V1
    if(!Array.isArray(s.players))return;
    // Server roster is authoritative, including an empty room.
    const signature=JSON.stringify([s.phase,s.players?.map(p=>p&&[p.name,p.choices?.length,p.ready]),s.per_player]);
    if(signature===lastSignature && panel.querySelector('.nk-card'))return;
    if(!Array.isArray(s.players))return;
    lastSignature=signature;
    const frag=document.createDocumentFragment();
    s.players.forEach((p,i)=>{
      if(!p)return;
      const card=make('div','nk-card');card.dataset.index=String(i);
      const avatar=make('div','nk-avatar',(p.name||'P').slice(0,1).toUpperCase());
      const meta=make('div','nk-meta');
      meta.append(make('div','nk-name',p.name||'Participante'),make('div','nk-choices',`${(p.choices||[]).length} de ${s.per_player||3} escolhas`));
      card.append(avatar,meta);
      if(['lobby','choosing'].includes(s.phase)){
        const x=make('button','nk-kick','X');x.type='button';x.title=`Expulsar ${p.name}`;x.setAttribute('aria-label',x.title);
        x.onclick=async()=>{
          if(!confirm(`Expulsar ${p.name} da festa e liberar a vaga?`))return;
          x.disabled=true;busy=true;
          try{
            const res=await fetch('/api/party/kick',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({player:i})});
            const data=await res.json().catch(()=>({}));
            if(!res.ok||!data.ok)throw Error(data.error||`Erro HTTP ${res.status}`);
            lastSignature='';
            const ct=document.getElementById('playerCount');if(ct)ct.textContent=`${(data.state?.players||[]).filter(Boolean).length} / ${(data.state?.players||s.players).length}`;
          }catch(e){alert('Nao foi possivel expulsar: '+e.message)}
          finally{busy=false;refresh()}
        };
        card.append(x);
      }
      frag.append(card);
    });
    if(!frag.hasChildNodes())frag.append(make('div','nk-error','Aguardando participantes...'));
    panel.replaceChildren(frag);
    const count=document.getElementById('playerCount');if(count)count.textContent=`${s.players.filter(Boolean).length} / ${s.players.length}`;
  }catch(e){console.warn('NeonStage Kick Cards:',e)}
}
setInterval(refresh,650);refresh();
})();
