
/* NeonStage SHOWTIME V8.25 - unified rockband stage with lyric FX, SFX, blurred clip bg, and pitch needle. */
(function(){
'use strict';
if(window.__neonShowtime824)return;window.__neonShowtime824=true;
const by=id=>document.getElementById(id);
const limit=(v,a,b)=>Math.max(a,Math.min(b,v));
const reduce=window.matchMedia?.('(prefers-reduced-motion: reduce)');
const unlocks=[{at:4,label:'AQUECIMENTO'},{at:10,label:'EM CHAMAS'},{at:20,label:'VOZ DE OURO'},{at:35,label:'LENDÁRIO'},{at:60,label:'SUPERSTAR'}];
const hypeWords=['PERFECT!','LINDO!','VOOU!','BRILHOU!','SEGURA!','MANDOU!','NO ALVO!','INCRÍVEL!'];
let hud,stage,canvas,ctx,clock,stars,fx=[],playing=false,activeNote=-1,lastLine='',lastTimestamp=0,frameId=0,round=[],resultsPending=null,superButton=null;
let wordLayer=null,needleCanvas=null,needleCtx=null,audioCtx=null,lastSfxAt=0,bgCacheKey='neon_bg_clip_cache_v823';
const level=x=>1+Math.floor(Math.sqrt(x/180));
const fmt=n=>Math.round(n).toLocaleString('pt-BR');
const saved=()=>{try{return JSON.parse(localStorage.getItem('neon_showtime_profile_v821')||'{}')}catch{return {}}};
function mount(){
 stage=by('gameScreen');if(!stage || !state.playing || !state.chart)return;
 stage.classList.add('ns-showtime');stage.dataset.showtimeVersion='8.25';
 stage.querySelector('#nsShowLayer')?.remove();
 const layer=document.createElement('div');layer.id='nsShowLayer';layer.innerHTML=`
 <div class="ns-bg-wrap" id="nsBgWrap"><div class="ns-bg-fallback"></div><div class="ns-bg-vignette"></div></div>
 <div class="ns-atmosphere" aria-hidden="true"><div class="ns-aurora ns-a"></div><div class="ns-aurora ns-b"></div><div class="ns-beam ns-beam1"></div><div class="ns-beam ns-beam2"></div><div class="ns-beam ns-beam3"></div></div>
 <canvas id="nsParticles" aria-hidden="true"></canvas>
 <div class="ns-upper"><div class="ns-round-logo"><span class="ns-logo-dot"></span> SHOWTIME <span class="ns-live">LIVE</span></div><div class="ns-stars" id="nsStars">☆ ☆ ☆ ☆ ☆</div></div>
 <div class="ns-players" id="nsPlayers"></div>
 <div class="ns-energy"><div class="ns-energy-kicker">PODER DE PALCO</div><div class="ns-meter"><i id="nsEnergyBar"></i></div><button type="button" class="ns-super" id="nsSuperBtn" disabled>✦ ATIVAR SUPERSTAR <small>ESPAÇO</small></button><span id="nsEnergyInfo">Cante para carregar</span></div>
 <div class="ns-burst-area" id="nsBurstArea" aria-live="polite"></div>
 <div class="ns-events" id="nsEvents" aria-live="polite"></div>
 <div class="ns-word-fx" id="nsWordFx" aria-hidden="true"></div>
 <div class="ns-needle-wrap"><div class="ns-needle-title">AFINAÇÃO VOCAL · TENTE ACERTAR A LINHA CENTRAL</div><canvas id="nsNeedleCanvas" width="850" height="120"></canvas><div class="ns-needle-tip" id="nsNeedleTip">CANTE PARA CENTRALIZAR</div></div>
 <div class="ns-side-title">YOUR VOICE · YOUR STAGE</div>`;
 stage.appendChild(layer);canvas=by('nsParticles');ctx=canvas.getContext('2d');hud=by('nsPlayers');clock=by('nsEnergyInfo');stars=by('nsStars');superButton=by('nsSuperBtn');wordLayer=by('nsWordFx');needleCanvas=by('nsNeedleCanvas');needleCtx=needleCanvas.getContext('2d');
 const profiles=saved();round=(state.players||[]).map((p,i)=>({id:i,name:p.name,streak:0,best:0,perfect:0,great:0,good:0,miss:0,total:0,xp:0,scoreBonus:0,energy:0,superUntil:0,awards:new Set(),profile:(profiles[p.name]||0),totalAccuracy:0}));
 hud.replaceChildren();for(let r of round){let el=document.createElement('div');el.className='ns-player';el.innerHTML=`<div class="ns-pheader"><span class="ns-pname"></span><span class="ns-pbadge">NV 1</span></div><div class="ns-score">0</div><div class="ns-pdetail"><b class="ns-combo">0 COMBO</b><strong class="ns-multi">x1</strong></div><div class="ns-ptrack"><i></i></div><div class="ns-pfeedback">PREPARE A VOZ</div></div>`;el.querySelector('.ns-pname').textContent=r.name;hud.appendChild(el);r.element=el;}
 superButton.onclick=()=>activate(0);ensureAudioCtx();
 round.forEach(updatePlayer);playing=true;activeNote=-1;lastLine='';fx.length=0;lastTimestamp=0;
 cancelAnimationFrame(frameId);frameId=requestAnimationFrame(animation);
 setupBackground();
}
function ensureAudioCtx(){try{audioCtx=audioCtx||new (window.AudioContext||window.webkitAudioContext)();if(audioCtx.state==='suspended')audioCtx.resume?.()}catch{}}
function sfx(type='good'){if(reduce?.matches)return;try{ensureAudioCtx();if(!audioCtx)return;const now=audioCtx.currentTime;if(now-lastSfxAt<0.06&&type!=='super')return;lastSfxAt=now;const tones={perfect:[880,1320],great:[700,1040],good:[520,700],miss:[220,180],super:[640,880,1280],unlock:[980,1220]};const seq=tones[type]||tones.good;seq.forEach((f,i)=>{const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type=type==='miss'?'triangle':'sine';o.frequency.setValueAtTime(f,now+i*0.06);g.gain.setValueAtTime(0.0001,now+i*0.06);g.gain.exponentialRampToValueAtTime(type==='super'?0.06:0.03,now+i*0.06+0.01);g.gain.exponentialRampToValueAtTime(0.0001,now+i*0.06+0.18);o.connect(g).connect(audioCtx.destination);o.start(now+i*0.06);o.stop(now+i*0.06+0.19)});}catch{}}
function updatePlayer(r){if(!r.element)return;const p=state.players[r.id];let multi=multiplier(r);r.element.querySelector('.ns-pbadge').textContent='NV '+level(r.profile+r.xp);r.element.querySelector('.ns-score').textContent=fmt(p?.score||0);r.element.querySelector('.ns-combo').textContent=r.streak+' COMBO';r.element.querySelector('.ns-multi').textContent='x'+multi;r.element.querySelector('.ns-ptrack i').style.width=limit(r.streak/25*100,0,100)+'%';r.element.querySelector('.ns-pfeedback').textContent=p?.feedback||'CANTANDO';r.element.classList.toggle('ns-hot',r.streak>=10);r.element.classList.toggle('ns-star-active',r.superUntil>performance.now());}
function multiplier(r){return Math.min(4,1+Math.floor(r.streak/8));}
function pop(title,subtitle='',kind='good'){const box=by('nsBurstArea');if(!box)return;let item=document.createElement('div');item.className='ns-judgement '+kind;let main=document.createElement('strong');main.textContent=title;let detail=document.createElement('span');detail.textContent=subtitle;item.append(main,detail);box.appendChild(item);setTimeout(()=>item.remove(),1120);while(box.children.length>3)box.firstChild.remove();spawnWord(title,kind);}
function spawnWord(text,kind='good'){if(!wordLayer)return;const el=document.createElement('div');el.className='ns-hype '+kind;el.textContent=text;el.style.left=(18+Math.random()*64)+'%';el.style.top=(26+Math.random()*44)+'%';el.style.setProperty('--rot',((-8)+Math.random()*16).toFixed(2)+'deg');wordLayer.appendChild(el);setTimeout(()=>el.remove(),1250);}
function event(label){let box=by('nsEvents');if(!box)return;let el=document.createElement('div');el.className='ns-achievement';el.textContent='✦ '+label;box.appendChild(el);setTimeout(()=>el.remove(),2500);while(box.children.length>3)box.firstChild.remove();}
function burst(n=20){if(reduce?.matches)return;const rect=stage.getBoundingClientRect();const x=rect.width*.5,y=rect.height*.52;for(let i=0;i<n;i++){let angle=(i/n)*Math.PI*2+(Math.random()*.4),v=1.5+Math.random()*4;fx.push({x,y,vx:Math.cos(angle)*v,vy:Math.sin(angle)*v-1,life:55+Math.random()*25,r:1.6+Math.random()*3,hue:i%3===0?185:i%3===1?315:48});}if(fx.length>240)fx.splice(0,fx.length-240)}
function onNote(i,snap){if(i<0||!round.length)return;round.forEach((r,k)=>{let p=snap[k];if(!p||p.attempts<.055)return;const q=limit(p.hits/p.attempts,0,1);r.total++;r.totalAccuracy+=q;const cls=q>=.9?'perfect':q>=.72?'great':q>=.54?'good':'miss';r[cls]++;if(cls==='miss'){if(r.streak>=5)pop('COMBO QUEBRADO','Continue cantando','miss');r.streak=0;r.energy=limit(r.energy-6,0,100);if(k===0)sfx('miss');}else{r.streak++;r.best=Math.max(r.best,r.streak);r.xp+=cls==='perfect'?45:cls==='great'?28:14;r.energy=limit(r.energy+(cls==='perfect'?13:cls==='great'?9:5),0,100);if(k===0){sfx(cls);if(cls==='perfect'){pop('PERFECT!',`+45 XP  ·  x${multiplier(r)}`,'perfect');if(Math.random()>.55)spawnWord(hypeWords[(Math.random()*hypeWords.length)|0],'perfect');}
 else if(cls==='great'&&r.streak%2===0)pop('GREAT!','SEGURA O COMBO','great');else if(cls==='good'&&r.streak%5===0)spawnWord('VAI!', 'good');if(cls==='perfect'||r.streak%7===0)burst(cls==='perfect'?24:15);if(r.streak&&r.streak%10===0){event('COMBO '+r.streak+'!');spawnWord('COMBO '+r.streak,'perfect');}}}
 for(let u of unlocks){if(r.streak>=u.at&&!r.awards.has(u.label)){r.awards.add(u.label);r.xp+=u.at*12;if(k===0){event(u.label+' · +'+u.at*12+' XP');burst(40);spawnWord(u.label,'perfect');sfx('unlock');}}}updatePlayer(r);});renderEnergy();}
function renderEnergy(){const r=round[0];if(!r)return;const now=performance.now(),isSuper=r.superUntil>now;by('nsEnergyBar').style.width=(isSuper?100:r.energy)+'%';const can=r.energy>=100&&!isSuper;superButton.disabled=!can;superButton.textContent=isSuper?'✦ SUPERSTAR ATIVO':can?'✦ ATIVAR SUPERSTAR':'✦ CARREGANDO...';clock.textContent=isSuper?'PODER '+Math.ceil((r.superUntil-now)/1000)+'s':can?'APERTE ESPAÇO PARA ATIVAR':'Cante bem para carregar';stage.classList.toggle('ns-super-active',isSuper);}
function activate(i){const r=round[i];if(!playing||!state.playing||!r||r.energy<100||r.superUntil>performance.now())return;r.energy=0;r.superUntil=performance.now()+13000;event('SUPERSTAR MODE • 13 SEGUNDOS');pop('SHOWTIME!','BÔNUS x2 NA PONTUAÇÃO','perfect');spawnWord('SUPERSTAR!','perfect');burst(75);sfx('super');renderEnergy();}
function setupBackground(){
 const wrap=by('nsBgWrap'),a=by('gameAudio');if(!wrap||!state.chart?.id)return;
 const v=document.createElement('video');v.className='ns-bg-video';v.muted=true;v.playsInline=true;v.preload='metadata';v.loop=false;wrap.prepend(v);
 let done=false,attempt=0;
 const sync=()=>{if(!v.src||!a)return;const diff=(a.currentTime||0)-(v.currentTime||0);if(Math.abs(diff)>.40&&v.readyState>=1){try{v.currentTime=Math.max(0,a.currentTime||0)}catch{}}
 if(a.paused||a.ended){if(!v.paused)v.pause()}else if(v.paused){v.play().catch(()=>{})}};
 a.addEventListener('play',sync);a.addEventListener('pause',sync);a.addEventListener('seeked',sync);
 const poll=()=>{if(!stage?.isConnected||done)return;fetch('/api/showtime/video/'+encodeURIComponent(state.chart.id),{cache:'no-store'}).then(r=>r.json()).then(info=>{if(info.ready&&info.url){done=true;v.src=info.url;v.addEventListener('loadedmetadata',sync,{once:true});sync();return;}if(info.state==='error'){done=true;return;}if(attempt++<120)setTimeout(poll,2500)}).catch(()=>{if(attempt++<25)setTimeout(poll,3000)})};
 fetch('/api/showtime/video/'+encodeURIComponent(state.chart.id),{method:'POST'}).then(()=>poll()).catch(()=>{});
 const observer=setInterval(()=>{if(!stage?.isConnected||!playing){clearInterval(observer);v.pause();return;}if(v.src)sync();},1200);
}
function drawNeedle(){
 if(!needleCtx||!needleCanvas)return;const g=needleCtx,w=needleCanvas.width,h=needleCanvas.height;g.clearRect(0,0,w,h);
 const t=by('gameAudio')?.currentTime||0,notes=state.chart?.notes||[];
 const target=notes.find(n=>!n.talkie&&n.start<=t&&n.end>=t);
 const player=state.players?.[0],pitch=player?.mid;
 g.fillStyle='rgba(6,11,29,.68)';g.fillRect(0,0,w,h);
 for(let k=0;k<7;k++){let y=15+k*15;g.strokeStyle=k===3?'rgba(255,192,242,.70)':'rgba(136,155,209,.23)';g.lineWidth=k===3?3:1;g.beginPath();g.moveTo(0,y);g.lineTo(w,y);g.stroke();}
 const scale=130,cursor=w*.24,timeScale=150;
 for(let n of notes){if(n.end<t-1.4||n.start>t+4.7||n.talkie)continue;let y=h*.51-(n.pitch-(target?.pitch??n.pitch))*9;y=limit(y,8,h-12);
 const x=cursor+(n.start-t)*timeScale,xe=cursor+(n.end-t)*timeScale;
 g.fillStyle=n===target?'#8deaff':'#24b8ee';g.shadowColor='#25bfff';g.shadowBlur=12;g.beginPath();g.roundRect(x,y-5,Math.max(3,xe-x),10,5);g.fill();g.shadowBlur=0;}
 g.strokeStyle='#fff4bb';g.lineWidth=3;g.beginPath();g.moveTo(cursor,0);g.lineTo(cursor,h);g.stroke();
 let tip='CANTE PARA CENTRALIZAR';if(target&&Number.isFinite(pitch)){
 const shift=((pitch-target.pitch+6)%12+12)%12-6;const y=limit(h*.51-shift*9,8,h-12);
 g.shadowBlur=20;g.shadowColor='#ffe3a3';g.fillStyle='#ffd985';g.beginPath();g.moveTo(cursor,y-11);g.lineTo(cursor+19,y);g.lineTo(cursor,y+11);g.lineTo(cursor-19,y);g.closePath();g.fill();g.shadowBlur=0;
 tip=Math.abs(shift)<.35?'NO ALVO!':shift<0?'SUBA A VOZ':'DESÇA A VOZ';
 }by('nsNeedleTip').textContent=tip;
}
function animation(t){if(!playing||!stage?.isConnected)return;const dpr=Math.min(2,window.devicePixelRatio||1),w=stage.clientWidth,h=stage.clientHeight;if(w>0&&h>0){if(canvas.width!==Math.ceil(w*dpr)||canvas.height!==Math.ceil(h*dpr)){canvas.width=Math.ceil(w*dpr);canvas.height=Math.ceil(h*dpr)}ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);for(let j=fx.length-1;j>=0;j--){let p=fx[j];p.x+=p.vx;p.y+=p.vy;p.vy+=.045;p.life-=1;ctx.beginPath();ctx.fillStyle=`hsla(${p.hue},100%,75%,${limit(p.life/65,0,1)})`;ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fill();if(p.life<=0)fx.splice(j,1);}}
 if(t-lastTimestamp>120){lastTimestamp=t;let r=round[0];if(r){renderEnergy();const max=Math.max(1,state.chart?.notes?.length||1),sum=round.reduce((v,a)=>v+a.perfect+a.great+a.good,0);const accuracy=sum/max;const st=limit(Math.round(accuracy*5),0,5);stars.textContent='★ '.repeat(st)+'☆ '.repeat(5-st);const rms=limit((state.players[0]?.rms||0)*9,0,1);stage.style.setProperty('--ns-beat',rms.toFixed(3));drawNeedle();round.forEach(updatePlayer);}}
 frameId=requestAnimationFrame(animation);
}
function finish(){if(!playing)return;const r=round[0];if(!r)return;const rows=round.map(q=>({name:q.name,xp:q.xp,perfect:q.perfect,great:q.great,good:q.good,miss:q.miss,best:q.best,accuracy:q.total?Math.round(q.totalAccuracy/q.total*100):0,stars:Math.min(5,Math.round((q.totalAccuracy/Math.max(1,q.total))*5)),score:Math.round(state.players[q.id]?.score||0),achievements:[...q.awards]}));const data=saved();for(let q of round)data[q.name]=(data[q.name]||0)+q.xp;try{localStorage.setItem('neon_showtime_profile_v821',JSON.stringify(data))}catch{}resultsPending=rows;}
function presentResults(){if(!resultsPending)return;const root=by('finishScores');if(!root)return;root.querySelector('.ns-results')?.remove();let wrap=document.createElement('section');wrap.className='ns-results';let title=document.createElement('div');title.className='ns-finish-title';title.textContent='RESULTADO DO SHOW';wrap.appendChild(title);for(let r of resultsPending){let row=document.createElement('div');row.className='ns-finish-card';const name=document.createElement('div');name.className='ns-finish-name';name.textContent=r.name;const score=document.createElement('strong');score.textContent=fmt(r.score)+' PTS';const star=document.createElement('div');star.className='ns-finish-stars';star.textContent='★'.repeat(r.stars)+'☆'.repeat(5-r.stars);const stats=document.createElement('div');stats.className='ns-finish-metrics';for(let t of [`${r.accuracy}% PRECISÃO`,`${r.best}x COMBO`,`+${r.xp} XP`,`${r.perfect} PERFECTS`]){let span=document.createElement('span');span.textContent=t;stats.appendChild(span);}row.append(name,score,star,stats);wrap.appendChild(row)}root.appendChild(wrap);resultsPending=null;}
const nativeScore=scoreFrame;
scoreFrame=function(t,dt){const prePlayers=state.players.map(p=>({attempts:p.attempts,hits:p.hits,score:p.score}));const preIndex=state.lastNote;nativeScore.apply(this,arguments);if(playing){for(let i=0;i<round.length;i++){let p=state.players[i],r=round[i];if(!p||!r)continue;const earned=Math.max(0,p.score-prePlayers[i].score),factor=multiplier(r)*(r.superUntil>performance.now()?2:1);const bonus=earned*(factor-1);if(Number.isFinite(bonus)&&bonus>0){p.score+=bonus;r.scoreBonus+=bonus;}}
 if(preIndex>=0&&preIndex!==state.lastNote)onNote(preIndex,prePlayers);activeNote=state.lastNote;}};
const nativeLyrics=renderLyrics;
renderLyrics=function(t){
 // Original app owns the authoritative complete lyric line; never render separate word rows.
 const oldLast=lastLine;
 nativeLyrics.apply(this,arguments);
 if(!playing)return;
 const el=by('lyricCurrent');if(!el)return;
 const full=(el.textContent||'').trim();
 if(full!==oldLast){lastLine=full;el.classList.remove('ns-line-enter');void el.offsetWidth;el.classList.add('ns-line-enter');
 const arr=(state.chart?.lyric_lines||[]).filter(x=>String(x.text||'').trim());const ix=arr.findIndex(x=>String(x.text||'').trim()===full);
 el.dataset.nsFrom=String(ix>=0?Number(arr[ix].at):t);el.dataset.nsTo=String(ix>=0&&arr[ix+1]?Number(arr[ix+1].at):t+4);
 }
 const from=Number(el.dataset.nsFrom),to=Number(el.dataset.nsTo);
 let progress=Number.isFinite(from)&&Number.isFinite(to)&&to>from?limit(100*(t-from)/(to-from),0,100):0;
 el.style.setProperty('--ns-lyric-progress',progress.toFixed(2)+'%');
};
const nativeBegin=beginSong;beginSong=async function(){const v=await nativeBegin.apply(this,arguments);if(state.playing&&state.chart)mount();return v;};
const nativeStop=stopGame;stopGame=async function(){playing=false;cancelAnimationFrame(frameId);stage?.classList.remove('ns-super-active');return nativeStop.apply(this,arguments)};
const nativeFinish=finishGame;finishGame=async function(){if(state.playing)finish();const v=await nativeFinish.apply(this,arguments);presentResults();return v;};
const gameScreen=by('gameScreen');
if(gameScreen){const syncStage=()=>{if(state.playing && state.chart && !gameScreen.classList.contains('hidden')){if(!gameScreen.querySelector('#nsShowLayer')) mount();}else if(!gameScreen.classList.contains('hidden')){}else if(playing){playing=false;cancelAnimationFrame(frameId);gameScreen.querySelector('#nsShowLayer')?.remove();gameScreen.classList.remove('ns-showtime');}};new MutationObserver(syncStage).observe(gameScreen,{attributes:true,attributeFilter:['class']});by('startGame')?.addEventListener('click',()=>{setTimeout(syncStage,0);setTimeout(syncStage,700);setTimeout(syncStage,2000)});syncStage();}
window.addEventListener('keydown',e=>{if(e.code==='Space'&&!e.repeat&&state.playing&&!/INPUT|TEXTAREA|BUTTON/.test(document.activeElement?.tagName||'')){if(round[0]?.energy>=100){e.preventDefault();activate(0);}}});
})();
