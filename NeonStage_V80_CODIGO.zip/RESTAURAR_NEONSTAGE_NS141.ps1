$ErrorActionPreference = 'Stop'
# Pare o servidor antes de restaurar.
$root = 'C:\Users\freit\Downloads\NeonStage_V80'
$backup = 'C:\Users\freit\Downloads\NeonStage_V80\BACKUP_ANTES_NS141_20261012_192238_403117'
if (!(Test-Path -LiteralPath $backup)) { throw 'Backup nao encontrado.' }
Copy-Item -LiteralPath (Join-Path $backup 'neon_sync_v2.py') -Destination (Join-Path $root 'neon_sync_v2.py') -Force
Copy-Item -LiteralPath (Join-Path $backup 'static\sync14.js') -Destination (Join-Path $root 'static\sync14.js') -Force
Copy-Item -LiteralPath (Join-Path $backup 'static\sync14.html') -Destination (Join-Path $root 'static\sync14.html') -Force
Write-Host 'NS14.1 revertida. Reinicie o NeonStage.' -ForegroundColor Green
