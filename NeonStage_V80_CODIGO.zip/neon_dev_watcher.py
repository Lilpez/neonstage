﻿from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import hashlib
import json
import os

ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"
EXTENSIONS = {".js", ".css", ".html"}

def revision():
    digest = hashlib.sha256()
    paths = [
        p for p in STATIC.rglob("*")
        if p.is_file() and p.suffix.lower() in EXTENSIONS
    ]
    for p in sorted(paths):
        try:
            s = p.stat()
            digest.update(str(p.relative_to(ROOT)).encode())
            digest.update(str(s.st_mtime_ns).encode())
            digest.update(str(s.st_size).encode())
        except OSError:
            pass
    return digest.hexdigest()[:20]

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path.split("?")[0] != "/status":
            self.send_error(404)
            return

        body = json.dumps({
            "ok": True,
            "revision": revision(),
            "mode": "NeonStage Dev Mode"
        }).encode("utf-8")

        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args):
        pass

if __name__ == "__main__":
    server = ThreadingHTTPServer(
        ("127.0.0.1", 8766), Handler
    )
    print("NeonStage Dev Mode: porta 8766", flush=True)
    server.serve_forever()
