(()=>{'use strict';
const $=id=>document.getElementById(id),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
// The main navigation never listens for remote starts; only /palco does.
const isPalco=location.pathname==='/palco';
async function api(url,options={}){const r=await fetch(url,{cache:'no-store',...options});const v=await r.json();if(!r.ok)throw Error(v.error||r.status);return v}
function home(){const scroll=$('scrollContent');if(!scroll||$('ns10Hub'))return;const hero=scroll.querySelector('.hero');const hub=document.createElement('section');hub.id='ns10Hub';hub.dataset.nsPage='home';hub.classList.toggle('ns-dev-visible',location.pathname==='/'||location.pathname==='/inicio');hub.innerHTML='<span class="eyebrow">NEONSTAGE • UMA ENGINE</span><h2>Cante sozinho ou compartilhe o palco.</h2><p>Use a biblioteca sem celular, ou conecte participantes para organizar uma festa pelo telefone. O mesmo motor de voz e pontuação atende os dois modos.</p><div class="ns10-actions"><button id="ns10Solo">CANTAR SOZINHO</button><button id="ns10Party">CONECTAR CELULARES / PARTY</button><button id="ns10Scores">PLACAR GLOBAL</button></div><div id="ns10Leader" style="display:none"></div>';
 (hero?.parentNode||scroll).insertBefore(hub,hero||scroll.firstChild);const syncHome=()=>hub.classList.toggle('ns-dev-visible',location.pathname==='/'||location.pathname==='/inicio');window.addEventListener('popstate',()=>setTimeout(syncHome,0));document.addEventListener('click',()=>setTimeout(syncHome,0),true);
 $('ns10Solo').onclick=()=>{location.href='/biblioteca'};
 $('ns10Party').onclick=()=>window.open('/neonstage-party','_blank','noopener');
 $('ns10Scores').onclick=()=>{let board=$('ns10Leader');board.style.display=board.style.display==='none'?'block':'none';loadBoard()};
 const nav=document.querySelector('.sidebar .nav');if(nav&&!$('ns10NavScores')){const b=document.createElement('button');b.id='ns10NavScores';b.className='navbtn';b.textContent='PLACAR';b.onclick=()=>{history.pushState({},'','/inicio');location.href='/inicio?placar=1'};nav.append(b)}
 if(new URLSearchParams(location.search).has('placar')){$('ns10Leader').style.display='block';loadBoard()}
}
async function loadBoard(){const board=$('ns10Leader');if(!board)return;try{const d=await api('/api/neon10/leaderboard');board.innerHTML='<h3>PLACAR GLOBAL • PONTOS ACUMULADOS</h3>'+(d.players||[]).map((p,i)=>`<div class="ns10-rank"><strong>${i+1}º</strong><span>${esc(p.name)}</span><small>${p.performances} apresentações</small><b>${Number(p.points||0).toLocaleString('pt-BR')}</b></div>`).join('')||'<p>Nenhuma pontuação registrada.</p>'}catch(e){board.textContent='Erro ao carregar placar: '+e.message}}
function stage(){if(!isPalco)return;document.documentElement.classList.add('ns10-palco');
 const title=document.title;document.title='NeonStage | Palco';
 const s=()=>{try{return state}catch{return null}};
 const game=$('gameScreen');
 const soloId=new URLSearchParams(location.search).get('solo');
 if(soloId&&/^[a-zA-Z0-9_-]{1,64}$/.test(soloId)){
   fetch('/api/song/'+encodeURIComponent(soloId)).then(r=>r.json()).then(async song=>{
     if(song?.id&&window.NEON12_START_SOLO)await window.NEON12_START_SOLO(song);
   }).catch(e=>console.warn('Nao foi possivel carregar solo:',e));
 }

 if(game){const obs=new MutationObserver(()=>{});obs.observe(game,{attributes:true,attributeFilter:['class']})}
 // Heartbeat allows Flask to open exactly one /palco tab when the phone starts.
 const ping=()=>fetch('/api/neon10/stage/ping',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({playing:!!s()?.playing})}).catch(()=>{});
 setInterval(ping,1600);ping();
 // Returning to lobby cancels the active Party session first, avoiding forced re-entry.
 const quit=async()=>{try{await api('/api/party/control',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'reset'})})}catch{};try{if(window.NEON_PARTY?.isPlaying?.())await window.NEON_PARTY.stop()}catch{};location.href='/inicio'};
 const bar=document.createElement('aside');bar.id='ns10StageTop';bar.style.cssText='position:fixed;z-index:2147483001;top:12px;left:50%;transform:translateX(-50%);pointer-events:auto;display:none';bar.innerHTML='<button id="ns10Lobby" style="padding:11px 17px;background:#151a2ff5;border:1px solid #89dfe78c;border-radius:11px;color:#fff;font-weight:900;cursor:pointer">SAIR PARA O LOBBY</button>';document.body.append(bar);$('ns10Lobby').onclick=()=>{if(confirm('Encerrar a festa atual e voltar ao lobby?'))quit()};
 setInterval(()=>{bar.style.display=s()?.partyActive&&s()?.playing?'block':'none'},450);
 window.NEON10_RETURN_LOBBY=quit;
}
if(!isPalco){document.addEventListener('click',e=>{
   let card=e.target.closest('.album[data-song]');
   if(card&&!e.target.closest('button, a, input, .ns-add-queue')){
     e.preventDefault();e.stopImmediatePropagation();location.href='/palco?solo='+encodeURIComponent(card.dataset.song);return;
   }
   if(e.target.closest('#startGame')){
     let selected=null;try{selected=state?.selected?.id}catch{}
     if(selected){e.preventDefault();e.stopImmediatePropagation();location.href='/palco?solo='+encodeURIComponent(selected)}
   }
 },true)}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>{home();stage()});else{home();stage()}
})();