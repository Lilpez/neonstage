"""Non-interactive Genius-to-ASR text overlay. Does not modify timing/scoring."""
from pathlib import Path
import copy, datetime, hashlib, json, os, shutil, time
VERSION='v816-20261012a'

def _token(root):
    try:
        from lyrics_verified import _genius_token
        return _genius_token()
    except Exception:return ''

def process(root,song_id,force=False):
    root=Path(root); song=root/'songs'/song_id; f=song/'chart.json'
    if not f.is_file():return {'state':'missing'}
    chart=json.loads(f.read_text(encoding='utf-8'))
    if chart.get('source')=='demo' or not chart.get('notes'):return {'state':'skipped'}
    stamp=song/'genius_overlay_v816.json'
    if not force and stamp.is_file():
        try:
            prev=json.loads(stamp.read_text(encoding='utf-8'))
            if prev.get('version')==VERSION and (prev.get('state')=='done' or time.time()-prev.get('time',0)<3600):return prev
        except Exception:pass
    from neon_auto_genius import lookup
    from neon_text_correction import correct_chart_text
    external=lookup(chart.get('title',''),chart.get('artist',''),chart.get('duration',0),_token(root),root)
    if not external or not external.get('lyric_lines'):
        status={'version':VERSION,'time':time.time(),'state':'unavailable'}
        stamp.write_text(json.dumps(status),encoding='utf-8');return status
    old_signature=[(n.get('start'),n.get('end'),n.get('pitch'),n.get('phrase'),n.get('talkie')) for n in chart['notes']]
    # Restore original ASR on a throwaway copy. ASR notes retain immutable asr_original.
    working=copy.deepcopy(chart)
    for n in working['notes']:
        n['text']=n.get('asr_original',n.get('text',''))
    updated,stats=correct_chart_text(working,external['lyric_lines'])
    from neon_v815_refine import refine as recover
    stats.update(recover(updated,external['lyric_lines']))
    from neon_v816_refine import refine as split
    stats.update(split(updated,external['lyric_lines']))
    new_signature=[(n.get('start'),n.get('end'),n.get('pitch'),n.get('phrase'),n.get('talkie')) for n in updated['notes']]
    if old_signature!=new_signature:raise RuntimeError('Safeguard: timing or scoring changed')
    updated['lyrics_verified_url']=external.get('lyrics_verified_url','')
    updated['lyrics_overlay_version']=VERSION
    backup=song/('chart_pre_v816_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.json')
    shutil.copy2(f,backup)
    temporary=song/'chart.v816.tmp'
    temporary.write_text(json.dumps(updated,ensure_ascii=False,indent=2),encoding='utf-8')
    os.replace(temporary,f)
    status={'version':VERSION,'time':time.time(),'state':'done','stats':stats,'source':updated['lyrics_verified_url'],'backup':str(backup)}
    stamp.write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding='utf-8')
    return status
