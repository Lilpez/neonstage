(()=>{
'use strict';
if(window.__NS_PARTY_FLOW4__)return;window.__NS_PARTY_FLOW4__=true;
const $=id=>document.getElementById(id);
let lastKey='',committing=false,lastPhase='',knownFailure=null;
const json=(url,body)=>fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),cache:'no-store'}).then(async r=>{const d=await r.json();if(!r.ok)throw Error(d.error||'Falha no Party');return d});
function gameActive(){return window.NEON_PARTY?.isPlaying?.()===true}
function getScore(){try{return Math.round(state.players?.[0]?.score||0)}catch{return 0}}
function getTime(){return $('gameAudio')?.currentTime||0}
function currentKey(s){return s.phase==='singing'?String(s.position)+'|'+String(s.playback?.song_id||''):''}
function toast(msg){let el=$('nsPartyFlowInfo');if(!el){el=document.createElement('div');el.id='nsPartyFlowInfo';el.style.cssText='position:fixed;z-index:2147483640;bottom:24px;left:50%;transform:translateX(-50%);background:#0b1125f2;color:#fff;border:1px solid #70d8e566;border-radius:15px;padding:13px 20px;font:700 14px system-ui;box-shadow:0 10px 34px #0008';document.body.append(el)}el.textContent=msg;clearTimeout(el._hide);el._hide=setTimeout(()=>el.remove(),4800)}
async function endTurn(reason){
 if(committing)return;committing=true;
 const failed=reason==='failed',skipped=reason==='skip';
 try{
   const score=skipped||failed?getScore():getScore();
   const response=await json('/api/party/control',{action:'complete',score,failed,skipped,score_split:window.NEON_DUET?.split?.()||null});
   if(gameActive()) await window.NEON_PARTY.stop();
   $('ns829Fail')?.classList.add('hidden');
   $('finishOverlay')?.classList.add('hidden');
   lastKey='';
   const singer=response.queue?.[response.position]?.singer;
   const name=response.players?.[singer]?.name||'próximo participante';
   toast(failed?'Você perdeu. Próxima vez: '+name:skipped?'Música pulada. Próxima vez: '+name:'Apresentação encerrada');
 }catch(e){console.error('[Party] Encerramento:',e);toast('Erro ao avançar a festa: '+e.message)}
 finally{committing=false}
}
function makeButton(id,label,onclick){let b=$(id);if(b)return b;b=document.createElement('button');b.id=id;b.textContent=label;b.type='button';b.onclick=onclick;b.style.cssText='padding:11px 13px;border-radius:12px;border:1px solid #ffffff40;background:#11192dcf;color:white;font:800 12px system-ui;cursor:pointer;box-shadow:0 5px 20px #0008';return b}
function refreshButtons(){
 const root=$('ns828Stage');const game=$('gameScreen');
 const parent=root||game;
 if(!parent)return;
 let bar=$('nsPartyFlowBar');if(!bar){bar=document.createElement('div');bar.id='nsPartyFlowBar';bar.style.cssText='position:absolute;top:14px;right:140px;z-index:2147483000;display:flex;gap:8px;pointer-events:auto';parent.append(bar)}
 if(bar.parentNode!==parent)parent.append(bar);
 const party=(()=>{try{return !!state.partyActive}catch{return false}})();
 bar.style.display=gameActive()?'flex':'none';
 const back=makeButton('nsPartyFlowExit','SAIR',()=>{if(!confirm('Encerrar esta apresentação?'))return;if(party)endTurn('skip');else $('exitGame')?.click()});
 const next=makeButton('nsPartyFlowNext','PRÓXIMA',()=>{if(!confirm('Pular esta música e passar para o próximo cantor?'))return;if(party)endTurn('skip');else {const a=$('gameAudio');if(a&&Number.isFinite(a.duration))a.currentTime=Math.max(0,a.duration-.03);else $('exitGame')?.click()}});
 if(!bar.contains(back))bar.append(back);if(!bar.contains(next))bar.append(next);
 next.style.display=party?'':'none';
}
async function tick(){
 refreshButtons();
 if(committing)return;
 try{
  const r=await fetch('/api/party/state',{cache:'no-store'});if(!r.ok)return;
  const s=await r.json(),key=currentKey(s);
  if(s.phase!=='singing'){lastKey='';knownFailure=null;return}
  if(key!==lastKey){lastKey=key;knownFailure=null}
  if(!gameActive())return;
  const fail=$('ns829Fail');
  if(fail&&!fail.classList.contains('hidden')){
    if(knownFailure!==key){knownFailure=key;await endTurn('failed')}
    return;
  }
  // On natural song ending the existing engine sends its own completion.
 }catch(e){if(!tick.warned){console.warn('[Party] Flow status:',e);tick.warned=true}}
}
setInterval(tick,750);tick();
})();