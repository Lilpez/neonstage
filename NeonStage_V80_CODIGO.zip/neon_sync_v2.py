"""NS14 experimental lyric alignment. Writes candidates only; never changes chart.json.

Evidence hierarchy: freshly transcribed vocal stem, then legacy word timing (explicitly
labelled as non-acoustic). Matching does not manufacture missing line timestamps.
"""
from __future__ import annotations

import copy
import difflib
import json
import math
import os
import re
import subprocess
import sys
import threading
import time
import unicodedata
import statistics
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

VERSION = 'ns14.3-sync-video-ocr-20261012'
DISPLAY_LEAD_SECONDS = 0.35  # Visual lyrics are deliberately shown before acoustic onset.
MAX_UNREVIEWED_SHIFT = 1.20  # Seconds: large changes need a human review.
_LOCK = threading.RLock()
_TASKS: dict[str, dict] = {}
_EXECUTOR = ThreadPoolExecutor(max_workers=1, thread_name_prefix='neon-sync-v2')
_ID = re.compile(r'[A-Za-z0-9_-]{1,64}\Z')


def tokens(text: str) -> list[str]:
    ascii_text = ''.join(c for c in unicodedata.normalize('NFKD', str(text).casefold()) if not unicodedata.combining(c))
    return re.findall(r'[a-z0-9]+', ascii_text)


def norm(text: str) -> str:
    return ' '.join(tokens(text))


def similarity(a: str, b: str) -> float:
    aa, bb = tokens(a), tokens(b)
    if not aa or not bb:
        return 0.0
    word_ratio = difflib.SequenceMatcher(None, aa, bb, autojunk=False).ratio()
    char_ratio = difflib.SequenceMatcher(None, ' '.join(aa), ' '.join(bb), autojunk=False).ratio()
    same = sum(1 for x in aa if x in bb)
    return min(1.0, 0.50 * word_ratio + 0.35 * char_ratio + 0.15 * same / max(len(aa), len(bb)))


def verified_lines(chart: dict) -> list[dict]:
    out = []
    for index, line in enumerate(chart.get('lyric_lines') or []):
        if not isinstance(line, dict):
            continue
        text = str(line.get('text') or '').strip()
        if not text or not tokens(text):
            continue
        try:
            original_at = float(line['at'])
        except (ValueError, TypeError, KeyError):
            continue
        if not math.isfinite(original_at):
            continue
        out.append({'index': index, 'text': text, 'old_at': original_at,
                    'source': str(line.get('text_source') or 'unspecified')})
    return out


def select_vocals(song: Path, allow_separation: bool, log) -> tuple[Path, bool]:
    paths = sorted((song / 'separation').rglob('vocals.wav')) if (song / 'separation').is_dir() else []
    paths = [p for p in paths if p.stat().st_size > 1000]
    if paths:
        log('Usando vocal isolado encontrado.'); return max(paths, key=lambda p: p.stat().st_size), True
    audio = next((song / n for n in ('audio.wav', 'audio.mp3', 'audio.flac', 'audio.m4a') if (song / n).is_file()), None)
    if audio is None:
        raise RuntimeError('Arquivo de audio ausente nesta musica.')
    if allow_separation:
        log('Separando vocal com Demucs. Pode demorar alguns minutos...')
        # Results remain in the song folder; no modification to the source audio.
        cmd = [sys.executable, '-m', 'demucs', '--two-stems', 'vocals', '-n', 'htdemucs',
               '--shifts', '1', '-o', str(song / 'separation'), str(audio)]
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
            paths = list((song / 'separation').rglob('vocals.wav'))
            if r.returncode == 0 and paths:
                log('Vocal separado.'); return max(paths, key=lambda p: p.stat().st_size), True
            log('Demucs falhou; prosseguindo com o mix original (qualidade inferior).')
        except (OSError, subprocess.TimeoutExpired):
            log('Demucs indisponivel; usando o mix original.')
    else:
        log('Sem vocal isolado; usando mix original (resultado menos confiavel).')
    return audio, False


def legacy_words(chart: dict) -> list[dict]:
    out = []
    for n in chart.get('notes') or []:
        text = str(n.get('asr_original') or n.get('text') or '').strip()
        try:
            a, b = float(n['start']), float(n['end'])
        except (ValueError, TypeError, KeyError):
            continue
        if text and math.isfinite(a) and math.isfinite(b) and b > a >= 0:
            out.append({'word': text, 'start': a, 'end': b})
    return sorted(out, key=lambda w: (w['start'], w['end']))


def _rms_frames(wav) -> dict:
    """Vocal stem RMS is independent of WhisperX words, but does not determine syllable onset."""
    try:
        import numpy as np
        hop = 640  # 40ms at WhisperX 16k
        a=np.asarray(wav, dtype=np.float32)
        usable=(len(a)//hop)*hop
        if usable<hop: return {}
        bins=np.sqrt(np.mean(a[:usable].reshape(-1,hop)**2,axis=1))
        return {'hop': 0.04, 'rms': bins.tolist()}
    except Exception:
        return {}


def _vocal_support(energy: dict, start: float, end: float) -> dict:
    """Voice energy checks presence, NOT precise onset. Return unknown if insufficient."""
    values = energy.get('rms') or []
    hop = energy.get('hop',0.04)
    if not values: return {'state':'unknown'}
    a=max(0,int((start-0.08)/hop)); b=min(len(values),int((max(start+.22,end)+.1)/hop))
    local_a=max(0,int((start-5)/hop));local_b=min(len(values),int((start+6)/hop))
    local=sorted(values[local_a:local_b]); observed=values[a:b]
    if not observed or len(local)<12: return {'state':'unknown'}
    p85=local[min(len(local)-1,int(.85*(len(local)-1)))]
    p20=local[int(.2*(len(local)-1))]
    threshold=(max(.0004, p85*.35) if p20>=p85*.75
               else max(.0004, p20*1.35, p85*.24))
    active=sum(x>=threshold for x in observed)/len(observed)
    return {'state':'present' if active>=.16 else 'low_energy',
            'active_ratio':round(active,3),'local_threshold':round(threshold,6)}


def acoustic_words(song: Path, chart: dict, log, allow_separation: bool) -> tuple[list[dict], dict, dict]:
    """Fresh transcription + word alignment, requires the existing WhisperX installation."""
    vocal, separated = select_vocals(song, allow_separation, log)
    import whisperx
    import torch
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    lang = str(chart.get('language') or 'pt').lower().split('-')[0]
    if lang in ('unknown', 'auto', 'none'):
        lang = 'pt'
    # Model selection belongs to the AI Python environment, not to the host Flask venv.
    # A laptop GPU can benefit from medium; allow an explicit override for VRAM limits.
    configured = os.getenv('NEONSTAGE_SYNC_WHISPER_MODEL', '').strip().lower()
    if configured and configured not in ('tiny', 'base', 'small', 'medium', 'large-v2', 'large-v3'):
        raise RuntimeError('NEONSTAGE_SYNC_WHISPER_MODEL invalido.')
    model_name = configured or ('medium' if device == 'cuda' else 'small')
    if device != 'cuda':
        log('CUDA nao foi detectado neste Python. Executando em CPU; verifique NEONSTAGE_AI_PYTHON e torch.cuda.is_available().')
    log(f'Reconhecendo voz: WhisperX {model_name} / {device} / idioma {lang}')
    wav = whisperx.load_audio(str(vocal))
    energy = _rms_frames(wav)
    try:
        model = whisperx.load_model(model_name, device, compute_type='float16' if device == 'cuda' else 'int8', language=lang)
    except Exception as exc:
        if device != 'cuda' or model_name == 'small' or configured:
            raise
        log('Modelo medium nao carregou na GPU; tentando small por falta de memoria ou incompatibilidade. '+str(exc)[:100])
        model_name = 'small'
        if hasattr(torch.cuda, 'empty_cache'):
            torch.cuda.empty_cache()
        model = whisperx.load_model('small', device, compute_type='float16', language=lang)
    result = model.transcribe(wav, batch_size=8 if device == 'cuda' else 2)
    segments = result.get('segments') or []
    del model
    if device == 'cuda':
        torch.cuda.empty_cache()
    log('Refinando os limites das palavras com alinhamento acustico...')
    aligned_ok = False
    try:
        model_a, metadata = whisperx.load_align_model(language_code=lang, device=device)
        aligned = whisperx.align(segments, model_a, metadata, wav, device, return_char_alignments=False)
        segments = aligned.get('segments') or segments
        aligned_ok = True
        del model_a
        if device == 'cuda':
            torch.cuda.empty_cache()
    except Exception as e:
        log('Alinhamento acustico indisponivel: ' + str(e)[:110])
    words = []
    for seg in segments:
        for item in seg.get('words') or []:
            try:
                a, b = float(item['start']), float(item['end'])
            except (KeyError, ValueError, TypeError):
                continue
            if not (math.isfinite(a) and math.isfinite(b) and b > a >= 0):
                continue
            txt = str(item.get('word') or '').strip()
            if tokens(txt):
                words.append({'word': txt, 'start': round(a, 3), 'end': round(b, 3)})
    # No proportional synthetic timings if the acoustic alignment didn't output words.
    words.sort(key=lambda w: (w['start'], w['end']))
    return words, {'method': 'whisperx_word_aligned' if aligned_ok else 'whisperx_segment_words',
                   'input': 'demucs_vocals' if separated else 'full_mix',
                   'device': device, 'asr_model': model_name, 'source_audio': vocal.name,
                   'acoustic': aligned_ok, 'cuda_available': device == 'cuda'}, energy


def align_lines(lines: list[dict], words: list[dict], log=lambda _: None) -> list[dict]:
    """Global monotonic fuzzy match with skip-lines and skip-ASR evidence.

    No line is forced to match. Retains old timings when evidence is weak.
    """
    n = min(len(words), 4500)
    words = words[:n]
    line_n = len(lines)
    if not n or not line_n:
        return [{'line': dict(line), 'match': None, 'confidence': 0.0, 'state': 'unmatched'} for line in lines]
    dp = [-1e12] * (n + 1)
    dp[0] = 0.0
    traces = []
    normalized = [norm(w['word']) for w in words]
    for i, line in enumerate(lines):
        ref = tokens(line['text'])
        k = len(ref)
        nextdp = [v - 0.58 for v in dp]  # Skip a lyric line; no hallucinated matching.
        pointers = [(j, None) for j in range(n + 1)]
        prefixscore, prefixpos = [-1e12]*(n+1), [0]*(n+1)
        best, bestpos = -1e12, 0
        for j in range(n+1):
            score = dp[j] + 0.018 * j
            if score > best:
                best, bestpos = score, j
            prefixscore[j], prefixpos[j] = best, bestpos
        min_size = max(1, k - max(3, math.ceil(k*0.45)))
        max_size = min(32, k + max(4, math.ceil(k*0.5)))
        for start in range(n):
            if prefixscore[start] < -1e11:
                continue
            for stop in range(start + min_size, min(n, start + max_size) + 1):
                text = ' '.join(normalized[start:stop])
                sim = similarity(line['text'], text)
                if sim < 0.57:
                    continue
                proximity = min(0.24, 0.007 * abs(words[start]['start'] - line['old_at']))
                # Explicit global ordering: loops/refrains cannot reuse earlier words.
                score = prefixscore[start] - 0.018 * start + 1.5 * sim - proximity
                if score > nextdp[stop]:
                    nextdp[stop] = score
                    pointers[stop] = (prefixpos[start], (start, stop, round(sim, 4)))
        traces.append(pointers)
        dp = nextdp
        if i % 10 == 0:
            log(f'Associando versos: {i+1}/{line_n}')
    cursor = max(range(n+1), key=lambda j: dp[j])
    matches = []
    for i in range(line_n-1, -1, -1):
        previous, found = traces[i][cursor]
        matches.append(found)
        cursor = previous
    matches.reverse()
    out = []
    for line, match in zip(lines, matches):
        if match is None:
            out.append({'line': dict(line), 'match': None, 'confidence': 0.0, 'state': 'unmatched'})
            continue
        start, stop, score = match
        exact_words = set(tokens(line['text'])) & set(tokens(' '.join(normalized[start:stop])))
        # A short phrase must match extremely well; longer phrases need at least 2 anchors.
        strong = score >= (0.87 if len(tokens(line['text'])) <= 3 else 0.73) and len(exact_words) >= (1 if len(tokens(line['text'])) <= 3 else 2)
        out.append({'line': dict(line), 'match': {'start': start, 'stop': stop},
                    'confidence': round(score, 3), 'state': 'aligned' if strong else 'review'})
    return out


def tally(report: dict) -> None:
    states=('aligned','validated_unchanged','review','unmatched','review_order',
            'review_boundary','review_large_shift','review_uncertain','review_audio',
            'review_shift','review_ctc','diagnostic_match','pending_firstpass')
    report['status_counts']={x:sum(1 for r in report['lines'] if r['status']==x) for x in states}
    validated=report['status_counts']['aligned']+report['status_counts']['validated_unchanged']
    report['coverage']=round(validated/max(1,report['reference_lines']),4)
    report['review_required']=report['reference_lines']-validated
    report['changed_lines']=report['status_counts']['aligned']
    report['validated_unchanged']=report['status_counts']['validated_unchanged']


def apply_firstpass_evidence(chart: dict, candidate: dict, report: dict, energy: dict, ref: dict|None=None):
    """Check ASR, local vocal energy and optional karaoke caption cross-check.

    Never assert that an RMS envelope measures exact word onset. New positions only
    admitted with word evidence AND independent consistent karaoke captions;
    otherwise existing lyric times are preserved for a user's review.
    """
    line_map={x['index']:x for x in (ref or {}).get('lines',[])}
    ref_consistent=bool((ref or {}).get('reference_compatible')) and not bool((ref or {}).get('visual_reference_only'))
    lead=DISPLAY_LEAD_SECONDS
    stats={'word_matches':0,'voice_present':0,'reference_correlated':0,'changed':0}
    for row in report['lines']:
        if row['status'] not in ('pending_firstpass','review_large_shift'):
            continue
        detected=row['detected_at'];end=row['detected_end']
        if detected is None or end is None:
            row['status']='review';continue
        voice=_vocal_support(energy,float(detected),float(end))
        row['vocal_activity']=voice
        if voice['state']=='present':stats['voice_present']+=1
        row['acoustic_at']=round(float(detected),3)
        suggested=round(max(0,float(detected)-lead),3)
        row['asr_suggested_display_at']=suggested
        drift=round(suggested-row['old_at'],3)
        if row['status']=='review_large_shift' or abs(drift)>MAX_UNREVIEWED_SHIFT:
            row['status']='review_large_shift';continue
        stats['word_matches']+=1
        if voice['state']!='present':
            row['status']='review_audio';continue
        if row['confidence']<.78:
            row['status']='review';continue
        linked=line_map.get(row['index'])
        if linked:
            row['karaoke_reference_at']=linked['reference_at']
            row['karaoke_reference_similarity']=linked['similarity']
        # Proposing a shift from two different recordings without verifying their
        # offset can corrupt a chart. Permit only near-existing changes corroborated
        # by stable, captioned reference; all other changes require user review.
        if abs(drift)<=.10:
            row['status']='validated_unchanged'
            continue
        if not ref_consistent or not linked:
            row['status']='review_shift'
            continue
        ref_offset=float(ref['reference_offset_seconds'])
        independent_est=linked['reference_at']-ref_offset
        # Reference caption cue usually leads vocal audio by an unknown amount.
        # Only a CLOSE match to the candidate display position is corroboration.
        if linked['similarity']<.87 or abs(independent_est-suggested)>.38 or abs(drift)>.7:
            row['status']='review_shift';continue
        ix=row['index'];out=candidate['lyric_lines']
        before=float(out[ix-1].get('at') or 0) if ix else -1e9
        after=float(out[ix+1].get('at') or 0) if ix+1<len(out) else 1e9
        if suggested<before-0.005 or suggested>after+0.005:
            row['status']='review_order';continue
        out[ix]['at']=suggested
        out[ix]['sync142_acoustic_at']=row['acoustic_at']
        out[ix]['sync14_candidate_source']='asr_vocal_and_reference'
        row.update(status='aligned',candidate_at=suggested,delta_seconds=drift)
        stats['reference_correlated']+=1
        stats['changed']+=1
    report['first_pass_validation']=stats
    report['alignment_method']='whisperx_firstpass_with_vocal_energy'
    report['reference_evidence']={k:v for k,v in (ref or {}).items() if k!='lines'} if ref else None
    report['reference_matches']=len(line_map)
    tally(report)


def build_candidate(chart: dict, words: list[dict], evidence: dict, log=lambda _: None) -> tuple[dict, dict]:
    reference = verified_lines(chart)
    if not reference:
        raise ValueError('Esta musica nao tem lyric_lines. Gere/verifique a letra antes do Sync V2.')
    results = align_lines(reference, words, log)
    candidate = copy.deepcopy(chart)
    report_lines = []
    is_acoustic = evidence.get('acoustic') is True
    for r in results:
        line, match = r['line'], r['match']
        detected = words[match['start']]['start'] if match is not None else None
        detected_end = words[match['stop']-1]['end'] if match is not None else None
        state = r['state']
        if state == 'aligned':
            # Already acoustically aligned by the first WhisperX pass. A separate CTC
            # pass failed on its artificial window borders in NS14.1.
            state = 'pending_firstpass' if is_acoustic else 'diagnostic_match'
            if abs(float(detected)-DISPLAY_LEAD_SECONDS-line['old_at']) > MAX_UNREVIEWED_SHIFT:
                state = 'review_large_shift'
        report_lines.append({
            'index': line['index'], 'text': line['text'], 'old_at': line['old_at'],
            'candidate_at': line['old_at'], 'detected_at': detected,
            'detected_end': detected_end,
            'asr_suggested_display_at': round(max(0, float(detected)-DISPLAY_LEAD_SECONDS),3) if detected is not None else None,
            'delta_seconds': 0.0, 'confidence': r['confidence'],
            'status': state, 'text_source': line['source']
        })
    candidate['sync_v2'] = {
        'version': VERSION, 'candidate_only': True, 'evidence': evidence,
        'notes_preserved': True, 'display_lead_seconds': DISPLAY_LEAD_SECONDS,
        'generated_at': datetime.now(timezone.utc).isoformat()
    }
    report = {
        'version': VERSION, 'candidate_only': True, 'title': chart.get('title'),
        'artist': chart.get('artist'), 'evidence': evidence,
        'reference_lines': len(reference), 'word_evidence': len(words),
        'display_lead_seconds': DISPLAY_LEAD_SECONDS, 'lines': report_lines,
        'notes_unchanged': len(chart.get('notes') or []),
        'warning': 'Primeiro alinhamento WhisperX + evidencia de atividade vocal. Atividade nao prova inicio fonetico; candidatos requerem revisao.'
    }
    tally(report)
    assert candidate['notes'] == chart['notes']
    assert [x.get('text') for x in candidate['lyric_lines']] == [x.get('text') for x in chart['lyric_lines']]
    return candidate, report


def _extract_ctc_words(seg: dict, win_start: float, win_end: float, reference: str, detected: float) -> tuple[str, list[dict]]:
    """Check the CTC output and flag its common artificial-window failure."""
    items = []
    for w in seg.get('words') or []:
        try:
            start, end = float(w['start']), float(w['end'])
        except (ValueError, TypeError, KeyError):
            continue
        if math.isfinite(start) and math.isfinite(end) and end > start >= 0:
            items.append({'word': str(w.get('word') or ''), 'start': round(start, 3), 'end': round(end, 3)})
    if not items:
        return 'review_ctc', []
    coverage = len(items) / max(1, len(tokens(reference)))
    if coverage < 0.75 or similarity(reference, ' '.join(w['word'] for w in items)) < 0.75:
        return 'review_ctc', items
    if any(items[i]['start'] < items[i-1]['start']-0.02 for i in range(1,len(items))):
        return 'review_ctc', items
    # The NS14 report placed starts exactly at detected-0.300 across most lines.
    # Such matches have no acoustic onset evidence: they are pegged to the pad.
    if items[0]['start'] <= win_start + 0.085:
        return 'review_boundary', items
    if items[-1]['end'] >= win_end - 0.035:
        return 'review_boundary', items
    if abs(items[0]['start'] - detected) > 0.75:
        return 'review_ctc', items
    return 'aligned', items


def refine_with_forced_alignment(song: Path, candidate: dict, report: dict, log=lambda _: None):
    """Guarded acoustic alignment: retry clipped windows; never trust their borders.

    Chart timestamps are *display* times, which intentionally lead acoustic starts.
    Uncertain phrases remain unchanged and are never marked as confirmed.
    """
    evidence = report['evidence']
    if evidence.get('method') != 'whisperx_word_aligned' or not evidence.get('acoustic'):
        report['forced_alignment'] = 'skipped: no independently aligned acoustic words'
        for row in report['lines']:
            if row['status'] == 'pending_ctc':
                row['status'] = 'review_ctc'
        tally(report)
        return
    try:
        import whisperx
        import torch
        vocals, _ = select_vocals(song, False, lambda _: None)
        wave = whisperx.load_audio(str(vocals))
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
        lang = str(candidate.get('language') or 'pt').lower().split('-')[0]
        model, metadata = whisperx.load_align_model(language_code=lang, device=device)
        eligible = []
        for row in report['lines']:
            if row['status'] != 'pending_ctc' or row['detected_at'] is None or row['detected_end'] is None:
                continue
            start, stop = float(row['detected_at']), float(row['detected_end'])
            if stop <= start or stop-start > 18:
                row['status'] = 'review_uncertain'
                continue
            eligible.append(row)
        attempts = 0
        accepted = 0
        rejected_border = 0
        # Initial padding is sufficient for obvious cases. Only near-window starts
        # are retried with a wider left context to avoid expensive work.
        remaining = list(eligible)
        for left_pad, right_pad in ((0.30, 0.35), (1.00, 0.75)):
            if not remaining:
                break
            requests = []
            for row in remaining:
                start, stop = float(row['detected_at']), float(row['detected_end'])
                requests.append({'start': max(0., start-left_pad), 'end': stop+right_pad, 'text': row['text']})
            log(f'CTC: validando {len(requests)} versos (margem anterior={left_pad:.2f}s)')
            output = whisperx.align(requests, model, metadata, wave, device, return_char_alignments=False)
            segments = output.get('segments') or []
            retry = []
            for position, row in enumerate(remaining):
                attempts += 1
                segment = segments[position] if position < len(segments) else {}
                state, aligned_words = _extract_ctc_words(
                    segment, requests[position]['start'], requests[position]['end'],
                    row['text'], float(row['detected_at']))
                if state == 'review_boundary' and left_pad < 0.9:
                    retry.append(row)
                    row['ctc_status'] = 'retry_wider_window'
                    continue
                if state != 'aligned':
                    if state == 'review_boundary':
                        rejected_border += 1
                    row['status'] = row['ctc_status'] = state
                    continue
                acoustic_start = float(aligned_words[0]['start'])
                display_start = round(max(0.0, acoustic_start-DISPLAY_LEAD_SECONDS), 3)
                if abs(display_start-float(row['old_at'])) > MAX_UNREVIEWED_SHIFT:
                    row['status'] = row['ctc_status'] = 'review_large_shift'
                    row['acoustic_suggested_at'] = acoustic_start
                    continue
                ix = row['index']
                # Check chronological ordering against all original lines (including
                # empty/hidden lines). Rejections never modify candidate lyric times.
                lyric_lines = candidate['lyric_lines']
                before = float(lyric_lines[ix-1].get('at') or 0) if ix else -1e9
                after = float(lyric_lines[ix+1].get('at') or 0) if ix+1<len(lyric_lines) else 1e9
                if display_start < before-0.005 or display_start > after+0.005:
                    row['status'] = row['ctc_status'] = 'review_order'
                    continue
                lyric_lines[ix]['at'] = display_start
                lyric_lines[ix]['sync14_words'] = aligned_words
                lyric_lines[ix]['sync141_acoustic_at'] = round(acoustic_start,3)
                lyric_lines[ix]['sync141_display_lead'] = DISPLAY_LEAD_SECONDS
                lyric_lines[ix]['sync14_candidate_source'] = 'whisperx_ctc_verified'
                lyric_lines[ix]['sync14_candidate_confidence'] = row['confidence']
                row['candidate_at'] = display_start
                row['acoustic_at'] = round(acoustic_start,3)
                row['delta_seconds'] = round(display_start-row['old_at'],3)
                row['ctc_word_coverage'] = round(len(aligned_words)/max(1,len(tokens(row['text']))),3)
                row['ctc_status'] = 'confirmed'
                row['status'] = 'aligned'
                row['acoustic_words'] = aligned_words
                accepted += 1
            remaining = retry
        # CTC can succeed on a phrase and still conflict with a neighbor updated
        # later in the batch. Revalidate all lines after both passes.
        out_lines = candidate['lyric_lines']
        for i in range(1, len(out_lines)):
            if float(out_lines[i].get('at') or 0) >= float(out_lines[i-1].get('at') or 0):
                continue
            for ix in (i, i-1):
                row = next((r for r in report['lines'] if r['index']==ix and r['status']=='aligned'),None)
                if row is None:
                    continue
                out_lines[ix]['at'] = row['old_at']
                for key in ('sync14_words','sync141_acoustic_at','sync141_display_lead',
                            'sync14_candidate_source','sync14_candidate_confidence'):
                    out_lines[ix].pop(key,None)
                row['status'] = row['ctc_status'] = 'review_order'
                row['candidate_at'] = row['old_at']
                row['delta_seconds'] = 0.0
                accepted -= 1
        report['forced_alignment'] = {'attempted_windows': attempts,
             'eligible_phrases': len(eligible), 'applied': accepted,
             'border_rejections': rejected_border,
             'second_pass': attempts > len(eligible), 'device': device}
        tally(report)
        del model
        if device == 'cuda':
            torch.cuda.empty_cache()
    except Exception as exc:
        report['forced_alignment'] = 'unavailable: '+str(exc)[:160]
        for row in report['lines']:
            if row['status'] == 'pending_ctc':
                row['status'] = 'review_ctc'
        tally(report)
        log('CTC indisponivel; chart candidato preserva os tempos anteriores.')


def process_song(song: Path, mode='acoustic', separate=True, log=lambda _: None) -> dict:
    original = song / 'chart.json'
    if not original.is_file():
        raise RuntimeError('Chart original nao encontrado.')
    chart = json.loads(original.read_text(encoding='utf-8'))
    energy={}
    if mode == 'quick':
        words = legacy_words(chart)
        evidence = {'method': 'legacy_asr_note_timing', 'input': 'existing_chart',
                    'acoustic': False, 'warning': 'Modo rapido NAO e novo alinhamento acustico.'}
        log('Usando tempos ASR do chart existente (modo comparacao).')
    elif mode == 'acoustic':
        words, evidence, energy = acoustic_words(song, chart, log, allow_separation=separate)
        if len(words) < 5:
            raise RuntimeError('WhisperX nao retornou palavras suficientes. Chart original preservado.')
    else:
        raise ValueError('Modo invalido.')
    if not words:
        raise RuntimeError('Sem palavras reconhecidas. Chart original preservado.')
    candidate, report = build_candidate(chart, words, evidence, log)
    if mode == 'acoustic':
        reference=None
        ref_path=song/'sync14_reference.json'
        if ref_path.is_file():
            try:
                data=json.loads(ref_path.read_text(encoding='utf-8'))
                if data.get('song_id')==str(chart.get('id') or song.name):
                    reference=data.get('reference')
            except (ValueError, OSError):
                pass
        apply_firstpass_evidence(chart,candidate,report,energy,reference)
        report['ctc_second_pass']='disabled: NS14.1 window boundary artifact'
        report['gpu_diagnostic']='CUDA is selected by the configured AI Python, not the Flask venv.' 
    def atomic_json(path: Path, value: dict):
        temp = path.with_name(path.name + '.ns14tmp')
        try:
            temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
            os.replace(temp, path)
        finally:
            temp.unlink(missing_ok=True)
    # Preserve existing NS14 candidate/report the first time NS14.1 runs.
    # These snapshots are read-only history, not game chart files.
    for name in ('chart_v2_candidate.json', 'sync14_report.json'):
        previous = song / name
        snapshot = song / name.replace('.json', '.pre_ns141.json')
        if previous.is_file() and not snapshot.exists():
            import shutil
            shutil.copy2(previous, snapshot)
    atomic_json(song/'chart_v2_candidate.json', candidate)
    atomic_json(song/'sync14_report.json', report)
    return report


def register(app, songs: Path):
    """Only the local PC can run CPU/GPU analysis; never exposed to party phones."""
    from flask import jsonify, request
    from neon_sync_reference import search as search_karaoke, inspect as inspect_karaoke, lookup_lrclib, atomic_json, youtube_url

    @app.get('/sync-lab')
    def ns14_ui():
        if request.remote_addr not in ('127.0.0.1', '::1'):
            return ('Disponivel somente no computador.', 403)
        return app.send_static_file('sync14.html')

    def resolve_song(song_id):
        if not _ID.fullmatch(song_id):
            return None
        path = (songs/song_id).resolve()
        if path.parent != songs.resolve() or not (path/'chart.json').is_file():
            return None
        return path


    def ensure_local_post():
        if request.remote_addr not in ('127.0.0.1','::1'):
            return 'Operacao disponivel apenas no PC.'
        origin=request.headers.get('Origin')
        if origin and origin != request.scheme+'://'+request.host:
            return 'Origem nao autorizada.'
        if request.headers.get('X-NeonStage-Local')!='1':
            return 'Confirmacao local necessaria.'
        return None

    @app.post('/api/sync14/<song_id>/reference/lrc')
    def ns142_reference_lrc(song_id):
        err=ensure_local_post()
        if err:return jsonify(error=err),403
        path=resolve_song(song_id)
        if path is None:return jsonify(error='Musica nao encontrada.'),404
        try:
            chart=json.loads((path/'chart.json').read_text(encoding='utf8'))
            ref=lookup_lrclib(chart)
            if ref:
                atomic_json(path/'sync14_reference.json',{'song_id':str(chart.get('id') or song_id),
                    'reference':ref})
            return jsonify(reference=ref)
        except Exception as exc:
            return jsonify(error=str(exc)[:250]),422

    @app.post('/api/sync14/<song_id>/reference/search')
    def ns142_reference_search(song_id):
        err=ensure_local_post()
        if err:return jsonify(error=err),403
        path=resolve_song(song_id)
        if path is None:return jsonify(error='Musica nao encontrada.'),404
        try:
            chart=json.loads((path/'chart.json').read_text(encoding='utf8'))
            found=search_karaoke(chart)
            return jsonify(results=found)
        except Exception as exc:
            return jsonify(error=str(exc)[:250]),422

    @app.post('/api/sync14/<song_id>/reference/auto')
    def ns142_reference_auto(song_id):
        err=ensure_local_post()
        if err:return jsonify(error=err),403
        path=resolve_song(song_id)
        if path is None:return jsonify(error='Musica nao encontrada.'),404
        try:
            chart=json.loads((path/'chart.json').read_text(encoding='utf8'))
            attempts=[];best=None
            try:
                lr=lookup_lrclib(chart)
                if lr:
                    attempts.append({'url':lr['url'],'status':lr['status']})
                    best=lr
                    if lr.get('reference_compatible'):
                        atomic_json(path/'sync14_reference.json',{'song_id':str(chart.get('id') or song_id),
                            'reference':lr})
                        return jsonify(reference=lr,attempts=attempts)
            except Exception as exc:
                attempts.append({'source':'lrclib','status':str(exc)[:100]})
            results=search_karaoke(chart)
            for item in results[:3]:
                duration=item.get('duration')
                try:
                    diff=abs(float(duration)-float(chart.get('duration') or 0))
                    if diff>max(3.,float(chart.get('duration') or 0)*.02):
                        attempts.append({'url':item['url'],'status':'duracao_diferente'})
                        continue
                except (ValueError,TypeError):
                    pass
                try:
                    proposal=inspect_karaoke(path,item['url'],chart)
                    attempts.append({'url':item['url'],'status':proposal.get('status')})
                    if best is None or (proposal.get('reference_compatible'),proposal.get('matched_ratio',0)) > (best.get('reference_compatible'),best.get('matched_ratio',0)):
                        best=proposal
                    if proposal.get('reference_compatible'):
                        break
                except Exception as exc:
                    attempts.append({'url':item['url'],'status':str(exc)[:100]})
            if best is None:
                return jsonify(reference=None,attempts=attempts,
                    message='Nenhum video com legendas acessiveis e duracao compativel foi identificado.')
            atomic_json(path/'sync14_reference.json',{'song_id':str(chart.get('id') or song_id),
                        'reference':best})
            return jsonify(reference=best,attempts=attempts)
        except Exception as exc:
            return jsonify(error=str(exc)[:240]),422

    @app.post('/api/sync14/<song_id>/reference/preview')
    def ns142_reference_preview(song_id):
        err=ensure_local_post()
        if err:return jsonify(error=err),403
        path=resolve_song(song_id)
        if path is None:return jsonify(error='Musica nao encontrada.'),404
        body=request.get_json(silent=True) or {}
        try:
            safe=youtube_url(body.get('url',''))
            chart=json.loads((path/'chart.json').read_text(encoding='utf8'))
            preview=inspect_karaoke(path,safe,chart)
            # Cached subtitle reference is independent of chart.json.
            atomic_json(path/'sync14_reference.json',{'song_id':str(chart.get('id') or song_id),
                'reference':preview})
            return jsonify(preview)
        except Exception as exc:
            return jsonify(error=str(exc)[:280]),422

    # NS14.3: visual frame analysis, asynchronous and local-only. Never uses VTT.
    import threading
    _visual_jobs={}
    _visual_lock=threading.Lock()

    @app.post('/api/sync14/<song_id>/reference/visual')
    def ns143_visual_start(song_id):
        err=ensure_local_post()
        if err:return jsonify(error=err),403
        song=resolve_song(song_id)
        if song is None:return jsonify(error='Musica nao encontrada.'),404
        body=request.get_json(silent=True) or {}
        try:
            url=youtube_url(body.get('url',''))
            worker=Path(__file__).resolve().parent/'neon_sync_visual.py'
            ocr_python=Path(__file__).resolve().parent/'.ns143_ocr'/'Scripts'/'python.exe'
            if not worker.is_file():raise ValueError('Worker NS14.3 nao encontrado.')
            if not ocr_python.is_file():
                raise ValueError('OCR nao instalado. Rode CONFIGURAR_NEONSTAGE_OCR_NS143.ps1 na pasta NeonStage_V80.')
            with _visual_lock:
                current=_visual_jobs.get(song_id,{})
                if current.get('state')=='running':return jsonify(error='Ja existe uma analise visual nesta musica.'),409
                state={'state':'running','stage':'Iniciando leitura do video...','url':url}
                _visual_jobs[song_id]=state
            def run_visual():
                statefile=song/'.ns143_visual_status.json'
                try:
                    statefile.unlink(missing_ok=True)
                    cmd=[str(ocr_python),str(worker),str(song/'chart.json'),url,
                         str(song/'sync14_visual_reference.json'),str(statefile)]
                    run=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=900)
                    if run.returncode:
                        raise RuntimeError((run.stderr or run.stdout or 'Falha na leitura OCR')[-700:])
                    with _visual_lock:
                        state.update(state='done',stage='Leitura visual concluida')
                except Exception as exc:
                    with _visual_lock:
                        state.update(state='error',error=str(exc)[-650:],stage='Falha no OCR')
                finally:
                    statefile.unlink(missing_ok=True)
            threading.Thread(target=run_visual,daemon=True,name='NS143-Visual-OCR').start()
            return jsonify(state='running',message='OCR visual em andamento')
        except (ValueError,RuntimeError) as exc:
            return jsonify(error=str(exc)),422

    @app.get('/api/sync14/<song_id>/reference/visual/status')
    def ns143_visual_status(song_id):
        if request.remote_addr not in ('127.0.0.1','::1'):return jsonify(error='Somente no PC'),403
        song=resolve_song(song_id)
        if song is None:return jsonify(error='Musica nao encontrada.'),404
        with _visual_lock: state=dict(_visual_jobs.get(song_id) or {})
        if state.get('state')=='running':
            f=song/'.ns143_visual_status.json'
            try:state['stage']=json.loads(f.read_text(encoding='utf8')).get('stage') or state['stage']
            except Exception:pass
        if not state:
            state={'state':'idle'}
        return jsonify(state)

    @app.get('/api/sync14/<song_id>/reference/visual')
    def ns143_visual_result(song_id):
        if request.remote_addr not in ('127.0.0.1','::1'):return jsonify(error='Somente no PC'),403
        song=resolve_song(song_id)
        if song is None:return jsonify(error='Musica nao encontrada.'),404
        file=song/'sync14_visual_reference.json'
        if not file.is_file():return jsonify(reference=None)
        try:
            document=json.loads(file.read_text(encoding='utf8'))
            if document.get('song_id')!=song_id:return jsonify(reference=None)
            return jsonify(reference=document.get('reference'))
        except (ValueError,TypeError):return jsonify(reference=None)

    @app.get('/api/sync14/<song_id>/reference')
    def ns142_reference_current(song_id):
        if request.remote_addr not in ('127.0.0.1','::1'):
            return jsonify(error='Apenas no PC'),403
        path=resolve_song(song_id)
        if path is None:return jsonify(error='Musica nao encontrada.'),404
        file=path/'sync14_reference.json'
        if not file.is_file():return jsonify(reference=None)
        try:
            data=json.loads(file.read_text(encoding='utf8'))
            if data.get('song_id')!=song_id:return jsonify(reference=None)
            return jsonify(reference=data.get('reference'))
        except Exception:
            return jsonify(reference=None)

    @app.get('/api/sync14/environment')
    def ns142_environment():
        if request.remote_addr not in ('127.0.0.1','::1'):
            return jsonify(error='Apenas no PC'),403
        python_path=os.getenv('NEONSTAGE_AI_PYTHON',sys.executable)
        snippet="import json,sys;import torch;print(json.dumps({'python':sys.executable,'torch':torch.__version__,'cuda':torch.cuda.is_available(),'gpu':torch.cuda.get_device_name(0) if torch.cuda.is_available() else None}))"
        try:
            r=subprocess.run([python_path,'-c',snippet],capture_output=True,text=True,encoding='utf8',errors='replace',timeout=15)
            if r.returncode:return jsonify(python=python_path,cuda=False,error=r.stderr[-300:])
            return jsonify(json.loads(r.stdout.strip().splitlines()[-1]))
        except Exception as exc:
            return jsonify(python=python_path,cuda=False,error=str(exc)[:200])

    @app.post('/api/sync14/<song_id>/run')
    def ns14_run(song_id):
        if request.remote_addr not in ('127.0.0.1', '::1'):
            return jsonify(error='Operacao disponivel apenas no PC.'), 403
        origin = request.headers.get('Origin')
        if origin and origin != request.scheme+'://'+request.host:
            return jsonify(error='Origem nao autorizada'), 403
        if request.headers.get('X-NeonStage-Local') != '1':
            return jsonify(error='Confirmacao local necessaria'), 403
        path = resolve_song(song_id)
        if path is None:
            return jsonify(error='Musica nao encontrada.'), 404
        params = request.get_json(silent=True) or {}
        mode = params.get('mode','acoustic')
        if mode not in ('quick', 'acoustic'):
            return jsonify(error='Modo invalido.'), 400
        with _LOCK:
            if any(t['state'] in ('queued','running') for t in _TASKS.values()):
                return jsonify(error='A analise anterior ainda esta em andamento.'), 409
            _TASKS[song_id] = {'state': 'queued', 'stage': 'Na fila', 'started': time.time(), 'error': None}
        def work():
            def log(msg):
                with _LOCK:
                    if song_id in _TASKS:
                        _TASKS[song_id]['stage'] = str(msg)[:250]
            with _LOCK:
                _TASKS[song_id]['state'] = 'running'
            try:
                if mode == 'acoustic':
                    # Reuse the same Python environment as analyze.py (often a
                    # separate CUDA/WhisperX venv). Keep GPU work out of Flask.
                    ai_python = os.getenv('NEONSTAGE_AI_PYTHON', sys.executable)
                    cmd = [ai_python, str(Path(__file__).resolve()), '--run-song',
                           str(path), '--mode', mode]
                    if bool(params.get('separate',True)):
                        cmd.append('--separate')
                    output=[]
                    proc=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                                          text=True,encoding='utf-8',errors='replace',bufsize=1)
                    def read_output():
                        for message in proc.stdout:
                            message=message.strip()
                            if message:
                                output.append(message)
                                if len(output)>25:output.pop(0)
                                log(message.replace('STAGE:', '',1).strip())
                    reader=threading.Thread(target=read_output,daemon=True)
                    reader.start()
                    try:
                        code=proc.wait(timeout=2700)
                    except subprocess.TimeoutExpired:
                        proc.kill();proc.wait();raise RuntimeError('Analise excedeu 45 minutos.')
                    reader.join(timeout=3)
                    if code!=0:
                        raise RuntimeError('Falha no alinhamento: '+' | '.join(output[-4:])[-620:])
                    report=json.loads((path/'sync14_report.json').read_text(encoding='utf-8'))
                else:
                    report = process_song(path,mode=mode,separate=False,log=log)
                with _LOCK:
                    _TASKS[song_id].update(state='done',stage='Candidato pronto',coverage=report['coverage'])
            except Exception as exc:
                with _LOCK:
                    _TASKS[song_id].update(state='error',error=str(exc)[:850],stage='Falha de analise')
        _EXECUTOR.submit(work)
        return jsonify(ok=True, state='queued'), 202

    @app.get('/api/sync14/<song_id>/status')
    def ns14_status(song_id):
        if request.remote_addr not in ('127.0.0.1', '::1'):
            return jsonify(error='Apenas no PC'), 403
        if resolve_song(song_id) is None:
            return jsonify(error='Musica nao encontrada.'), 404
        with _LOCK:
            state = dict(_TASKS.get(song_id) or {})
        if not state:
            state = {'state': 'done' if (songs/song_id/'sync14_report.json').exists() else 'idle'}
        return jsonify(state)

    @app.get('/api/sync14/<song_id>/report')
    def ns14_report(song_id):
        if request.remote_addr not in ('127.0.0.1', '::1'):
            return jsonify(error='Apenas no PC'), 403
        path = resolve_song(song_id)
        if path is None:
            return jsonify(error='Musica nao encontrada.'), 404
        f = path/'sync14_report.json'
        if not f.is_file():
            return jsonify(error='Execute o Sync V2 antes de abrir o relatorio.'), 404
        return jsonify(json.loads(f.read_text(encoding='utf-8')))


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description='NeonStage NS14 Sync Lab (experimental, read-only chart)')
    parser.add_argument('--run-song', type=Path, required=True)
    parser.add_argument('--mode', choices=['acoustic','quick'], default='acoustic')
    parser.add_argument('--separate', action='store_true')
    args=parser.parse_args()
    result=process_song(args.run_song,mode=args.mode,separate=args.separate,
                        log=lambda msg: print('STAGE:',msg,flush=True))
    print('STAGE: Cobertura com evidencias:',str(result['coverage']),flush=True)
