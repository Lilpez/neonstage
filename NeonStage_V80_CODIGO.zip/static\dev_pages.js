(() => {
 'use strict';
 const pageFromPath={"/":"home","/inicio":"home","/descobrir":"search","/biblioteca":"library","/multiplayer":"multiplayer","/configuracoes":"settings","/cantar":"sing"};
 const paths={home:"/inicio",search:"/descobrir",library:"/biblioteca",multiplayer:"/multiplayer",settings:"/configuracoes",sing:"/cantar"};
 const labels={home:"INÍCIO",search:"DESCOBRIR",library:"BIBLIOTECA",multiplayer:"MULTIPLAYER",settings:"CONFIGURAÇÕES",sing:"CANTAR"};
 const scroller=document.getElementById('scrollContent');if(!scroller)return;
 // Preserve existing layout; separate each direct child into one screen.
 const nodes=[...scroller.children];
 for(const el of nodes){const id=el.id;el.dataset.nsPage=id==='searchSection'?'search':id==='librarySection'?'library':id==='multiplayerSection'?'multiplayer':id==='settingsSection'?'settings':id==='singSection'?'sing':'home';}
 function show(page,push=true){if(!paths[page])page='home';document.body.classList.add('ns-dev-pages');for(const el of nodes)el.classList.toggle('ns-dev-visible',el.dataset.nsPage===page);document.querySelectorAll('.navbtn').forEach(b=>b.classList.toggle('active',b.dataset.nav===page));const crumb=document.getElementById('crumb');if(crumb)crumb.textContent=labels[page];scroller.scrollTop=0;if(push&&location.pathname!==paths[page])history.pushState({neonPage:page},'',paths[page]);}
 document.addEventListener('click',e=>{const btn=e.target.closest('[data-nav]');if(btn&&btn.classList.contains('navbtn')){e.stopImmediatePropagation();e.preventDefault();if(btn.dataset.nav==='multiplayer'){window.open('/neonstage-party','_blank','noopener');return;}show(btn.dataset.nav);}},true);
 window.addEventListener('popstate',()=>show(pageFromPath[location.pathname]||'home',false));
 // Compatibility: original app.js calls navigate() from hero and party buttons.
 // Intercept scrollIntoView to keep the new section behavior consistent.
 for(const [id,page] of [['searchSection','search'],['librarySection','library'],['multiplayerSection','multiplayer']]){const el=document.getElementById(id);if(el)el.scrollIntoView=function(){show(page);};}
 show(pageFromPath[location.pathname]||'home',false);
 let stream=null,ctx=null,analyser=null,frame=0;
 const sel=document.getElementById('nsDevMic');const status=document.getElementById('nsDevMicStatus');const meter=document.getElementById('nsDevMicLevel');
 async function listMics(){if(!navigator.mediaDevices?.enumerateDevices)return;const old=sel.value;const list=(await navigator.mediaDevices.enumerateDevices()).filter(d=>d.kind==='audioinput');sel.replaceChildren(new Option('Microfone padrão',''));list.forEach((d,i)=>sel.add(new Option(d.label||`Microfone ${i+1}`,d.deviceId)));if([...sel.options].some(o=>o.value===old))sel.value=old;}
 async function stop(){cancelAnimationFrame(frame);frame=0;stream?.getTracks().forEach(t=>t.stop());stream=null;if(ctx){await ctx.close().catch(()=>{});ctx=null;}meter.style.width='0%';}
 async function start(){await stop();try{stream=await navigator.mediaDevices.getUserMedia({audio:{deviceId:sel.value?{exact:sel.value}:undefined},video:false});ctx=new AudioContext();const source=ctx.createMediaStreamSource(stream);analyser=ctx.createAnalyser();analyser.fftSize=1024;source.connect(analyser);const data=new Float32Array(analyser.fftSize);status.textContent='Microfone ativo — fale para testar o nível de entrada.';function loop(){analyser.getFloatTimeDomainData(data);let s=0;for(const x of data)s+=x*x;const rms=Math.sqrt(s/data.length);meter.style.width=Math.min(100,Math.round(rms*550))+'%';frame=requestAnimationFrame(loop);}loop();await listMics();}catch(e){status.textContent='Não foi possível acessar o microfone: '+e.message;}}
 document.getElementById('nsDevMicPermission').onclick=async()=>{try{const s=await navigator.mediaDevices.getUserMedia({audio:true});s.getTracks().forEach(t=>t.stop());await listMics();status.textContent='Permissão concedida.';}catch(e){status.textContent=e.message;}};
 document.getElementById('nsDevMicTest').onclick=start;
 document.getElementById('nsDevMicStop').onclick=async()=>{await stop();status.textContent='Teste encerrado.';};
 document.getElementById('nsDevStorage').textContent='Local atual: pasta songs do NeonStage (migração pendente)';
 listMics().catch(()=>{});
})();

/* NS_PARTY_EXTERNAL_TAB_V2 */
(()=>{const url='/neonstage-party';const p=document.getElementById('multiplayerSection');if(p){p.innerHTML='<div class="section-head"><div><span class="kicker">FESTA EM UMA NOVA ABA</span><h2>NeonStage Party</h2></div></div><p>O controle da festa funciona em uma aba independente do palco principal.</p><button id="nsOpenParty" class="primary" type="button">Abrir NeonStage Party</button>';document.getElementById('nsOpenParty').onclick=()=>window.open(url,'_blank','noopener');}})();
