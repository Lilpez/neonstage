$ErrorActionPreference = 'Stop'
$root = 'C:\Users\freit\Downloads\NeonStage_V80'
$backup = 'C:\Users\freit\Downloads\NeonStage_V80\BACKUP_ANTES_NS11_20261012_175920_213560'
if (!(Test-Path $backup)) { throw 'Backup nao encontrado' }
Copy-Item -LiteralPath (Join-Path $backup 'app.py') -Destination (Join-Path $root 'app.py') -Force
Copy-Item -LiteralPath (Join-Path $backup 'party_next.py') -Destination (Join-Path $root 'party_next.py') -Force
Copy-Item -LiteralPath (Join-Path $backup 'static\index.html') -Destination (Join-Path $root 'static\index.html') -Force
Copy-Item -LiteralPath (Join-Path $backup 'static\party_next.html') -Destination (Join-Path $root 'static\party_next.html') -Force
Copy-Item -LiteralPath (Join-Path $backup 'static\party_next.js') -Destination (Join-Path $root 'static\party_next.js') -Force
Copy-Item -LiteralPath (Join-Path $backup 'static\party_studio_next.html') -Destination (Join-Path $root 'static\party_studio_next.html') -Force
Copy-Item -LiteralPath (Join-Path $backup 'static\party_studio_next.js') -Destination (Join-Path $root 'static\party_studio_next.js') -Force
Copy-Item -LiteralPath (Join-Path $backup 'static\neon_next.js') -Destination (Join-Path $root 'static\neon_next.js') -Force
Remove-Item -LiteralPath (Join-Path $root 'static\neon11.js') -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath (Join-Path $root 'static\neon11.css') -Force -ErrorAction SilentlyContinue
Write-Host 'NS10 restaurada. Reinicie o servidor.' -ForegroundColor Green
