(()=>{'use strict';
if(window.__NEON11_UI__)return;window.__NEON11_UI__=true;
const $=id=>document.getElementById(id);
const icon={mic:'<path d="M12 3a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V6a3 3 0 0 0-3-3Z"/><path d="M5 10v2a7 7 0 0 0 14 0v-2M12 19v3m-4 0h8"/>',users:'<path d="M16 20v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 20v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',cup:'<path d="M8 21h8m-4-4v4M7 3h10v6a5 5 0 0 1-10 0V3Z"/><path d="M7 5H4v2a4 4 0 0 0 4 4M17 5h3v2a4 4 0 0 1-4 4"/>',pause:'<rect x="7" y="5" width="3" height="14" rx="1"/><rect x="14" y="5" width="3" height="14" rx="1"/>',play:'<path d="m8 5 11 7-11 7V5Z"/>',next:'<path d="m5 5 10 7-10 7V5ZM19 5v14"/>',back:'<path d="m15 18-6-6 6-6"/>',sliders:'<path d="M4 7h16M4 17h16"/><circle cx="9" cy="7" r="2"/><circle cx="15" cy="17" r="2"/>'};
const svg=name=>`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icon[name]||''}</svg>`;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function main(){if(location.pathname==='/palco')return;
 const hero=document.querySelector('.hero .hero-cta');if(hero){hero.innerHTML=`<button class="ns11-main-solo" id="ns11Solo">${svg('mic')} Cantar sozinho</button><button class="ns11-main-party" id="ns11Party">${svg('users')} Modo Party (Multiplayer)</button>`;
 $('ns11Solo').onclick=()=>location.href='/biblioteca';$('ns11Party').onclick=()=>window.open('/neonstage-party','_blank','noopener')}
 document.getElementById('ns10Hub')?.remove();document.getElementById('ns10NavScores')?.remove();
 const nav=document.querySelector('.sidebar .nav');if(nav&&!$('ns11ScoresNav')){
  const btn=document.createElement('button');btn.className='navbtn';btn.id='ns11ScoresNav';btn.innerHTML=svg('cup')+' PLACAR GLOBAL';btn.onclick=e=>{e.preventDefault();e.stopPropagation();location.href='/placar'};nav.append(btn)
 }
 const scroller=$('scrollContent');if(!scroller)return;
 const page=document.createElement('section');page.id='ns11ScoresPage';page.dataset.nsPage='leader';page.innerHTML=`<div class="ns11-score-top"><span>HISTÓRICO PERMANENTE</span><h1>${svg('cup')} Placar Global</h1><p>Todos os pontos registrados neste notebook, entre apresentações solo e festas.</p></div><div class="ns11-leaderboard" id="ns11Leaderboard">Carregando classificação...</div>`;
 scroller.append(page);
 if(location.pathname==='/placar'){
  for(const child of scroller.children)child.classList.toggle('ns-dev-visible',child===page);
  document.body.classList.add('ns-dev-pages');$('ns11ScoresNav')?.classList.add('active');const crumb=$('crumb');if(crumb)crumb.textContent='PLACAR GLOBAL';
  fetch('/api/neon10/leaderboard',{cache:'no-store'}).then(r=>r.json()).then(d=>{
    const rows=d.players||[];$('ns11Leaderboard').innerHTML=rows.length?rows.map((p,i)=>`<div class="ns11-score-row"><span class="ns11-rank-num">${i+1}</span><span class="ns11-avatar">${p.avatar?.startsWith('data:image/')?`<img src="${p.avatar}" alt="">`:esc((p.name||'?')[0])}</span><div><b>${esc(p.name)}</b><small>${Number(p.performances||0)} apresentações</small></div><strong>${Number(p.points||0).toLocaleString('pt-BR')}</strong></div>`).join(''):'<p>Nenhuma pontuação ainda. Cante uma música para entrar no placar.</p>';
  }).catch(e=>{const b=$('ns11Leaderboard');if(b)b.textContent='Não foi possível carregar o placar: '+e.message})
 }
}
function quickControls(){if(location.pathname!=='/palco')return;const stage=$('ns828Stage'),game=$('gameScreen');if(!stage||!game||game.classList.contains('hidden'))return;
 let bar=$('ns11StageControls');if(bar&&bar.parentElement!==stage){bar.remove();bar=null;}
 if(!bar){bar=document.createElement('nav');bar.id='ns11StageControls';bar.setAttribute('aria-label','Controles do palco');bar.innerHTML=`<button id="ns11Back" type="button" title="Sair para o lobby">${svg('back')}</button><button id="ns11Pause" type="button" title="Pausar ou continuar">${svg('pause')}</button><button id="ns11Skip" type="button" title="Próxima música">${svg('next')}</button><button id="ns11Audio" type="button" title="Ajustes rápidos de áudio">${svg('sliders')}</button>`;
  stage.append(bar);
  $('ns11Back').onclick=()=>{if(confirm('Sair da apresentação e voltar ao lobby?')){if(window.NEON10_RETURN_LOBBY)window.NEON10_RETURN_LOBBY();else $('exitGame')?.click()}};
  $('ns11Pause').onclick=()=>$('pauseGame')?.click();
  $('ns11Skip').onclick=()=>{let old=$('nsPartyFlowNext');if(old&&getComputedStyle(old).display!=='none')old.click();else $('ns9PlaylistSkip')?.click()};
  $('ns11Audio').onclick=()=>{if(window.NEON11_OPEN_AUDIO)window.NEON11_OPEN_AUDIO();else $('ns9AudioBtn')?.click()};
 }
 const aud=$('gameAudio');$('ns11Pause').innerHTML=svg(aud?.paused?'play':'pause');
}
function boot(){main();if(location.pathname==='/palco')setInterval(quickControls,450)}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
