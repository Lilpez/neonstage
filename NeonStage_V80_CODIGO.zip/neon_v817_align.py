"""Local WhisperX forced alignment of *display* lyrics, never scoring notes.
Alignment is opt-in per song and failure leaves the V8.16 chart intact.
"""
from pathlib import Path
import copy, json, os, re, shutil, time, datetime

VERSION='v817-20261012a'

def _vocals(song):
    paths=list((song/'separation').rglob('vocals.wav')) if (song/'separation').exists() else []
    if paths:return sorted(paths,key=lambda x:x.stat().st_size,reverse=True)[0]
    for n in ('audio.wav','audio.mp3'):
        if (song/n).exists():return song/n
    return None

def _notes_signature(chart):
    return [(n.get('start'),n.get('end'),n.get('pitch'),n.get('phrase'),n.get('talkie'),n.get('confidence')) for n in chart.get('notes',[])]

def _ts(note):
    return float(note.get('start',0))

def _word(s):
    import unicodedata
    s=''.join(c for c in unicodedata.normalize('NFD',str(s).lower()) if not unicodedata.combining(c))
    return re.sub('[^a-z0-9]','',s)

def align_chart(root, song_id, force=False, min_word_ratio=.62):
    root=Path(root); song=root/'songs'/song_id; f=song/'chart.json'
    if not f.exists():return {'state':'missing_chart'}
    base=json.loads(f.read_text(encoding='utf8'))
    existing=base.get('lyric_lines') or []
    if not existing:return {'state':'no_lyrics'}
    vocal=_vocals(song)
    if vocal is None:return {'state':'no_audio'}
    sig=_notes_signature(base)
    cache=song/'forced_align_v817.json'
    if cache.exists() and not force:
        try:
            old=json.loads(cache.read_text(encoding='utf8'))
            if old.get('version')==VERSION and old.get('state')=='done':return old
        except Exception:pass
    import torch, whisperx
    device='cuda' if torch.cuda.is_available() else 'cpu'
    wave=whisperx.load_audio(str(vocal))
    total=len(wave)/16000.
    raw=sorted((dict(x) for x in existing if isinstance(x,dict)),key=lambda r:float(r.get('at',0)))
    # Do not align over hidden spoken passages. Include only official lyric text.
    candidate=[]
    for i,r in enumerate(raw):
        s=str(r.get('text','')).strip()
        if not s or r.get('text_source') in ('stage_speech_hidden','unverified_hidden'):continue
        start=max(0.,float(r.get('at',0)))
        if start>=total-.1:continue
        next_at=float(raw[i+1]['at']) if i+1<len(raw) else min(total,start+12)
        end=min(total,max(start+1.0,next_at+.4),start+14.)
        if end-start<.5:continue
        candidate.append((i,{'start':max(0,start-.35),'end':end,'text':s},start,s))
    if not candidate:return {'state':'no_official_lines'}
    # WhisperX receives FULL correct lyrics but must keep the existing audio/segment neighborhood.
    # Two passes: first per original lyric slot, then split long comma phrases using its aligned words.
    model,meta=whisperx.load_align_model(language_code='pt',device=device)
    segments=[x[1] for x in candidate]
    try:
        aligned=whisperx.align(segments,model,meta,wave,device,return_char_alignments=False)
    finally:
        del model
        if device=='cuda':torch.cuda.empty_cache()
    results=aligned.get('segments') or []
    updated=copy.deepcopy(base); lines=[dict(r) for r in raw]
    corrections=0;splits=0;rejected=0
    for ((pos,seg,old_at,text),res) in zip(candidate,results):
        words=[w for w in (res.get('words') or []) if w.get('start') is not None and w.get('end') is not None]
        intended=[_word(x) for x in re.findall(r"[\wÀ-ÿ]+",text) if _word(x)]
        actual=[_word(w.get('word','')) for w in words if _word(w.get('word',''))]
        ratio=min(len(actual),len(intended))/max(1,len(intended))
        if ratio<min_word_ratio or len(words)<2:rejected+=1;continue
        starts=[float(w['start']) for w in words];ends=[float(w['end']) for w in words]
        # Reject implausible hallucinated/degenerate timings and large shifts.
        if any(b+0.05<a for a,b in zip(starts,starts[1:])) or ends[-1]-starts[0]>.2+seg['end']-seg['start'] or abs(starts[0]-old_at)>1.2:
            rejected+=1;continue
        lines[pos]['at']=round(max(0,starts[0]),3)
        lines[pos]['text_source']=str(lines[pos].get('text_source','genius'))+'_v817_aligned'
        corrections+=1
        if ',' not in text or len(intended)<7:continue
        # Align comma break by locating the matching last word of the first half.
        first,rest=text.split(',',1)
        left=[_word(w) for w in re.findall(r"[\wÀ-ÿ]+",first) if _word(w)]
        right=[_word(w) for w in re.findall(r"[\wÀ-ÿ]+",rest) if _word(w)]
        if len(left)<2 or len(right)<3:continue
        # This requires distinct timing evidence on both sides, no proportional splitting.
        ix=min(len(left),len(words)-2)
        if ix<2 or ix>=len(words):continue
        found=[_word(w.get('word','')) for w in words]
        if not (_word(words[ix-1].get('word',''))==left[-1] or _word(words[ix].get('word',''))==right[0]):continue
        pivot=float(words[ix]['start'])
        if pivot-starts[0]<.45 or pivot>=ends[-1]-.2:continue
        lines[pos]['text']=first.strip()+','
        lines.append({'at':round(pivot,3),'text':rest.strip(),'text_source':'genius_v817_aligned_split'})
        splits+=1
    lines.sort(key=lambda x:float(x.get('at',0)))
    # Enforce monotonic display times without touching note groups.
    if any(float(lines[i]['at'])>float(lines[i+1]['at']) for i in range(len(lines)-1)):
        raise RuntimeError('Non-monotonic lyric timestamps')
    if not corrections:return {'state':'no_safe_alignments','candidate':len(candidate),'rejected':rejected,'audio':str(vocal)}
    updated['lyric_lines']=lines
    updated['lyrics_forced_alignment_version']=VERSION
    if sig!=_notes_signature(updated):raise RuntimeError('Scoring note safeguard failed')
    backup=song/('chart_pre_v817_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.json')
    shutil.copy2(f,backup)
    tmp=song/'chart.v817.tmp'
    try:
        tmp.write_text(json.dumps(updated,ensure_ascii=False,indent=2),encoding='utf8')
        os.replace(tmp,f)
    finally:
        tmp.unlink(missing_ok=True)
    status={'state':'done','version':VERSION,'aligned':corrections,'comma_splits':splits,'rejected':rejected,'total_candidates':len(candidate),'notes_unchanged':len(sig),'audio':str(vocal),'backup':str(backup)}
    cache.write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding='utf8')
    return status
