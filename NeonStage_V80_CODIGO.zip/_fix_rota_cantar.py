from pathlib import Path
import datetime, shutil, re
root=Path(__file__).resolve().parent
app=root/"app.py"
src=app.read_text(encoding="utf-8-sig")
marker="# NS_PARTY_FIX_CANTAR_ROUTE_V1"
if marker not in src:
    match=re.search(r"(?m)^@app\.get\(['\"]\/['\"]\)",src)
    if not match:
        raise SystemExit("Rota principal nao encontrada; nada foi alterado.")
    addition="""# NS_PARTY_FIX_CANTAR_ROUTE_V1
@app.get('/cantar')
def neonstage_cantar_page():
    if request.remote_addr not in ('127.0.0.1','::1'):
        return redirect('/party')
    return app.send_static_file('index.html')

"""
    modified=src[:match.start()]+addition+src[match.start():]
    compile(modified,str(app),"exec")
    backup=root/("backup_rota_cantar_"+datetime.datetime.now().strftime("%Y%m%d_%H%M%S"))
    backup.mkdir()
    shutil.copy2(app,backup/"app.py")
    app.write_text(modified,encoding="utf-8",newline="")
    print("Rota /cantar adicionada; backup:",backup)
else:
    print("Rota /cantar deste patch ja instalada.")
print("Reinicie o servidor para ativar.")
