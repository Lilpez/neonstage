"""Align externally verified lyrics to ASR segment timings, including repeated choruses.
Never fabricate official text and never use ASR text for onscreen lyrics.
"""
import difflib
import re
import unicodedata


def norm(value):
    s = unicodedata.normalize('NFKD', str(value)).encode('ascii', 'ignore').decode().casefold()
    return re.sub(r'[^a-z0-9]+', '', s)


def words_of(text):
    return [norm(t) for t in str(text).split() if norm(t)]


def clean_lines(verified):
    result = []
    for item in verified or []:
        text = str(item.get('text', '') if isinstance(item, dict) else item).strip()
        # Genius HTML sometimes merges its title/header into the first sung line.
        text = re.sub(r'(?is)^.{0,100}?\blyrics\b(?:\[[^\]]{0,160}\])?', '', text, count=1).strip() if re.search(r'(?i)^.{0,100}?\blyrics\b', text) else text
        text = re.sub(r'(?i)^\[?(?:letra de|lyrics for|written by)[^\]]*\]?', '', text).strip()
        if not text or re.match(r'(?i)^(?:you might also like|contributors?|embed|read more|translation|\[?(verse|chorus|refr[aã]o|intro|outro|bridge)\b)', text):
            continue
        if text not in result or (result and result[-1] != text):
            # Keep non-adjacent repeated lines; they might be genuine repetitions.
            result.append(text)
    return result


def _sim(a, b):
    aa = words_of(a); bb = words_of(b)
    if not aa or not bb:
        return 0.
    a_norm = ' '.join(aa); b_norm = ' '.join(bb)
    edit = difflib.SequenceMatcher(None, a_norm, b_norm, autojunk=False).ratio()
    overlap = sum(1 for w in aa if w in set(bb)) / max(1, min(len(aa), len(bb)))
    # Raw segmented ASR may contain just half a line: avoid penalizing short chunks too much.
    return .60 * edit + .40 * overlap


def _segments_from_asr(words, segments):
    chunks=[]
    for seg in segments or []:
        try:
            a=float(seg['start']); b=float(seg['end']); txt=str(seg.get('text') or '').strip()
            if txt and b>a and a>=0:
                chunks.append({'at':a,'end':b,'text':txt})
        except (KeyError, TypeError, ValueError):
            pass
    if chunks:
        return sorted(chunks, key=lambda x:x['at'])
    # Fallback using ASR word timings and breathing gaps.
    group=[]
    for w in words:
        try:
            a=float(w['start']); b=float(w['end']); txt=str(w.get('text') or '').strip()
            if b<=a or not txt: continue
        except (KeyError,TypeError,ValueError): continue
        if group and (a-group[-1]['end']>.52 or b-group[0]['at']>5.8):
            chunks.append({'at':group[0]['at'], 'end':group[-1]['end'], 'text':' '.join(x['text'] for x in group)})
            group=[]
        group.append({'at':a,'end':b,'text':txt})
    if group: chunks.append({'at':group[0]['at'], 'end':group[-1]['end'], 'text':' '.join(x['text'] for x in group)})
    return chunks


def align_official(verified, asr_words, segments=None):
    """Constrained monotonic audio alignment with official-lyric chorus repeats.

    A lyric line may occur repeatedly; each recurrence gets the ASR segment's original
    timestamp. Explicit gaps carry no fabricated text. Pitch note times are untouched.
    """
    lines=clean_lines(verified)
    chunks=_segments_from_asr(asr_words,segments)
    result={'lyric_lines':[],'word_overlays':[],'matched_words':0,
            'official_words':sum(len(words_of(x)) for x in lines), 'coverage':0.,
            'match_mode':'asr_segment_repeats'}
    if not lines or not chunks: return result
    candidates=[]
    n=len(lines)
    last_idx=None
    for chunk in chunks:
        # Some ASR chunks contain more than a single lyric line. Compare full
        # segment and windows thereof, rather than relying on global SequenceMatcher.
        text=chunk['text']
        scores=[]
        for i,line in enumerate(lines):
            similarity=_sim(text,line)
            # Follow neighboring lines when ambiguous; allow wrap after chorus.
            advance=(i-last_idx)%n if last_idx is not None else 0
            bias=.035 if last_idx is not None and advance in (1,2) else 0.
            scores.append((similarity+bias,similarity,i))
        _,sim,idx=max(scores)
        if sim<.46:
            continue
        if last_idx is not None and idx==last_idx and candidates:
            prev=candidates[-1]
            # WhisperX frequently breaks a single sung line into two chunks.
            # Merge those rather than making a second rapidly changing screen line.
            if chunk['at']-prev['at']<5.5 and chunk['at']-prev['end']<1.0:
                prev['end']=max(prev['end'],chunk['end'])
                prev['confidence']=max(prev['confidence'],round(sim,3))
                continue
        candidates.append({'at':round(chunk['at'],3),'end':round(chunk['end'],3),
                           'text':lines[idx], 'confidence':round(sim,3),'source_line':idx})
        last_idx=idx
    # Remove isolated implausible jumps when neither lyric neighbor nor repeat
    # is corroborated by adjacent ASR chunks. Keep clear high-confidence cases.
    filtered=[]
    for c in candidates:
        if filtered and c['at']<=filtered[-1]['at']+0.08:continue
        if filtered and c['text']==filtered[-1]['text'] and c['at']-filtered[-1]['at']<6:
            filtered[-1]['end']=max(filtered[-1]['end'],c['end']);continue
        filtered.append(c)
    result['lyric_lines']=filtered
    result['matched_words']=sum(len(words_of(c['text'])) for c in filtered)
    result['coverage']=round(len(filtered)/max(1,len(chunks)),3)
    # Text on individually timed ASR notes is intentionally not copied unless
    # independently verified at word level, avoiding invented official note words.
    return result
