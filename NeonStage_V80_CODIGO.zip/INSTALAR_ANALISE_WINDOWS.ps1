$ErrorActionPreference='Stop'
Set-Location $PSScriptRoot
$py=Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (!(Test-Path $py)) { throw 'Execute INSTALAR_WINDOWS.ps1 primeiro.' }
& $py -m pip install -r requirements-analysis.txt
if ($LASTEXITCODE -ne 0) { throw 'Dependencias de analise falharam. Verifique versoes de PyTorch/WhisperX.' }
Write-Host 'Dependencias de analise instaladas.' -ForegroundColor Green
