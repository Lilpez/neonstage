/* NeonStage V8.29 - isolated stage with Rock Band inspired crowd meter */
(()=>{
'use strict';
if(window.__NS_STAGE829__)return;window.__NS_STAGE829__=true;
const $=id=>document.getElementById(id),clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
let root=null,canvas=null,ctx=null,video=null,uid='',lines=[],lastIndex=-99, raf=0,lastFrame=0,videoTimer=0,lastNote=-1;
let streak=0,good=0,awarded=0,pastNote=null,anchorBase=60,rangeLow=45,rangeHigh=81;
let progressEl,scoreEl,comboEl,ratioEl,topLeft=null;
let crowd=100,lastCrowdTime=null,failPending=false,failed=false,failOverlay=null,prevMeterNote=-1,hitIndicatorAt=0;
let leadMs=0,lastDrawError=false;
const targetGame=$('gameScreen');if(!targetGame)return;
const getEngine=()=>{try{return state}catch{return null}};
const frameSong=()=>getEngine()?.chart||null;
const audio=()=> $('gameAudio');
const visualLines=chart=>((chart?.lyric_lines)||[]).filter(x=>String(x.text||'').trim()).map(x=>({at:Number(x.at??x.start??0),text:String(x.text).trim()})).sort((a,b)=>a.at-b.at);
const fmt=n=>Math.round(n||0).toLocaleString('pt-BR');
function cleanOverlay(){
 if(raf){cancelAnimationFrame(raf);raf=0;}if(videoTimer){clearInterval(videoTimer);videoTimer=0;}
 if(video){video.pause();video.removeAttribute('src');video.load();video=null;}
 targetGame.classList.remove('ns828-active');
 root?.remove();root=null;canvas=null;ctx=null;uid='';lastIndex=-99;failed=false;failPending=false;
}
function isStagePlaying(){const s=getEngine();return Boolean(s?.playing&&s?.chart&&!targetGame.classList.contains('hidden')&&audio()?.src);}
function fit(){if(!canvas||!root)return;const dpr=Math.min(devicePixelRatio||1,2),r=canvas.getBoundingClientRect();let w=Math.max(1,Math.round(r.width*dpr)),h=Math.max(1,Math.round(r.height*dpr));if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;ctx.setTransform(dpr,0,0,dpr,0,0);}}
function mount(){
 const s=getEngine(),ch=s?.chart;if(!ch)return;
 cleanOverlay(); uid=ch.id||s.selected?.id||'song';lines=visualLines(ch);lastIndex=-99;lastNote=-1;streak=0;good=0;awarded=0;crowd=100;lastCrowdTime=null;failed=false;failPending=false;prevMeterNote=-1;lastDrawError=false;
 const pitches=(ch.notes||[]).filter(n=>!n.talkie&&Number.isFinite(n.pitch)).map(n=>n.pitch).sort((a,b)=>a-b);
 if(pitches.length){const p=(q)=>pitches[Math.min(pitches.length-1,Math.floor(q*(pitches.length-1)))];const mid=p(.5);rangeLow=Math.floor((p(.06)-4)/6)*6;rangeHigh=Math.ceil((p(.94)+4)/6)*6;if(rangeHigh-rangeLow<18){rangeLow=mid-12;rangeHigh=mid+12;}anchorBase=mid;}
 targetGame.classList.add('ns828-active');
 root=document.createElement('div');root.id='ns828Stage';
 root.innerHTML=`<div class="ns828-bg"><div class="ns828-gradient"></div><video class="ns828-video" muted playsinline preload="metadata"></video><div class="ns828-vignette"></div></div>
 <div class="ns828-topline"><div class="ns828-stage-tag">✦ NEONSTAGE <b>LIVE</b></div><div class="ns828-track-title"></div><div class="ns828-controls"><button id="ns828Back" type="button" title="Sair">←</button><button id="ns828Pause" type="button" title="Pausar">Ⅱ</button><button id="ns828Restart" type="button" title="Recomeçar">↺</button></div></div>
 <section class="ns828-highway"><canvas id="ns828Canvas"></canvas><div class="ns828-fadeleft"></div><div class="ns828-faderight"></div><div class="ns828-highway-caption">ACERTE O TOM <span>✦</span> MANTENHA A MULTIDÃO</div></section>
 <aside class="ns828-left"><div class="ns828-crowd-title">MULTIDÃO</div><div id="ns828Pname"></div><div class="ns828-vertical"><div id="ns828Level"></div><div class="ns828-danger"></div></div><div class="ns828-combo" id="ns828Combo">x1</div><div id="ns828MeterLabel">100%</div></aside>
 <aside class="ns828-right"><div class="ns828-points" id="ns828Points">0</div><div class="ns828-stars" id="ns828Stars">☆☆☆☆☆</div><div class="ns828-accuracy" id="ns828Accuracy">CANTE PARA GANHAR ESTRELAS</div></aside>
 <div class="ns828-centerlyrics" id="ns828Lyrics"><div class="ns828-sideverse" id="ns828Prev"></div><div class="ns828-mainverse" id="ns828Current"><span class="ns828-white"></span></div><div class="ns828-sideverse" id="ns828Next"></div></div>
 <div class="ns828-burst" id="ns828Burst"></div>
 <div class="ns829-fail-overlay hidden" id="ns829Fail"><div class="ns829-fail-box"><div class="ns829-fail-kicker">O SHOW ACABOU</div><h2>A multidão foi embora</h2><p>Você ficou sem energia. Tente novamente e mantenha o ritmo!</p><div class="ns829-fail-actions"><button type="button" id="ns829Retry">↻ TENTAR NOVAMENTE</button><button type="button" id="ns829Exit">SAIR DO PALCO</button></div></div></div>
 <footer class="ns828-bottom"><span id="ns828Time">0:00</span><div class="ns828-timebar"><i id="ns828Progress"></i></div><span id="ns828Total">0:00</span><div id="ns828Status">● MICROFONE PRONTO</div></footer>`;
 targetGame.appendChild(root);
 const rawTitle=String(ch.title||'');const rawArtist=String(ch.artist||'');
 root.querySelector('.ns828-track-title').textContent=(rawTitle.toLowerCase().startsWith(rawArtist.toLowerCase()+' - ') ? rawTitle : [rawArtist,rawTitle].filter(Boolean).join(' — '));
 root.querySelector('#ns828Pname').textContent=(s.players?.[0]?.name||'PLAYER 1').toUpperCase();
 canvas=$('ns828Canvas');ctx=canvas.getContext('2d');video=root.querySelector('video');
 progressEl=$('ns828Progress');scoreEl=$('ns828Points');comboEl=$('ns828Combo');ratioEl=$('ns828Accuracy');
 $('ns828Back').onclick=()=>$('exitGame')?.click(); $('ns828Pause').onclick=()=>$('pauseGame')?.click(); $('ns828Restart').onclick=()=>$('restartGame')?.click();
 $('ns829Retry').onclick=()=>{ $('ns829Fail')?.classList.add('hidden'); $('restartGame')?.click(); };
 $('ns829Exit').onclick=()=>{ $('ns829Fail')?.classList.add('hidden'); $('exitGame')?.click(); };
 setupVideo(uid);raf=requestAnimationFrame(render);
}
function setupVideo(id){
 if(!id||!video)return;
 const v=video;let attempts=0,done=false;
 async function poll(){if(!root||done)return;try{const r=await fetch('/api/showtime/video/'+encodeURIComponent(id),{cache:'no-store'});if(!r.ok)return;const j=await r.json();if(j.ready&&j.url){done=true;v.src=j.url;v.addEventListener('loadedmetadata',syncVideo,{once:true});syncVideo();return;}if(j.state==='error'){done=true;return;}}catch{}if(++attempts>=85)done=true;}
 fetch('/api/showtime/video/'+encodeURIComponent(id),{method:'POST'}).catch(()=>{}).finally(()=>poll());
 videoTimer=setInterval(()=>{if(!root)return;if(!done)poll();syncVideo();},1800);
}
function syncVideo(){if(!video?.src)return;const a=audio();if(!a)return;try{if(video.readyState>=1&&Math.abs(video.currentTime-a.currentTime)>.4)video.currentTime=a.currentTime;if(a.paused){video.pause();}else if(video.paused)video.play().catch(()=>{});}catch{}}
function getIndex(t){let lo=0,hi=lines.length-1,best=-1;while(lo<=hi){const mid=(lo+hi)>>1;if(lines[mid].at<=t+.12){best=mid;lo=mid+1;}else hi=mid-1;}return best;}
function lyricUpdate(t){const idx=getIndex(t);if(idx!==lastIndex){lastIndex=idx;const line=idx>=0?lines[idx].text:'INTRODUÇÃO';const display=$('ns828Current');display.classList.remove('ns828-enter');void display.offsetWidth;display.classList.add('ns828-enter');display.querySelector('.ns828-white').textContent=line;$('ns828Prev').textContent=idx>0?lines[idx-1].text:'';$('ns828Next').textContent=lines[idx+1]?.text||'';}

}
function syllables(token){
 const punctuation=token.match(/[.,!?;:]+$/)?.[0]||'';const word=punctuation?token.slice(0,-punctuation.length):token;
 if(word.length<5)return[word+punctuation];const vowels=/[aeiouáéíóúâêôãõà]/i;
 let out=[],carry='';for(let i=0;i<word.length;i++){carry+=word[i];if(i>=word.length-2)continue;const a=word[i],b=word[i+1],c=word[i+2];if(vowels.test(a)&&!vowels.test(b)&&vowels.test(c)&&!/[rlh]/i.test(b)){out.push(carry+'-');carry='';}}
 if(carry)out.push(carry+punctuation);return out.length?out:[word+punctuation];
}
function formatTime(t){if(!Number.isFinite(t))return'0:00';return Math.floor(t/60)+':'+String(Math.floor(t%60)).padStart(2,'0');}
function draw(t){
 if(!ctx||!canvas)return;
 fit();const dpr=Math.min(devicePixelRatio||1,2),W=canvas.width/dpr,H=canvas.height/dpr,g=ctx;
 // Canvas transforms must always be set; resizing resets the drawing context.
 g.setTransform(dpr,0,0,dpr,0,0);g.clearRect(0,0,W,H);
 const s=getEngine(),pitch=s?.players?.[0]?.mid,notes=frameSong()?.notes||[];
 const baseTop=16,baseBottom=H-29,cursorX=W*.20,secScale=(W-cursorX-28)/5.8;
 const yy=p=>baseBottom-(clamp(p,rangeLow,rangeHigh)-rangeLow)/Math.max(1,rangeHigh-rangeLow)*(baseBottom-baseTop);
 // Stable pitch grid (never follows the singer or the currently playing note).
 g.fillStyle='rgba(8,13,30,.58)';g.fillRect(0,0,W,H);
 for(let k=0;k<=8;k++){
   const y=baseTop+(baseBottom-baseTop)*k/8;
   g.strokeStyle=k===4?'rgba(251,129,202,.65)':'rgba(132,180,215,.22)';g.lineWidth=k===4?2:1;
   g.beginPath();g.moveTo(0,y);g.lineTo(W,y);g.stroke();
 }
 for(let k=0;k<=14;k++){
   g.strokeStyle='rgba(255,255,255,.042)';const x=k*W/14;g.beginPath();g.moveTo(x,baseTop);g.lineTo(x,baseBottom);g.stroke();
 }
 // Real note blocks flow to the hit line from right to left.
 const visible=notes.filter(n=>!n.talkie && Number.isFinite(n.start)&&Number.isFinite(n.end)&&Number.isFinite(n.pitch)&&n.end>=t-.8&&n.start<=t+5.8);
 for(const n of visible){
   const x=cursorX+(n.start-t)*secScale,ex=cursorX+(n.end-t)*secScale,y=yy(n.pitch);
   if(!Number.isFinite(x)||!Number.isFinite(ex)||!Number.isFinite(y))continue;
   g.shadowBlur=10;g.shadowColor='#19c9fa';g.fillStyle=n.start<=t&&n.end>=t?'#72eeff':'#29caed';
   g.beginPath();g.roundRect(x,y-5,Math.max(4,ex-x),10,4);g.fill();
 }
 g.shadowBlur=0;
 g.strokeStyle='#e8f2ff';g.lineWidth=2.4;g.beginPath();g.moveTo(cursorX,3);g.lineTo(cursorX,H-6);g.stroke();
 // Persistent stylized arrow, moving vertically as the microphone pitch changes.
 const target=visible.find(n=>n.start<=t&&n.end>=t)||visible.find(n=>n.start>t)||null;
 const arrowY=yy(Number.isFinite(pitch)?pitch:(target?.pitch??anchorBase)),ax=cursorX-12;
 g.save();g.shadowColor='#ffda73';g.shadowBlur=19;g.fillStyle='#ffc959';g.strokeStyle='#fff2bc';g.lineWidth=1.6;
 g.beginPath();g.moveTo(ax-28,arrowY);g.lineTo(ax-7,arrowY-12);g.lineTo(ax+8,arrowY-12);g.lineTo(ax+30,arrowY);g.lineTo(ax+8,arrowY+12);g.lineTo(ax-7,arrowY+12);g.closePath();g.fill();g.stroke();g.restore();
 // Approximate syllabic fragments accompany note guides (no claimed phonetic accuracy).
 const ix=getIndex(t), current=ix>=0?lines[ix]:null;
 if(current){
   const parts=current.text.split(/\s+/).flatMap(syllables).slice(0,38);
   const from=current.at,to=lines[ix+1]?.at||from+4,dur=Math.max(.5,to-from);
   g.textAlign='center';g.font='650 13px system-ui';g.textBaseline='middle';
   parts.forEach((p,i)=>{
     let x=cursorX+((from+(i+.5)/parts.length*dur)-t)*secScale;if(x<4||x>W-4)return;
     const y=H-13;g.lineWidth=2.6;g.strokeStyle='rgba(0,0,0,.85)';g.strokeText(p,x,y);
     g.fillStyle=((i+.5)/parts.length)<clamp((t-from)/dur,0,1)?'#ff91d6':'#f0f5ff';g.fillText(p,x,y);
   });
 }
}
function judgment(dt,t){
 const s=getEngine(), a=audio(),p=s?.players?.[0];if(!p||!a||a.paused||failed||!Number.isFinite(dt)||dt<=0)return;
 const notes=s.chart?.notes||[];
 const active=notes.find(n=>!n.talkie && t>=n.start && t<=n.end);
 if(!active || t<7)return; // silence, interludes and intro never drain the meter
 // Meter updates from actual vocal frame confidence. Does not change game score.
 const diff=Number.isFinite(p.mid)?Math.abs(((p.mid-active.pitch+6)%12+12)%12-6):null;
 const quality=diff===null?0:clamp(1-diff/2.5,0,1);
 crowd=clamp(crowd+(quality>=.77?2.7:quality>=.55?0.25:-4.0)*dt,0,100);
 if(crowd<26 && !failPending){failPending=true;root.classList.add('ns829-danger-mode');}
 if(crowd>32 && failPending){failPending=false;root.classList.remove('ns829-danger-mode');}
 if(crowd<=0 && !failed){
   failed=true;crowd=0;a.pause();root.classList.remove('ns829-danger-mode');$('ns829Fail')?.classList.remove('hidden');
   $('ns828Burst').textContent='SHOW ENCERRADO';$('ns828Burst').classList.remove('ns828-pop');void $('ns828Burst').offsetWidth;$('ns828Burst').classList.add('ns828-pop');
 }
}
function particleOnNote(){const s=getEngine();let i=s?.lastNote??-1;if(i===lastNote)return;const p=s?.players?.[0];if(lastNote>=0&&p){if(p.combo>streak){streak=p.combo;good++;if(streak>0&&streak%5===0){const e=$('ns828Burst');e.textContent=streak+'x COMBO';e.classList.remove('ns828-pop');void e.offsetWidth;e.classList.add('ns828-pop');}}else streak=p.combo||0;}lastNote=i;}
function render(now){if(!isStagePlaying()){cleanOverlay();return;}const s=getEngine(),a=audio(),t=a.currentTime;
 const dt=lastCrowdTime===null?0:clamp((now-lastCrowdTime)/1000,0,.12);lastCrowdTime=now;
 if(!failed)judgment(dt,t);
 lyricUpdate(t);
 try{draw(t);lastDrawError=false;}catch(e){if(!lastDrawError){console.warn('SHOWTIME pista:',e);lastDrawError=true;}}
 particleOnNote();scoreEl.textContent=fmt(s.players[0]?.score||0);comboEl.textContent='x'+Math.max(1,Math.min(4,1+Math.floor((s.players[0]?.combo||0)/8)));
 const fraction=clamp((s.players[0]?.score||0)/Math.max(2000, (s.chart?.notes?.length||50)*220),0,1),stars=Math.min(5,Math.floor(fraction*5));$('ns828Stars').textContent='★'.repeat(stars)+'☆'.repeat(5-stars);$('ns828Level').style.height=crowd.toFixed(1)+'%';
 $('ns828MeterLabel').textContent=Math.round(crowd)+'%';ratioEl.textContent=s.players[0]?.feedback||'AJUSTE SUA VOZ';
 $('ns828Time').textContent=formatTime(t);$('ns828Total').textContent=formatTime(a.duration||s.chart.duration);progressEl.style.width=(100*t/(a.duration||s.chart.duration||1))+'%';$('ns828Pause').textContent=a.paused?'▶':'Ⅱ';
 raf=requestAnimationFrame(render);
}
function reconcile(){if(isStagePlaying()){if(!root)mount();}else if(root)cleanOverlay();}
const obs=new MutationObserver(reconcile);obs.observe(targetGame,{attributes:true,attributeFilter:['class']});
$('startGame')?.addEventListener('click',()=>{setTimeout(reconcile,0);setTimeout(reconcile,500);setTimeout(reconcile,1600);});
$('exitGame')?.addEventListener('click',()=>setTimeout(reconcile,50));
reconcile();
})();
