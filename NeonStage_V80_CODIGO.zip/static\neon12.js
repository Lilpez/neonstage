/* NeonStage NS12 — stage controller and reusable song search. */
(()=>{
'use strict';
if(window.__NEON12__)return;window.__NEON12__=true;
const $=id=>document.getElementById(id);
const stagePage=location.pathname==='/palco';
const htmlEscape=s=>String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function songSearchHero(id){
 const element=document.createElement('div');element.id=id;element.className='ns12-song-search';
 element.innerHTML=`<div class="ns12-search-heading"><div><span class="ns12-search-kicker">ESCOLHA O SOM</span><h2>O que vamos cantar?</h2></div><span>Encontre sua versão favorita</span></div><form class="ns12-song-form"><label class="ns12-search-input"><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="m16 16 5 5"/></svg><input type="search" aria-label="Buscar música ou artista" placeholder="Música, artista ou versão ao vivo..." autocomplete="off" minlength="2" required></label><button type="submit">Buscar versões <span aria-hidden="true">→</span></button></form><p>Pesquise gravações, versões acústicas e shows ao vivo. Depois adicione a música ao repertório.</p>`;
 element.querySelector('form').addEventListener('submit',event=>{
  event.preventDefault();const q=element.querySelector('input').value.trim();if(q.length<2)return;
  const url='/descobrir?q='+encodeURIComponent(q);
  if(location.pathname==='/descobrir'){
   const input=$('searchInput');if(input){input.value=q;$('searchButton')?.click();return;}
  }
  location.assign(url);
 });
 return element;
}
function mountSearch(){
 const hero=document.querySelector('.hero');
 if(hero&&!$('ns12HomeSearch')){
  const node=songSearchHero('ns12HomeSearch');hero.insertAdjacentElement('afterend',node);
  const sync=()=>{node.hidden=!['/','/inicio'].includes(location.pathname)};
  window.addEventListener('click',()=>setTimeout(sync,0),true);
  window.addEventListener('popstate',sync);sync();
 }
 const lib=$('librarySection');
 if(lib&&!$('ns12LibrarySearch'))lib.prepend(songSearchHero('ns12LibrarySearch'));
 // The existing search backend renders the results and the + add/prepare control.
 if(location.pathname==='/descobrir'){
  const query=new URLSearchParams(location.search).get('q')?.trim();
  if(query){const input=$('searchInput');if(input){input.value=query;setTimeout(()=>$('searchButton')?.click(),120)}}
 }
 // Keep global scoreboard in /placar and the sidebar only.
 $('settingsSection')?.querySelectorAll('#ns10Leader, #ns10Hub').forEach(node=>node.remove());
}
let currentSolo=null,starting=false;
function permissionNotice(message){
 let bar=$('ns12Permission');
 if(!bar){bar=document.createElement('section');bar.id='ns12Permission';bar.setAttribute('role','status');bar.innerHTML='<span class="ns12-permission-text"></span><button type="button" id="ns12Retry">Ativar áudio e microfone</button><a href="/biblioteca">Voltar à biblioteca</a>';document.body.append(bar)}
 bar.querySelector('.ns12-permission-text').textContent=message||'O navegador precisa autorizar áudio e microfone.';
 $('ns12Retry').onclick=()=>{if(currentSolo)window.NEON12_START_SOLO(currentSolo,true);else window.NEON12_ENABLE_AUDIO?.()};
 bar.hidden=false;
}
function clearNotice(){const n=$('ns12Permission');if(n)n.hidden=true}
function savedProfile(){try{return JSON.parse(localStorage.getItem('neon9_profile')||'{}')}catch{return {}}}
function savedAudio(){try{return JSON.parse(localStorage.getItem('neon9_mixer')||'{}')}catch{return {}}}
async function startSolo(song){
 if(!stagePage||!song?.id||starting)return;
 // Not a party presentation. /palco?solo opens through the same engine.
 starting=true;currentSolo=song;clearNotice();
 try{
  const s=typeof state!=='undefined'?state:null;
  if(!s)throw Error('O motor vocal não foi inicializado.');
  if(s.playing&&s.selected?.id===song.id)return;
  s.partyActive=false;s.selected=song;
  $('setupSong').textContent=song.title||'Música';$('setupArtist').textContent=song.artist||'';
  $('setupError').textContent='';$('duetToggle').checked=false;
  if(typeof toggleDuet==='function')toggleDuet();
  const profile=savedProfile();$('name1').value=profile.name||localStorage.getItem('neon_player1')||'Convidado';
  if(typeof loadMics==='function')await loadMics();
  const micId=savedAudio().mic;
  if(micId&&[...$('mic1').options].some(x=>x.value===micId))$('mic1').value=micId;
  if(typeof modal==='function')modal('setupOverlay',false);
  await beginSong();
  const audio=$('gameAudio');
  if(!s.playing||audio?.paused){
   const message=$('setupError')?.textContent?.trim()||'Reprodução não autorizada. Clique para permitir áudio e microfone.';
   if(typeof stopGame==='function')await stopGame();
   permissionNotice(message);
  }else clearNotice();
 }catch(e){
  try{if(typeof stopGame==='function')await stopGame()}catch{}
  permissionNotice(e?.message||'Falha ao iniciar o palco.');
 }finally{starting=false}
}
window.NEON12_START_SOLO=startSolo;
function mountStage(){
 if(!stagePage)return;
 document.documentElement.classList.add('ns12-palco');
 // The legacy form still exists for engine compatibility, but is never displayed.
 const overlay=$('setupOverlay');if(overlay){overlay.classList.add('hidden');overlay.setAttribute('aria-hidden','true')}
 // Fallback for a non-solo Party start that browsers initially block.
 window.NEON12_ENABLE_AUDIO=async()=>{
  const ctx=typeof state!=='undefined'?state.ctx:null;
  try{if(ctx?.state==='suspended')await ctx.resume();const audio=$('gameAudio');if(audio?.src&&audio.paused)await audio.play();clearNotice()}
  catch(e){permissionNotice(e.message)}
 };
 // Avoid starting a second vocal stream on repeated remote notifications.
}
function boot(){mountStage();if(!stagePage)mountSearch()}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
