$ErrorActionPreference='Stop'
Set-Location $PSScriptRoot
if (-not (Get-Command py -ErrorAction SilentlyContinue)) { throw 'Instale Python 3.11 primeiro: winget install Python.Python.3.11' }
if (!(Test-Path '.venv\Scripts\python.exe')) { py -3.11 -m venv .venv }
$py=Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
& $py -m pip install --upgrade pip
& $py -m pip install -r requirements-basic.txt
Write-Host 'Interface pronta. Para gerar novas musicas e preciso instalar dependencias de analise.' -ForegroundColor Green
Write-Host 'Execute: .\INSTALAR_ANALISE_WINDOWS.ps1' -ForegroundColor Yellow
Write-Host 'Inicie: .\INICIAR_WINDOWS.ps1' -ForegroundColor Yellow
