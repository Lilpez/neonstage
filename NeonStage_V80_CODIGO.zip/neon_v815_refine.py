"""Small text-only refinement of v8.14. No score/timing data on notes modified."""
from neon_text_correction import clean_lines, similarity, tokens, norm

def refine(chart, official):
    lines=chart.get('lyric_lines') or []
    words=chart.get('notes') or []
    reference=clean_lines(official)
    if not reference: return {'recovered':0,'remaining_hidden':0,'timing_snapped':0}
    candidates=[(i,reference[i]) for i in range(len(reference))]
    candidates += [(i,reference[i]+' '+reference[i+1]) for i in range(len(reference)-1)]
    def match(text, threshold=.55):
        choices=sorted(((similarity(text,s)[0],i) for i,s in candidates),reverse=True)
        if not choices or choices[0][0]<threshold:return None
        if len(choices)>1 and choices[0][0]-choices[1][0]<.015:return None
        return choices[0][1]
    anchors={}
    for k,row in enumerate(lines):
        if row.get('text') and row.get('text_source')=='genius_exact_line':
            p=match(row['text'],.84)
            if p is not None:anchors[k]=p
    grouped={}
    for w in words:
        grouped.setdefault(w.get('phrase',0),[]).append(w)
    slots=sorted(grouped.values(),key=lambda group:float(group[0].get('start',0)))
    original=[(round(float(g[0].get('start',0)),3),' '.join(str(w.get('asr_original',w.get('text',''))) for w in g)) for g in slots]
    recovered=0; remaining=0; snapped=0
    for k,row in enumerate(lines):
        if row.get('text_source') not in ('unverified_hidden',):continue
        at=float(row.get('at',0))
        if not original:remaining+=1;continue
        closest=min(original,key=lambda x:abs(x[0]-at))
        if abs(closest[0]-at)>.22:remaining+=1;continue
        transcription=closest[1]
        if len(tokens(transcription))<3:remaining+=1;continue
        left=next(((q,anchors[q]) for q in range(k-1,-1,-1) if q in anchors),None)
        right=next(((q,anchors[q]) for q in range(k+1,len(lines)) if q in anchors),None)
        if left is None:remaining+=1;continue
        # Restrict to verses immediately following an established anchor. Within
        # two-sided anchors, prohibit jumping forward or wrapping across choruses.
        possible=[]
        for p,s in candidates:
            distance=p-left[1]
            if distance<0 or distance>max(4,2*(k-left[0])):continue
            if right and (p>right[1] or p<left[1]):continue
            score,an=similarity(transcription,s)
            if an<1 or score<.49:continue
            possible.append((score,p,s))
        possible.sort(reverse=True)
        if len(possible)==0 or (len(possible)>1 and possible[0][0]-possible[1][0]<.055):
            remaining+=1;continue
        score,p,s=possible[0]
        row['text']=s
        row['text_source']='genius_v815_recovered'
        row['match_confidence']=round(score,3)
        anchors[k]=p
        recovered+=1
    chart['lyrics_refinement_version']='v815_conservative'
    return {'recovered':recovered,'remaining_hidden':remaining,'timing_snapped':snapped}
