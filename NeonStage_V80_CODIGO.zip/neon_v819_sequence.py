"""V8.19: reversible lyric grouping + global-order audit. Never edits scoring notes.
Uses existing V8.17 word-aligned onsets and the official Genius lyric order.
"""
from pathlib import Path
import json, re, unicodedata, difflib, shutil, os, hashlib, datetime
VERSION='v819-20261012a'

def tok(s):
    s=''.join(c for c in unicodedata.normalize('NFKD',str(s).lower()) if not unicodedata.combining(c))
    return re.findall(r'[a-z0-9]+',s)

def similar(a,b):
    aa=tok(a);bb=tok(b)
    if not aa or not bb:return 0.
    w=difflib.SequenceMatcher(None,aa,bb,autojunk=False).ratio()
    c=difflib.SequenceMatcher(None,' '.join(aa),' '.join(bb),autojunk=False).ratio()
    return .58*w+.42*c

def official_lines(root,chart):
    try:
        from neon_auto_genius import lookup
        try:
            from lyrics_verified import _genius_token
            token=_genius_token()
        except Exception:token=''
        d=lookup(chart.get('title',''),chart.get('artist',''),chart.get('duration',0),token,Path(root))
        if d and d.get('lyric_lines'):
            from neon_text_correction import clean_lines
            return clean_lines(d['lyric_lines'])
    except Exception:pass
    return []

def bestmatch(s,reference):
    ranked=sorted(((similar(s,r),i) for i,r in enumerate(reference)),reverse=True)
    return ranked[0] if ranked else (0.,-1)

def run(root,song_id,force=False):
    root=Path(root);song=root/'songs'/song_id;f=song/'chart.json'
    if not f.exists():return {'state':'missing_chart'}
    chart=json.loads(f.read_text(encoding='utf8'))
    lines=chart.get('lyric_lines') or []
    if not lines:return {'state':'no_lyrics'}
    if chart.get('lyrics_sequence_version')==VERSION and not force:return {'state':'already_processed'}
    raw=sorted([dict(x) for x in lines if isinstance(x,dict)],key=lambda r:float(r.get('at',0)))
    original_notes=json.dumps(chart.get('notes',[]),ensure_ascii=False,sort_keys=True)
    official=official_lines(root,chart)
    output=[];joined=0; i=0; join_log=[]
    while i<len(raw):
        a=dict(raw[i]);ta=str(a.get('text','')).strip()
        if not ta or i+1>=len(raw):output.append(a);i+=1;continue
        b=raw[i+1];tb=str(b.get('text','')).strip()
        if not tb:output.append(a);i+=1;continue
        gap=float(b.get('at',0))-float(a.get('at',0))
        if gap<0 or gap>5.4 or a.get('hidden') or b.get('hidden'):
            output.append(a);i+=1;continue
        combined=(ta.rstrip()+' '+tb.lstrip()).strip()
        wa,wb=len(tok(ta)),len(tok(tb))
        if len(tok(combined))>15 or len(combined)>115 or wa>9 or wb>10:
            output.append(a);i+=1;continue
        # Allow join only with explicit linguistic/punctuation evidence; do not blindly join neighboring verses.
        comma=ta.endswith(',')
        grammar=(ta.lower().startswith(('e o que eu sei','tô aqui na frente','to aqui na frente')) or
                 tb.lower().startswith(('é que daqui','imaginando chuva')))
        matching=False
        if official:
            joint_score,_=bestmatch(combined,official)
            first_score,_=bestmatch(ta,official)
            second_score,_=bestmatch(tb,official)
            # If the official lyric line really contains both fragments, joining is appropriate.
            matching=joint_score>=.80 and joint_score>=max(first_score,second_score)+.055
        if not ((comma or grammar) and (matching or grammar and gap<=4.5)):
            output.append(a);i+=1;continue
        # Do not combine speech or unverified hidden fragments.
        src_a=str(a.get('text_source',''));src_b=str(b.get('text_source',''))
        if any(x in (src_a+' '+src_b) for x in ('hidden','speech')):
            output.append(a);i+=1;continue
        a['text']=combined
        a['text_source']=src_a+'_v819_grouped'
        a['v819_child_onset']=float(b['at']) # diagnostic only; original aligned onset retained
        output.append(a);join_log.append({'at':a['at'],'joined':combined,'second_at':b['at']});joined+=1;i+=2
    # Detect strong local disorder, but never invent a lyric-to-audio remapping based on text order alone.
    disorder=[]
    if official:
        entries=[]
        for k,r in enumerate(output):
            if not str(r.get('text','')).strip():continue
            score,ind=bestmatch(str(r['text']),official)
            entries.append((k,score,ind,str(r['text'])))
        for x,y in zip(entries,entries[1:]):
            if x[1]>=.81 and y[1]>=.81 and y[2]+1<x[2]:
                disorder.append({'at_a':output[x[0]]['at'],'line_a':x[3], 'at_b':output[y[0]]['at'],'line_b':y[3], 'reason':'potential_reversal_or_refrain'})
    chart['lyric_lines']=output
    chart['lyrics_sequence_version']=VERSION
    if original_notes!=json.dumps(chart.get('notes',[]),ensure_ascii=False,sort_keys=True):
        raise RuntimeError('Note invariant violated')
    if any(float(x['at'])>float(y['at']) for x,y in zip(output,output[1:])):raise RuntimeError('Unsorted onset')
    backup=song/('chart_pre_v819_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.json')
    shutil.copy2(f,backup)
    tmp=song/'chart.v819.tmp'
    try:
        tmp.write_text(json.dumps(chart,ensure_ascii=False,indent=2),encoding='utf8')
        os.replace(tmp,f)
    finally:tmp.unlink(missing_ok=True)
    report={'state':'done','version':VERSION,'lines_before':len(raw),'lines_after':len(output),'merged':joined,'notes_unchanged':len(chart.get('notes',[])),'official_lines':len(official),'order_warnings':len(disorder),'warnings':disorder,'joins':join_log,'backup':str(backup)}
    (song/'v819_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    return report
