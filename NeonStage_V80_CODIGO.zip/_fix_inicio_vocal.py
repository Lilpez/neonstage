from pathlib import Path
import datetime
import re
import shutil

root = Path(__file__).resolve().parent
static = root / "static"
engine = static / "app.js"
index = static / "index.html"

if not engine.exists() or not index.exists():
    raise SystemExit("Arquivos principais nao encontrados.")

html = index.read_text(encoding="utf-8")

# Identificar a versao realmente carregada.
active = re.findall(
    r'<script[^>]+src=["\'][^"\']*/(stage8\d+\.js)',
    html,
    flags=re.I
)

if not active:
    raise SystemExit(
        "Nenhum stage8xx.js ativo encontrado no HTML."
    )

stage = static / active[-1]

if not stage.exists():
    raise SystemExit(
        "Arquivo ativo inexistente: " + stage.name
    )

marker = "/* NS_FIRST_VALID_LYRIC_GATE */"

helper = '''
/* NS_FIRST_VALID_LYRIC_GATE */
function nsFirstValidLyricTime(chart) {
    const lines = chart?.lyric_lines || [];
    const starts = lines
        .filter(line => String(line.text || "").trim())
        .map(line => Number(line.at ?? line.start))
        .filter(Number.isFinite);

    if (starts.length) return Math.min(...starts);

    const notes = chart?.notes || [];
    const noteStarts = notes
        .map(n => Number(n.start))
        .filter(Number.isFinite);

    return noteStarts.length
        ? Math.min(...noteStarts)
        : 0;
}
'''

engineSource = engine.read_text(encoding="utf-8")
stageSource = stage.read_text(encoding="utf-8")

# O motor original pode usar qualquer versao de stage.
# A alteracao fica concentrada na selecao de notas.
if marker not in engineSource:
    engineSource = helper + "\n" + engineSource

if marker not in stageSource:
    stageSource = helper + "\n" + stageSource

engineOld = "const notes=chart.notes;"
engineNew = (
    "const notes=chart.notes.filter(n=>"
    "Number(n.start)>=nsFirstValidLyricTime(chart)-0.02);"
)

if engineNew not in engineSource:
    if engineOld not in engineSource:
        raise SystemExit(
            "Estrutura do motor de pontuacao inesperada."
        )
    engineSource = engineSource.replace(
        engineOld, engineNew, 1
    )

# Substituir apenas as duas leituras de notas no
# desenho da pista e no medidor da multidao.
stageOld1 = "notes=s?.chart?.notes||[]"
stageNew1 = (
    "notes=(s?.chart?.notes||[]).filter(n=>"
    "Number(n.start)>=nsFirstValidLyricTime(s?.chart)-0.02)"
)

stageOld2 = "const notes=s.chart?.notes||[];"
stageNew2 = (
    "const notes=(s.chart?.notes||[]).filter(n=>"
    "Number(n.start)>=nsFirstValidLyricTime(s.chart)-0.02);"
)

if stageNew1 not in stageSource:
    if stageOld1 not in stageSource:
        raise SystemExit(
            "Nao encontrei a leitura de notas da pista."
        )
    stageSource = stageSource.replace(
        stageOld1, stageNew1, 1
    )

if stageNew2 not in stageSource:
    if stageOld2 not in stageSource:
        raise SystemExit(
            "Nao encontrei a leitura de notas do medidor."
        )
    stageSource = stageSource.replace(
        stageOld2, stageNew2, 1
    )

# Fazer backup antes de gravar qualquer arquivo.
backup = root / (
    "backup_inicio_vocal_" +
    datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
)
backup.mkdir()

for path in (engine, stage):
    shutil.copy2(path, backup / path.name)

# Gravar somente JS. Nao alterar HTML ou charts.
engine.write_text(engineSource, encoding="utf-8")
stage.write_text(stageSource, encoding="utf-8")

print()
print("CORRECAO DO INICIO VOCAL APLICADA")
print("Motor:", engine.name)
print("Palco ativo:", stage.name)
print("Backup:", backup)
print()
print("Notas preliminares: ignoradas")
print("Pontuacao: somente apos primeira letra valida")
print("Multidao: sem penalidade na introducao")
print("Chart original: preservado")
