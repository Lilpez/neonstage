"""NeonStage V8.4 - align external lyrics to ASR vocal timeline without late-only anchors.
The words coming from ASR are never shown as lyrics.
"""
import re
import unicodedata
import difflib
import statistics

HEADER = re.compile(r'(?i)^\s*(?:(?:.{1,100}?)\s+lyrics\s*(?:\[[^\]]{0,150}\])?|\[?letra de[^\]]*\]?)\s*')
JUNK = re.compile(r'(?i)\b(?:you might also like|contributors|embed|read more)\b')

def clean_text(text):
    s=str(text or '').strip()
    for _ in range(3):
        after=HEADER.sub('',s).strip()
        if after==s:break
        s=after
    return re.sub(r'\s+',' ',s)

def _norm(s):
    s=unicodedata.normalize('NFKD',str(s)).encode('ascii','ignore').decode().lower()
    return re.sub('[^a-z0-9]+','',s)

def _asr_timeline(asr_words):
    entries=[]
    for w in asr_words:
        try:
            a=float(w['start']); b=float(w.get('end',a+0.3))
            if a>=0 and b>a and b-a<=5.0:
                entries.append((a,b,str(w.get('text',''))))
        except (ValueError,TypeError,KeyError):pass
    entries.sort()
    return entries

def overlay_lines(verified_lines,asr_words):
    lines=[]
    for v in verified_lines:
        t=clean_text(v.get('text','') if isinstance(v,dict) else str(v))
        if t and not JUNK.search(t): lines.append(t)
    if not lines:return []
    timeline=_asr_timeline(asr_words)
    if not timeline:return []
    tokens=[];owners=[]
    for li,line in enumerate(lines):
        for word in line.split():
            n=_norm(word)
            if n:tokens.append(n);owners.append(li)
    if not tokens:return []
    # Primary schedule follows the *entire* ASR activity, not only rare matching words.
    # Equal fractions of word count correspond to fractions of transcribed vocal-word sequence.
    starts=[w[0] for w in timeline]
    total=len(tokens)
    first_token={}
    for j,li in enumerate(owners):first_token.setdefault(li,j)
    baseline=[]
    for i in range(len(lines)):
        pos=first_token.get(i,0)*max(0,len(timeline)-1)/max(1,total-1)
        lo=int(pos);hi=min(len(timeline)-1,lo+1)
        baseline.append(starts[lo]+(starts[hi]-starts[lo])*(pos-lo))

    # Look for word matches; individual matches are untrustworthy for repeated choruses.
    asr=[_norm(w[2]) for w in timeline]
    matcher=difflib.SequenceMatcher(None,asr,tokens,autojunk=False)
    candidates={}
    for block in matcher.get_matching_blocks():
        if block.size<3:continue
        for k in range(block.size):
            ai=block.a+k; li=owners[block.b+k]
            candidates.setdefault(li,[]).append(starts[ai])
    # Trust only anchors close to baseline (which is based on full vocal activity),
    # never pull the early lines into a later chorus.
    safe={}
    for li,ts in candidates.items():
        t=statistics.median(ts)
        if abs(t-baseline[li])<=max(4.0,min(10.0,(starts[-1]-starts[0])*.04)):
            safe[li]=t
    # Blend, not replace: avoid abrupt warping from a single matching segment.
    estimate=[(.70*baseline[i]+.30*safe[i]) if i in safe else baseline[i] for i in range(len(lines))]
    out=[]
    for i,t in enumerate(estimate):
        if out:t=max(t,out[-1]['at']+.04)
        out.append({'at':round(min(starts[-1],t),3),'text':lines[i]})
    return out
