/* NeonStage Party: PC listens to the phone's start command. */
(()=>{
'use strict';
if(window.__NS_PARTY_REMOTE_PC__) return;
window.__NS_PARTY_REMOTE_PC__=true;
if(location.pathname!=='/palco')return;
const $=id=>document.getElementById(id);
let busy=false, activeKey='', retryKey='', warning=null, counter=0, dismissed=new Set();
const audio=()=>$('gameAudio');
const isSinging=()=>window.NEON_PARTY?.isPlaying?.()===true;
function notice(message,needsClick=false){
 if(!warning){warning=document.createElement('aside');warning.id='nsRemoteNotice';warning.style.cssText='position:fixed;z-index:999999;bottom:30px;left:50%;transform:translateX(-50%);background:rgba(11,15,32,.97);color:white;border:1px solid rgba(132,240,251,.55);padding:16px 20px;border-radius:16px;box-shadow:0 12px 65px #000b;display:flex;gap:16px;align-items:center;max-width:95vw;font:600 14px system-ui';warning.innerHTML='<span id="nsRemoteLabel"></span><button id="nsRemoteActivate" style="background:#6ce2ed;color:#08101c;border:0;border-radius:10px;padding:11px 15px;font:800 13px system-ui;cursor:pointer">Ativar audio e microfone</button>';document.body.append(warning);warning.querySelector('button').onclick=async()=>{const key=retryKey;retryKey='';if(isSinging()&&audio()?.paused){try{await audio().play();hideNotice();return}catch(e){console.warn('[NeonStage Party] audio:',e)}}if(key){activeKey='';dismissed.delete(key)}hideNotice();check()};}
 warning.querySelector('#nsRemoteLabel').textContent=message;warning.querySelector('button').style.display=needsClick?'':'none';
}
function hideNotice(){warning?.remove();warning=null}
async function check(){
 if(busy||!window.NEON_PARTY||!$('gameAudio'))return;
 busy=true;
 try{
  const res=await fetch('/api/party/state',{cache:'no-store'});if(!res.ok)return;
  const s=await res.json();
  if(s.phase!=='singing'||!s.playback?.song_id){
   if(!isSinging()){activeKey='';retryKey='';hideNotice()}
   return;
  }
  const entry=s.queue?.[s.position];if(!entry)return;
  const key=String(s.position)+'|'+s.playback.song_id;
  if(isSinging()){
   activeKey=key;
   if(audio()?.paused){retryKey=key;notice('O celular iniciou a música, mas o navegador bloqueou a reprodução. Ative o áudio aqui uma vez.',true)}
   else hideNotice();
   return;
  }
  if(activeKey===key || dismissed.has(key))return;
  activeKey=key;
  const singer=s.players?.[entry.singer]?.name||'Convidado';
  try{
   await window.NEON_PARTY.begin(s.playback.song_id,singer);
   if(audio()?.paused){retryKey=key;notice('Autorize o áudio e o microfone neste PC para continuar a apresentação.',true)}
   else hideNotice();
  }catch(err){
   retryKey=key;
   notice('O início remoto está pronto, mas precisa de autorização neste navegador: '+(err?.message||'Verifique o microfone'),true);
   console.warn('[NeonStage Party] inicio remoto:',err);
  }
 }catch(err){if(++counter%30===1)console.debug('[NeonStage Party] aguardando servidor:',err)}
 finally{busy=false}
}
setInterval(check,1100);check();
})();
