(()=>{'use strict';
if(window.__NEON_CONSOLIDATED_9__)return;window.__NEON_CONSOLIDATED_9__=true;
const $=id=>document.getElementById(id),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const getState=()=>{try{return state}catch{return null}};
const store=(k,v)=>localStorage.setItem('neon9_'+k,JSON.stringify(v));
const read=(k,def)=>{try{return JSON.parse(localStorage.getItem('neon9_'+k))??def}catch{return def}};
let profile=read('profile',{name:'Convidado',avatar:''}),queue=read('queue',[]),mixer=read('mixer',{monitor:0,reverb:0,music:100,vocal:80,pitch:0,mic:'',output:'',preset:'studio',compression:-21,tone:3});
if(!mixer.preset)mixer.preset='studio';if(mixer.compression==null)mixer.compression=-21;if(mixer.tone==null)mixer.tone=3;
// One-time migration: legacy preset monitor levels were 20-28%, then attenuated again.
if(localStorage.getItem('neon12_audio_upgrade')!=='1'){
 if(mixer.monitor>=0&&mixer.monitor<=32)mixer.monitor=80;
 localStorage.setItem('neon12_audio_upgrade','1');localStorage.setItem('neon9_mixer',JSON.stringify(mixer));
}
let streamGraph=null,track=null,trackId='',finishTimer=null,remoteState=null,remoteBusy=false,lastSong='',duetSplit=new Array(10).fill(0),duetLastScore=0,duetVoice=null,duetKey='';
const liveAudio=$('gameAudio');
const saveMixer=()=>store('mixer',mixer);
function showError(msg){try{toast(msg)}catch{alert(msg)}}
function card(parent,title,html){const el=document.createElement('section');el.className='ns-next-card';el.innerHTML='<h3>'+title+'</h3>'+html;parent.appendChild(el);return el}
function avatarHtml(){return profile.avatar?`<img class="ns-next-profile-photo" src="${profile.avatar}" alt="Seu avatar">`:`<span class="ns-next-profile-photo">${esc((profile.name||'C')[0])}</span>`}
function profileButton(){const btn=$('profileButton');if(!btn)return;btn.title='Editar perfil local';btn.textContent=profile.avatar?'':(profile.name||'Convidado').slice(0,12);btn.classList.toggle('ns-next-profile-btn',!!profile.avatar);btn.style.backgroundImage=profile.avatar?`url(${profile.avatar})`:'';btn.onclick=profileEditor}
function profileEditor(){const overlay=document.createElement('div');overlay.className='ns-next-overlay';overlay.innerHTML=`<section class="ns-next-modal"><div class="eyebrow">PERFIL LOCAL • SEM CONTA</div><h2>Seu nome no palco</h2><div id="ns9AvatarPreview">${avatarHtml()}</div><label>NOME</label><input id="ns9ProfileName" maxlength="25" placeholder="Nome de palco" value="${esc(profile.name)}"><label>FOTO DO COMPUTADOR</label><input id="ns9ProfileFile" type="file" accept="image/*"><p class="ns-next-help">A foto e o nome ficam salvos somente neste navegador. Não existe login nem envio para terceiros.</p><div class="ns-next-actions"><button class="primary" id="ns9ProfileSave">SALVAR PERFIL</button><button class="ghost" id="ns9ProfileCancel">CANCELAR</button></div></section>`;document.body.append(overlay);let nextPhoto=profile.avatar;$('ns9ProfileCancel').onclick=()=>overlay.remove();$('ns9ProfileFile').onchange=async e=>{const f=e.target.files[0];if(!f)return;try{if(f.size>12e6)throw Error('Imagem muito grande.');const bmp=await createImageBitmap(f);const c=document.createElement('canvas');c.width=c.height=160;const g=c.getContext('2d');const k=Math.max(160/bmp.width,160/bmp.height);g.drawImage(bmp,(160-bmp.width*k)/2,(160-bmp.height*k)/2,bmp.width*k,bmp.height*k);bmp.close?.();nextPhoto=c.toDataURL('image/jpeg',.75);$('ns9AvatarPreview').innerHTML=`<img class="ns-next-profile-photo" alt="Prévia" src="${nextPhoto}">`}catch(err){showError(err.message)}};$('ns9ProfileSave').onclick=()=>{profile={name:$('ns9ProfileName').value.trim().slice(0,25)||'Convidado',avatar:nextPhoto};store('profile',profile);localStorage.setItem('neon_player1',profile.name);profileButton();overlay.remove()}}
// Playlist independent of the existing library renderer. Do not replace/delete music cards.
function list(){const c=$('ns9PlaylistList');if(!c)return;const songs=getState()?.library||[];queue=queue.filter(id=>songs.some(x=>x.id===id));store('queue',queue);c.innerHTML=queue.map((id,i)=>{const song=songs.find(x=>x.id===id);return `<div class="ns-next-item"><span>${i+1}</span><div><b>${esc(song?.title||id)}</b><small>${esc(song?.artist||'')}</small></div><button data-remove="${i}" class="ghost">REMOVER</button></div>`}).join('')||'<div class="ns-next-empty">Playlist vazia. Use “+ PLAYLIST” nos cartões da biblioteca.</div>';$('ns9QueueCount').textContent=queue.length+' músicas';c.querySelectorAll('[data-remove]').forEach(b=>b.onclick=()=>{queue.splice(+b.dataset.remove,1);store('queue',queue);list()})}
function addToQueue(songId){const songs=getState()?.library||[];if(!songs.some(s=>s.id===songId))return;if(queue.length>=80)return showError('Playlist limitada a 80 músicas.');queue.push(songId);store('queue',queue);list()}
function playNext(){const songs=getState()?.library||[];while(queue.length){let id=queue.shift();store('queue',queue);list();const song=songs.find(s=>s.id===id);if(song){if(finishTimer){clearTimeout(finishTimer);finishTimer=null}const overlay=$('ns9NextOverlay');overlay?.remove();modal('finishOverlay',false);getState().selected=song;if(profile?.name)$('name1').value=profile.name;beginSong();return}}showError('A playlist terminou.');}
function playlist(){const el=$('librarySection');if(!el)return;let cardEl=card(el,'Minha playlist',`<div class="ns-next-actions"><span id="ns9QueueCount" class="pill">0 músicas</span><button id="ns9QueuePlay" class="primary">CANTAR PLAYLIST</button><button id="ns9QueueClear" class="ghost">LIMPAR LISTA</button></div><div class="ns-next-list" id="ns9PlaylistList"></div><p class="ns-next-help">Clique na capa para cantar apenas uma música ou use + PLAYLIST para montar uma sequência.</p>`);cardEl.id='ns9QueueCard';$('ns9QueuePlay').onclick=()=>playNext();$('ns9QueueClear').onclick=()=>{if(confirm('Esvaziar a playlist?')){queue=[];store('queue',queue);list()}};
 const grid=$('libraryGrid');if(grid){const attach=()=>{for(const el of grid.querySelectorAll('.album[data-song]')){if(el.querySelector('.ns-add-queue'))continue;const b=document.createElement('button');b.type='button';b.className='ns-add-queue';b.textContent='+ PLAYLIST';b.onclick=e=>{e.preventDefault();e.stopPropagation();addToQueue(el.dataset.song)};el.append(b)}};new MutationObserver(attach).observe(grid,{childList:true});attach()}list()}
function audioRow(id,label,min,max,value,step=1,unit='%'){return `<div class="ns-next-audio-row"><label for="${id}">${label}</label><input type="range" id="${id}" min="${min}" max="${max}" step="${step}" value="${value}"><output id="${id}Out">${value}${unit}</output></div>`}
function createMixer(){
 const panel=$('settingsSection');if(!panel)return;
 const el=card(panel,'Estúdio vocal',`<p class="ns-next-help">Use fones de ouvido para evitar microfonia. Escolha o microfone na seção Dispositivo de entrada.</p>
 ${audioRow('ns9Music','Volume da música',0,100,mixer.music)}
 ${audioRow('ns9Voice','Volume do vocal original',0,100,mixer.vocal)}
 <p id="ns9VoiceNote" class="ns-next-help">A remoção independente da voz depende dos stems da música. A separação pode ser solicitada no palco.</p>
 ${audioRow('ns9Monitor','Retorno do microfone',0,100,mixer.monitor)}
 ${audioRow('ns9Reverb','Reverb da minha voz',0,100,mixer.reverb)}
 ${audioRow('ns9Pitch','Tom (semitons)',-5,5,mixer.pitch,1,' st')}
 <p class="ns-next-help">A transposição disponível altera também a velocidade. Os efeitos atuam no retorno da sua voz; não incluem autotune.</p>`);
 el.id='ns9AudioSettings';
 const wire=(id,key,postfix='%')=>{const inp=$(id);inp.oninput=()=>{mixer[key]=Number(inp.value);const out=$(id+'Out');if(out)out.textContent=mixer[key]+postfix;if(key==='monitor'||key==='reverb'){mixer.preset='custom';document.querySelectorAll('#ns10PresetGroup [data-preset]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.preset==='custom')));$('ns10PresetGroup')?.classList.add('ns10-custom-active')}saveMixer();applyAudio();syncPresetControls()}};
 wire('ns9Music','music');wire('ns9Voice','vocal');wire('ns9Monitor','monitor');wire('ns9Reverb','reverb');wire('ns9Pitch','pitch',' st');
 const sel=$('nsDevMic');sel?.addEventListener('change',()=>{mixer.mic=sel.value;saveMixer()});
 setTimeout(()=>{if(sel&&[...sel.options].some(o=>o.value===mixer.mic))sel.value=mixer.mic},900);
}

function setMic(){const mic=$('mic1');if(mic&&mixer.mic&&[...mic.options].some(o=>o.value===mixer.mic))mic.value=mixer.mic;}
function impulse(ctx){const size=Math.round(ctx.sampleRate*1.55),b=ctx.createBuffer(2,size,ctx.sampleRate);for(let ch=0;ch<2;ch++){let d=b.getChannelData(ch);for(let i=0;i<size;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/size,3)}return b}
/* NS13_REVERB_PRESET_UPDATE */
const voicePresets={
 clean:{reverb:0,compression:-14,tone:0,monitor:78,ratio:2.1,highpass:100,lowpass:18000},
 studio:{reverb:20,compression:-23,tone:3.5,monitor:85,ratio:3.8,highpass:95,lowpass:17000},
 stage:{reverb:50,compression:-26,tone:2,monitor:85,ratio:4.2,highpass:120,lowpass:16000},
 cathedral:{reverb:100,compression:-24,tone:1.5,monitor:83,ratio:3.4,highpass:110,lowpass:16500},
 pop:{reverb:12,compression:-29,tone:5.5,monitor:86,ratio:5.2,highpass:125,lowpass:18500},
 radio:{reverb:0,compression:-27,tone:6,monitor:82,ratio:4.8,highpass:450,lowpass:3500},
 robot:{reverb:8,compression:-24,tone:-3,monitor:82,ratio:5.5,highpass:155,lowpass:10500}
};
// Upgrade saved built-in presets once; never overwrite the custom mix.
if(localStorage.getItem('neon13_reverb_upgrade')!=='1'){
 const selected=voicePresets[mixer.preset];
 if(selected){mixer.reverb=selected.reverb;saveMixer();}
 localStorage.setItem('neon13_reverb_upgrade','1');
}
function syncPresetControls(){
 const display=[['ns9Monitor','monitor','%'],['ns9Reverb','reverb','%'],
 ['ns10CustomReverb','reverb','%'],['ns10Comp','compression',' dB'],['ns10Tone','tone',' dB'],
 ['ns9LiveMonitor','monitor','%']];
 for(const [id,key,unit] of display){
  const input=$(id);if(!input)continue;
  input.value=mixer[key];
  const out=$(id+'Out');if(out)out.textContent=String(mixer[key])+unit;
 }
 const live=$('ns10LivePreset');if(live&&[...live.options].some(x=>x.value===mixer.preset))live.value=mixer.preset;
 const group=$('ns10PresetGroup');
 if(group){group.classList.toggle('ns10-custom-active',mixer.preset==='custom');
 group.querySelectorAll('[data-preset]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.preset===mixer.preset)));}
}
function presetUI(){const settings=$('ns9AudioSettings');if(!settings||$('ns10PresetGroup'))return;
 const div=document.createElement('div');div.id='ns10PresetGroup';div.innerHTML=`<label>EFEITO VOCAL</label><div class="ns10-presets">${Object.entries({clean:'Limpo - 0%',studio:'Est\u00fadio - 20%',stage:'Palco - 50%',cathedral:'Catedral - 100%',pop:'Pop - 12%',radio:'R\u00e1dio - 0%',robot:'Rob\u00f4 - 8%',custom:'Personalizado'}).map(([id,n])=>`<button type="button" data-preset="${id}">${n}</button>`).join('')}</div><section id="ns10Custom" class="ns-next-card"><strong>Ajuste fino</strong>${audioRow('ns10Comp','Compressor (limiar)',-42,-6,mixer.compression,1,' dB')}${audioRow('ns10Tone','Timbre / presença',-12,12,mixer.tone,1,' dB')}${audioRow('ns10CustomReverb','Reverb',0,100,mixer.reverb)}</section><p class="ns-next-help">Efeitos aplicados ao retorno de voz. Use fones de ouvido. Não é autotune.</p>`;
 settings.insertBefore(div,settings.querySelector('#ns9Monitor')?.closest('.ns-next-audio-row')||settings.lastChild);
 const refresh=()=>{div.classList.toggle('ns10-custom-active',mixer.preset==='custom');div.querySelectorAll('[data-preset]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.preset===mixer.preset)))};
 div.querySelectorAll('[data-preset]').forEach(b=>b.onclick=()=>{
  mixer.preset=b.dataset.preset;
  const existingMonitor=mixer.monitor;
  if(voicePresets[mixer.preset])Object.assign(mixer,voicePresets[mixer.preset]);
  mixer.monitor=existingMonitor; // Presets never lower the user's monitor volume.
  saveMixer();applyAudio();syncPresetControls();refresh();
 });
 for(const [id,key,unit] of [['ns10Comp','compression',' dB'],['ns10Tone','tone',' dB'],['ns10CustomReverb','reverb','%']])$(id).oninput=()=>{mixer.preset='custom';mixer[key]=Number($(id).value);$(id+'Out').textContent=mixer[key]+unit;saveMixer();applyAudio();syncPresetControls();refresh()};
 refresh();
}
function connectMonitor(){
 const s=getState(),p=s?.players?.[0];if(!s?.ctx||!p?.source)return;
 if(streamGraph?.ctx===s.ctx&&streamGraph?.source===p.source)return;
 if(streamGraph?.osc)try{streamGraph.osc.stop()}catch{}
 if(streamGraph?.source)try{streamGraph.source.disconnect(streamGraph.highpass)}catch{}
 streamGraph=null;
 const ctx=s.ctx;
 const highpass=ctx.createBiquadFilter();highpass.type='highpass';highpass.frequency.value=95;
 const equalizer=ctx.createBiquadFilter();equalizer.type='peaking';equalizer.frequency.value=2800;equalizer.Q.value=.75;
 const filter=ctx.createBiquadFilter();filter.type='lowpass';filter.frequency.value=17000;
 const compressor=ctx.createDynamicsCompressor();
 const tremolo=ctx.createGain(),dry=ctx.createGain(),wet=ctx.createGain(),conv=ctx.createConvolver();
 const limiter=ctx.createDynamicsCompressor();limiter.threshold.value=-3;limiter.ratio.value=12;limiter.attack.value=.002;limiter.release.value=.13;
 conv.buffer=impulse(ctx);
 p.source.connect(highpass);highpass.connect(equalizer);equalizer.connect(filter);filter.connect(compressor);compressor.connect(tremolo);
 tremolo.connect(dry);dry.connect(limiter);compressor.connect(conv);conv.connect(wet);wet.connect(limiter);limiter.connect(ctx.destination);
 streamGraph={ctx,source:p.source,highpass,dry,wet,conv,compressor,equalizer,filter,tremolo,limiter,osc:null};applyAudio();
}
function applyAudio(){
 const vol=Math.max(0,Math.min(1,(mixer.music??100)/100));
 if(liveAudio){liveAudio.volume=vol;const sem=Number(mixer.pitch)||0;liveAudio.preservesPitch=false;liveAudio.playbackRate=Math.pow(2,sem/12);if(mixer.output&&liveAudio.setSinkId)liveAudio.setSinkId(mixer.output).catch(()=>{})}
 if(streamGraph){
  const g=streamGraph, preset=voicePresets[mixer.preset]||voicePresets.studio;
  // Audible dry level remains consistent when a new input device is selected.
  // Reverb is a real wet/dry balance: 0%=dry, 50%=mix, 100%=wet only.
  const level=Math.max(0,Math.min(1,Number(mixer.monitor??80)/100));
  const balance=Math.max(0,Math.min(1,(Number(mixer.reverb)||0)/100));
  const dryLevel=level*Math.cos(balance*Math.PI/2)*.95;
  const wetLevel=level*Math.sin(balance*Math.PI/2)*.85;
  g.dry.gain.setTargetAtTime(dryLevel,g.ctx.currentTime,.035);
  g.wet.gain.setTargetAtTime(wetLevel,g.ctx.currentTime,.035);
  g.compressor.threshold.value=Number(mixer.compression??-21);
  g.compressor.ratio.value=preset.ratio??3.8;
  g.compressor.attack.value=mixer.preset==='pop'?.003:.009;
  g.compressor.release.value=mixer.preset==='stage'?.3:.20;
  g.equalizer.gain.value=Number(mixer.tone)||0;
  g.highpass.frequency.value=preset.highpass??95;
  g.filter.frequency.value=preset.lowpass??17000;
  if(mixer.preset==='robot'&&!g.osc){const osc=g.ctx.createOscillator(),mod=g.ctx.createGain();osc.type='sine';osc.frequency.value=32;mod.gain.value=.36;osc.connect(mod);mod.connect(g.tremolo.gain);g.tremolo.gain.value=.58;osc.start();g.osc=osc;g.oscMod=mod}
  else if(mixer.preset!=='robot'&&g.osc){try{g.osc.stop()}catch{}g.osc.disconnect();g.oscMod?.disconnect();g.osc=null;g.tremolo.gain.value=1}
 }
 if(track){track.volume=vol*(mixer.vocal??80)/100;track.playbackRate=liveAudio.playbackRate;track.preservesPitch=false;}
}

function syncTrack(){const s=getState();if(!s?.playing){if(track){track.pause();track.remove();track=null;trackId=''}streamGraph=null;return}connectMonitor();if(!track&&s.chart?.mix_stems?.vocals){track=new Audio(s.chart.mix_stems.vocals);track.preload='auto';trackId=s.chart.id;track.currentTime=liveAudio.currentTime;applyAudio();track.play().catch(()=>{})}if(track){if(liveAudio.paused){if(!track.paused)track.pause()}else if(track.paused)track.play().catch(()=>{});if(track.readyState>=1&&Math.abs(track.currentTime-liveAudio.currentTime)>.20){try{track.currentTime=liveAudio.currentTime}catch{}}}}
function onBegin(){setMic();applyAudio();}
function setupLive(){const btn=$('profileButton');profileButton();$('name1').value=profile.name||'Convidado';
 const game=$('gameScreen');const bar=document.createElement('div');bar.id='ns9LiveControls';bar.className='ns-next-live-controls';bar.innerHTML='<button id="ns9AudioBtn">ÁUDIO</button><button id="ns9PlaylistSkip">PRÓXIMA MÚSICA</button>';game.append(bar);$('ns9AudioBtn').onclick=()=>audioPopup();$('ns9PlaylistSkip').onclick=async()=>{const s=getState();if(s?.partyActive)return;await stopGame();playNext()};
 new MutationObserver(()=>{if(!$('setupOverlay').classList.contains('hidden')){setTimeout(setMic,200);$('name1').value=profile.name||'Convidado'}}).observe($('setupOverlay'),{attributes:true,attributeFilter:['class']});
 liveAudio?.addEventListener('ended',()=>{if(getState()?.partyActive||queue.length===0)return;setTimeout(()=>{if(!getState()?.playing&&queue.length)playlistCountdown()},160)});
}
function audioPopup(){
 let el=$('ns9AudioPopup');if(el){el.remove();return}
 el=document.createElement('aside');el.id='ns9AudioPopup';el.className='ns11-audio-drawer';
 el.setAttribute('aria-label','Controle rapido de audio');
 el.innerHTML=`<div class="ns11-drawer-head"><strong>Áudio do palco</strong><button type="button" id="ns9CloseAudio" aria-label="Fechar">X</button></div>
 <label for="ns10LivePreset">Efeito vocal</label><select id="ns10LivePreset"><option value="clean">Limpo</option><option value="studio">Estúdio</option><option value="stage">Palco</option><option value="cathedral">Catedral (100%)</option><option value="pop">Pop</option><option value="radio">Rádio</option><option value="robot">Robô</option><option value="custom">Personalizado</option></select>
 ${audioRow('ns9LiveVoice','Voz do artista',0,100,mixer.vocal)}${audioRow('ns9LiveMonitor','Meu microfone',0,100,mixer.monitor)}
 <p class="ns11-stem-note" id="ns11StemStatus"></p><button class="ns11-separate" type="button" id="ns11Separate">Separar voz da faixa</button>
 <p class="ns11-stem-note">Ajustes completos, reverb e compressor: Configurações. Use fones para evitar microfonia.</p>`;
 ($('ns828Stage')||$('gameScreen')||document.body).append(el);
 const fields=[['ns9LiveVoice','vocal'],['ns9LiveMonitor','monitor']];
 fields.forEach(([id,key])=>{$(id).oninput=()=>{mixer[key]=Number($(id).value);$(id+'Out').textContent=mixer[key]+'%';saveMixer();applyAudio()}});
 $('ns10LivePreset').value=mixer.preset;
 $('ns10LivePreset').onchange=()=>{mixer.preset=$('ns10LivePreset').value;const existingMonitor=mixer.monitor;if(voicePresets[mixer.preset])Object.assign(mixer,voicePresets[mixer.preset]);mixer.monitor=existingMonitor;saveMixer();applyAudio();syncPresetControls()};
 $('ns9CloseAudio').onclick=()=>el.remove();
 const song=getState()?.chart,id=song?.id;
 $('ns11StemStatus').textContent=song?.mix_stems?'Stems ativos: volume vocal independente.':'Sem stems: o volume do vocal nao pode ser reduzido isoladamente.';
 $('ns11Separate').style.display=song?.mix_stems?'none':'block';
 $('ns11Separate').onclick=async()=>{
  if(!id)return void($('ns11StemStatus').textContent='Musica sem ID.');
  $('ns11Separate').disabled=true;
  try{const response=await fetch('/api/neon/separate/'+encodeURIComponent(id),{method:'POST'}),data=await response.json();if(!response.ok)throw Error(data.error||'Falha');
   if(data.ready){$('ns11StemStatus').textContent='Stems prontos. Reinicie esta musica.';return}
   $('ns11StemStatus').textContent='Demucs separando voz em segundo plano. A atualizacao sera aplicada ao reiniciar a musica.';
  }catch(e){$('ns11StemStatus').textContent=String(e.message)}finally{$('ns11Separate').disabled=false}
 };
}
window.NEON11_OPEN_AUDIO=audioPopup;
function playlistCountdown(){if($('ns9NextOverlay')||getState()?.partyActive)return;const el=document.createElement('div');el.id='ns9NextOverlay';el.className='ns-next-finale';el.innerHTML='<section><h2>Playlist em andamento</h2><p>A próxima música começa em <strong id="ns9Count">5</strong> segundos</p><button id="ns9NextNow">PRÓXIMA AGORA</button><button id="ns9NextCancel">PARAR PLAYLIST</button></section>';document.body.append(el);let n=5;$('ns9NextNow').onclick=()=>playNext();$('ns9NextCancel').onclick=()=>{clearInterval(finishTimer);finishTimer=null;el.remove();queue=[];store('queue',queue);list()};finishTimer=setInterval(()=>{n--;$('ns9Count')&&($('ns9Count').textContent=String(n));if(n<=0){clearInterval(finishTimer);finishTimer=null;playNext()}},1000)}
function rankPhoto(p){return p?.avatar?.startsWith('data:image/')?`<img src="${p.avatar}" alt="">`:`<span>${esc((p?.name||'?')[0])}</span>`}
function renderDuet(s){
 const game=$('gameScreen'),entry=s.queue?.[s.position];let box=$('ns9Duet');
 const duet=s.phase==='singing'&&Boolean(entry?.duet);
 window.NEON10_DUET_ACTIVE=duet;const label=$('ns828Pname');if(label&&duet)label.textContent='PLATEIA';
 if(!duet||!game||game.classList.contains('hidden')){box?.remove();return}
 if(!box){box=document.createElement('div');box.id='ns9Duet';box.className='ns-next-duet ns10-turn';($('ns828Stage')||game).append(box)}
 const time=liveAudio?.currentTime||0,segs=s.duet_segments||[];let current=entry.singer;
 let allSing=false;for(const part of segs){if(part.at<=time+.12){current=part.singer;allSing=!!part.all_sing;}else break}
 const next=segs.find(x=>x.at>time+.12&&x.singer!==current),p=s.players[current],q=s.players[next?.singer];
 const colors=s.colors||['#be78e9','#45c7e6','#ff8a8e','#f6c76e','#88e4a1','#9e9aff','#ffab6e','#d58dcf','#8be9db','#c6c6ff'];
 if(box.dataset.singer!==String(current)){
   box.dataset.singer=String(current);box.style.setProperty('--ns10-accent',colors[current%colors.length]);
   box.innerHTML=`<small>${allSing?'TODOS CANTAM • REFRÃO':s.mode==='duet'?'EQUIPE • SUA VEZ':'PASSA O MIC'}</small><div class="ns-next-duet-pics">${p?.avatar?.startsWith('data:image/')?`<img src="${p.avatar}" alt="">`:`<span class="ns10-avatar">${esc((p?.name||'?')[0])}</span>`}<span class="ns10-name">${esc(p?.name||'Convidado')}</span></div><div class="ns10-next" id="ns10NextSinger"></div>`;
 }
 box.classList.toggle('ns11-all-singing',allSing);const kind=box.querySelector('small');if(kind)kind.textContent=allSing?'TODOS CANTAM • REFRÃO':s.mode==='duet'?'EQUIPE • SUA VEZ':'PASSA O MIC';const nextEl=box.querySelector('#ns10NextSinger');if(nextEl)nextEl.textContent=next?'PRÓXIMO: '+(q?.name||'Convidado')+' em '+Math.max(0,Math.ceil(next.at-time))+'s':'ÚLTIMO TURNO';
 if(duetKey!==String(s.position)+'|'+s.playback?.song_id){duetSplit=Array(10).fill(0);duetLastScore=0;duetKey=String(s.position)+'|'+s.playback?.song_id}
 const currentScore=getState()?.players?.[0]?.score||0,delta=Math.max(0,currentScore-duetLastScore);
 if(allSing){const singers=entry.singers||[current];const share=delta/Math.max(1,singers.length);for(const i of singers)duetSplit[i]=(duetSplit[i]||0)+share}else duetSplit[current]=(duetSplit[current]||0)+delta;duetLastScore=currentScore;
}
function partyScoreSplit(){return duetSplit.map(x=>Math.round(x))}
window.NEON_DUET={split:partyScoreSplit,live:partyScoreSplit};
window.NEON_TRANSPOSE=()=>Number(mixer.pitch)||0;
async function pollParty(){if(remoteBusy)return;remoteBusy=true;try{const r=await fetch('/api/party/state',{cache:'no-store'});if(!r.ok)return;remoteState=await r.json();renderDuet(remoteState)}catch{}finally{remoteBusy=false}}
function partySafe(){const s=getState();$('ns9PlaylistSkip').style.display=s?.partyActive?'none':'';const bar=$('ns9LiveControls');bar.style.display=s?.playing?'flex':'none';if(s?.playing)syncTrack();else syncTrack();if($('ns9VoiceNote'))$('ns9VoiceNote').textContent=s?.chart?.mix_stems?'Vocal e instrumental separados. Ajuste o nível do vocal.':'Sem stems: a faixa original permanece no mix. Para remover voz, selecione a música e use Separar voz.'}
// Changes in Settings propagate to the dedicated /palco tab.
window.addEventListener('storage',e=>{if(e.key==='neon9_mixer'&&e.newValue){try{Object.assign(mixer,JSON.parse(e.newValue));applyAudio();syncPresetControls()}catch{}}});
// UI boot
profileButton();playlist();createMixer();presetUI();setupLive();applyAudio();setInterval(partySafe,200);setInterval(pollParty,1100);pollParty();
})();
