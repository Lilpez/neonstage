(()=>{
'use strict';
const $=id=>document.getElementById(id);
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let chosen='',loadedId='',approved=null,loading=false;
const photoMarkup=(p,size=48)=>p?.avatar?`<img src="${p.avatar}" alt="" style="width:${size}px;height:${size}px;object-fit:cover;border-radius:50%;border:2px solid #a87fff">`:`<div style="width:${size}px;height:${size}px;border-radius:50%;display:grid;place-items:center;background:#39265a;color:white;font-weight:900">${esc((p?.name||'?').slice(0,1).toUpperCase())}</div>`;
async function resize(file){if(!file)return '';if(!file.type.startsWith('image/'))throw Error('Escolha uma imagem');const bitmap=await createImageBitmap(file);const c=document.createElement('canvas');c.width=c.height=128;const g=c.getContext('2d');const scale=Math.max(128/bitmap.width,128/bitmap.height);const w=bitmap.width*scale,h=bitmap.height*scale;g.drawImage(bitmap,(128-w)/2,(128-h)/2,w,h);bitmap.close?.();return c.toDataURL('image/jpeg',.7)}
async function upload(src){if(!token)return;await api('/api/party/avatar','POST',{avatar:src});await refresh()}
$('partyAvatarFile')?.addEventListener('change',async e=>{try{chosen=await resize(e.target.files[0]);$('partyAvatarPreview').innerHTML=`<img src="${chosen}" alt="Sua foto" style="width:74px;height:74px;border-radius:50%;object-fit:cover">`}catch(err){toast(err.message)}});
$('partyAvatarChange')?.addEventListener('change',async e=>{try{await upload(await resize(e.target.files[0]))}catch(err){toast(err.message)}});
const originalJoin=$('joinBtn').onclick;
$('joinBtn').onclick=async function(){await originalJoin?.();if(token&&slot>=0&&chosen){try{await upload(chosen)}catch(e){toast('Foto: '+e.message)}}};
const oldLobby=lobby;
lobby=function(){oldLobby();const p=info?.players?.[slot];if(p)$('partyProfilePhoto').innerHTML=photoMarkup(p,66)};
function lyricLines(data){return (data?.lyric_lines||[]).filter(l=>String(l.text||'').trim()).map(l=>({at:Number(l.at??l.start??0),text:String(l.text||'').trim()})).filter(l=>Number.isFinite(l.at)).sort((a,b)=>a.at-b.at)}
lyrics=async function(){
 section('lyrics');const entry=info.queue?.[info.position],pb=info.playback;if(!entry)return;
 const singer=info.players?.[entry.singer],name=singer?.name||'Convidado';
 $('whoSings').textContent=entry.singer===slot?'VOCE ESTA CANTANDO':name.toUpperCase()+' NO PALCO';
 $('songName').textContent=entry.title||'';$('songArtist').textContent=entry.artist||'';
 $('partyLiveSinger').innerHTML=`<div style="display:flex;gap:12px;align-items:center">${photoMarkup(singer,58)}<div><small style="opacity:.65">CANTANDO AGORA</small><div style="font-weight:900;font-size:21px">${esc(name)}</div></div></div>`;
 const live=Number(pb?.live_score||0),totals=info.players.map((p,i)=>({p,score:Number(info.scores[i]||0)+(i===entry.singer?live:0)})).filter(x=>x.p).sort((a,b)=>b.score-a.score);
 $('partyLiveRanking').innerHTML='<div style="font-size:12px;letter-spacing:.14em;opacity:.7;margin-bottom:10px">RANKING AO VIVO</div>'+totals.map((x,i)=>`<div style="display:flex;align-items:center;gap:10px;padding:7px 0;border-bottom:1px solid #ffffff16"><b style="width:22px">${i+1}</b>${photoMarkup(x.p,36)}<div style="flex:1;min-width:0;font-weight:750">${esc(x.p.name)}</div><strong>${Math.round(x.score).toLocaleString('pt-BR')}</strong></div>`).join('');
 $('myScore').textContent=Math.round(Number(info.scores[slot]||0)+(entry.singer===slot?live:0)).toLocaleString('pt-BR');
 $('scoreTotals').textContent=totals.map(x=>Math.round(x.score).toLocaleString('pt-BR')).join(' / ');
 if(pb.song_id!==loadedId&&!loading){loading=true;loadedId=pb.song_id;approved=null;try{approved=await api('/api/song/'+encodeURIComponent(loadedId))}catch(e){toast('Nao foi possivel carregar letra aprovada')}finally{loading=false}}
 if(!approved)return;
 let t=Number(pb.time||0);if(pb.playing)t+=Math.max(0,Math.min(1.5,Date.now()/1000-pb.started_at));t=Math.min(t,approved.duration||3600);
 $('clock').textContent=time(t);$('total').textContent=time(approved.duration);$('barProgress').style.width=Math.max(0,Math.min(100,100*t/(approved.duration||1)))+'%';
 const lines=lyricLines(approved);let ix=-1;for(let i=0;i<lines.length;i++){if(lines[i].at<=t+.12)ix=i;else break}
 $('prevLine').textContent=ix>0?lines[ix-1].text:'';
 $('currentLine').textContent=ix<0?'INTRODUCAO':lines[ix].text;
 $('nextLine').textContent=lines[ix+1]?.text||'';
};
})();