/* NeonStage SHOWTIME V8.27 - HUD refinado, pista estável, sílabas e transições */
(function(){
'use strict';
if(window.__neonShowtime827) return; window.__neonShowtime827 = true;
const $ = id => document.getElementById(id);
const clamp = (v,a,b)=>Math.max(a,Math.min(b,v));
const prefersReduce = window.matchMedia?.('(prefers-reduced-motion: reduce)');
let stage, overlay, particleCanvas, pctx, highwayCanvas, hctx, bgVideo;
let playing=false, frameId=0, fx=[], round=[], resultsPending=null;
let phraseBadge, leftFill, rightScore, rightStars, comboBadge, eventBox, burstBox;
let audioCtx=null, lastSfxAt=0;
let lastLine='', lastLineAt=0, lastLineTo=0, lastVerseIx=0;

const saved=()=>{ try{return JSON.parse(localStorage.getItem('neon_showtime_profile_v827')||'{}')}catch{return{}} };
const fmt=n=>Math.round(n||0).toLocaleString('pt-BR');
const hypeWords=['PERFECT!','INCRÍVEL!','MANDOU!','SHOW!','LINDO!','VOOU!','NO ALVO!','SUPER!'];
const unlocks=[{at:4,label:'AQUECIMENTO'},{at:10,label:'EM CHAMAS'},{at:20,label:'VOZ DE OURO'},{at:35,label:'LENDÁRIO'},{at:60,label:'SUPERSTAR'}];

function ensureAudioCtx(){
  try{ audioCtx = audioCtx || new (window.AudioContext||window.webkitAudioContext)(); if(audioCtx.state==='suspended') audioCtx.resume?.(); }catch{}
}
function sfx(type='good'){
  if(prefersReduce?.matches) return;
  try{
    ensureAudioCtx(); if(!audioCtx) return;
    const now=audioCtx.currentTime; if(now-lastSfxAt<0.05 && type!=='super') return; lastSfxAt=now;
    const tones={perfect:[920,1280],great:[760,1040],good:[560,720],miss:[220,180],super:[680,980,1320],unlock:[860,1100,1460]};
    (tones[type]||tones.good).forEach((f,i)=>{
      const o=audioCtx.createOscillator(), g=audioCtx.createGain();
      o.type=type==='miss'?'triangle':'sine'; o.frequency.setValueAtTime(f, now+i*0.045);
      g.gain.setValueAtTime(0.0001, now+i*0.045);
      g.gain.exponentialRampToValueAtTime(type==='super'?0.05:0.024, now+i*0.045+0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, now+i*0.045+0.14);
      o.connect(g).connect(audioCtx.destination); o.start(now+i*0.045); o.stop(now+i*0.045+0.16);
    });
  }catch{}
}

function primeChartCache(){
  const notes=(state.chart?.notes||[]).filter(n=>!n.talkie && Number.isFinite(n.pitch));
  if(!notes.length) return;
  const min=Math.min(...notes.map(n=>n.pitch)), max=Math.max(...notes.map(n=>n.pitch));
  state.chart.__nsPitchMin = min-1; state.chart.__nsPitchMax = max+1;
}

function mount(){
  stage=$('gameScreen');
  if(!stage || !state.playing || !state.chart) return;
  primeChartCache();
  stage.classList.add('ns-showtime');
  stage.dataset.showtimeVersion='8.27';
  stage.querySelector('#nsShowLayer')?.remove();
  overlay=document.createElement('div');
  overlay.id='nsShowLayer';
  overlay.innerHTML=`
  <div class="ns-bg-wrap" id="nsBgWrap"><div class="ns-bg-fallback"></div><div class="ns-bg-vignette"></div></div>
  <div class="ns-edge-fade"></div>
  <div class="ns-light-pass ns-light1"></div><div class="ns-light-pass ns-light2"></div><div class="ns-light-pass ns-light3"></div>
  <canvas id="nsParticles" aria-hidden="true"></canvas>

  <div class="ns-left-rail">
    <div class="ns-left-name" id="nsLeftName">PLAYER 1</div>
    <div class="ns-left-meter-wrap"><div class="ns-left-meter"><i id="nsLeftMeterFill"></i></div><div class="ns-left-meter-cap"></div></div>
    <div class="ns-left-multi" id="nsComboBadge">x1</div>
  </div>

  <div class="ns-right-rail">
    <div class="ns-score-box" id="nsRightScore">0</div>
    <div class="ns-stars-box" id="nsRightStars">☆☆☆☆☆</div>
  </div>

  <div class="ns-top-center">
    <div class="ns-brand" id="nsBrand">SHOWTIME <span>LIVE</span></div>
    <div class="ns-highway-shell">
      <canvas id="nsHighwayCanvas" width="2048" height="242"></canvas>
      <div class="ns-phrase-badge" id="nsPhraseBadge">CANTE PARA DETECTAR SUA VOZ</div>
    </div>
  </div>

  <div class="ns-event-box" id="nsEventBox" aria-live="polite"></div>
  <div class="ns-burst-box" id="nsBurstBox" aria-live="polite"></div>`;
  stage.appendChild(overlay);

  particleCanvas=$('nsParticles'); pctx=particleCanvas.getContext('2d');
  highwayCanvas=$('nsHighwayCanvas'); hctx=highwayCanvas.getContext('2d');
  phraseBadge=$('nsPhraseBadge'); leftFill=$('nsLeftMeterFill'); rightScore=$('nsRightScore'); rightStars=$('nsRightStars'); comboBadge=$('nsComboBadge');
  eventBox=$('nsEventBox'); burstBox=$('nsBurstBox');

  const profiles=saved();
  round=(state.players||[]).map((p,i)=>({id:i,name:p.name||('PLAYER '+(i+1)),streak:0,best:0,perfect:0,great:0,good:0,miss:0,total:0,xp:0,energy:0,scoreBonus:0,superUntil:0,awards:new Set(),profile:(profiles[p.name]||0),totalAccuracy:0}));
  $('nsLeftName').textContent = round[0]?.name || 'PLAYER 1';
  playing=true; fx.length=0; lastLine='';
  ensureAudioCtx(); round.forEach(updateHud); setupBackground();
  cancelAnimationFrame(frameId); frameId=requestAnimationFrame(animation);
}

function setupBackground(){
  const wrap=$('nsBgWrap'), a=$('gameAudio'); if(!wrap || !state.chart?.id) return;
  bgVideo=wrap.querySelector('video')||document.createElement('video');
  bgVideo.className='ns-bg-video'; bgVideo.muted=true; bgVideo.loop=false; bgVideo.playsInline=true; bgVideo.preload='metadata';
  if(!bgVideo.isConnected) wrap.prepend(bgVideo);
  let done=false, attempt=0;
  const sync=()=>{
    if(!bgVideo.src || !a) return;
    const diff=(a.currentTime||0) - (bgVideo.currentTime||0);
    if(Math.abs(diff)>.45 && bgVideo.readyState>=1){ try{ bgVideo.currentTime=Math.max(0,a.currentTime||0); }catch{} }
    if(a.paused || a.ended){ if(!bgVideo.paused) bgVideo.pause(); }
    else if(bgVideo.paused){ bgVideo.play().catch(()=>{}); }
  };
  const poll=()=>{
    if(!stage?.isConnected || done) return;
    fetch('/api/showtime/video/'+encodeURIComponent(state.chart.id),{cache:'no-store'})
      .then(r=>r.json()).then(info=>{
        if(info.ready && info.url){ done=true; bgVideo.src=info.url; bgVideo.addEventListener('loadedmetadata',sync,{once:true}); sync(); return; }
        if(info.state==='error'){ done=true; return; }
        if(attempt++<120) setTimeout(poll,2500);
      }).catch(()=>{ if(attempt++<25) setTimeout(poll,3000); });
  };
  fetch('/api/showtime/video/'+encodeURIComponent(state.chart.id),{method:'POST'}).then(()=>poll()).catch(()=>{});
  const obs=setInterval(()=>{ if(!stage?.isConnected || !playing){ clearInterval(obs); bgVideo?.pause(); return; } if(bgVideo?.src) sync(); }, 700);
}

function emitBurst(label,kind='good'){
  if(!burstBox) return;
  const d=document.createElement('div'); d.className='ns-burst '+kind; d.textContent=label; burstBox.appendChild(d); setTimeout(()=>d.remove(),1000);
  while(burstBox.children.length>3) burstBox.firstChild.remove();
}
function emitEvent(label){
  if(!eventBox) return;
  const d=document.createElement('div'); d.className='ns-event'; d.textContent='✦ '+label; eventBox.appendChild(d); setTimeout(()=>d.remove(),2200);
  while(eventBox.children.length>3) eventBox.firstChild.remove();
}
function particleBurst(n=22){
  const rect=stage.getBoundingClientRect(), x=rect.width*.5, y=rect.height*.56;
  for(let i=0;i<n;i++){
    const ang=(i/n)*Math.PI*2 + Math.random()*0.4, v=1.5+Math.random()*4.8;
    fx.push({x,y,vx:Math.cos(ang)*v,vy:Math.sin(ang)*v-1.1,life:55+Math.random()*28,r:1.8+Math.random()*2.9,hue:i%3===0?190:i%3===1?320:44});
  }
  if(fx.length>260) fx.splice(0,fx.length-260);
}
function multiplier(r){ return Math.min(6, 1 + Math.floor(r.streak/6)); }
function updateHud(r){
  if(!r) return; const p=state.players[r.id];
  if(r.id===0){
    rightScore.textContent = fmt(p?.score||0);
    comboBadge.textContent = 'x'+multiplier(r);
    leftFill.style.height = clamp((r.superUntil>performance.now()?100:r.energy),0,100)+'%';
  }
}

function onNote(i,snap){
  if(i<0 || !round.length) return;
  round.forEach((r,k)=>{
    const p=snap[k]; if(!p || p.attempts<.055) return;
    const q=clamp(p.hits/p.attempts,0,1); r.total++; r.totalAccuracy+=q;
    const cls=q>=.9?'perfect':q>=.72?'great':q>=.54?'good':'miss'; r[cls]++;
    if(cls==='miss'){
      if(r.streak>=6 && k===0) emitBurst('COMBO QUEBRADO','miss');
      r.streak=0; r.energy=clamp(r.energy-8,0,100); if(k===0) sfx('miss');
    }else{
      r.streak++; r.best=Math.max(r.best,r.streak); r.xp+=cls==='perfect'?45:cls==='great'?28:14; r.energy=clamp(r.energy+(cls==='perfect'?12:cls==='great'?8:5),0,100);
      if(k===0){
        if(cls==='perfect'){ emitBurst(hypeWords[(Math.random()*hypeWords.length)|0],'perfect'); if(Math.random()>.35) particleBurst(24); sfx('perfect'); }
        else if(cls==='great'){ if(r.streak%2===0) emitBurst('GREAT!','great'); sfx('great'); }
        else { if(r.streak%5===0) emitBurst('VAI!','good'); sfx('good'); }
        if(r.streak && r.streak%10===0){ emitEvent('COMBO '+r.streak+'!'); particleBurst(36); }
      }
    }
    for(const u of unlocks){
      if(r.streak>=u.at && !r.awards.has(u.label)){
        r.awards.add(u.label); r.xp+=u.at*10;
        if(k===0){ emitEvent(u.label+'  +'+u.at*10+' XP'); particleBurst(45); sfx('unlock'); }
      }
    }
    updateHud(r);
  });
}

function roundRect(ctx,x,y,w,h,r,fill,stroke){
  if(w<0){ x+=w; w*=-1; }
  if(w<=0||h<=0) return;
  ctx.beginPath();
  ctx.moveTo(x+r,y); ctx.arcTo(x+w,y,x+w,y+h,r); ctx.arcTo(x+w,y+h,x,y+h,r); ctx.arcTo(x,y+h,x,y,r); ctx.arcTo(x,y,x+w,y,r); ctx.closePath();
  if(fill) ctx.fill(); if(stroke) ctx.stroke();
}

function getPitchRange(){
  return [state.chart?.__nsPitchMin ?? 50, state.chart?.__nsPitchMax ?? 74];
}

function getCurrentPhraseNotes(t){
  const notes=state.chart?.notes||[];
  const active=notes.find(n=>!n.talkie && n.start<=t && n.end>=t) || notes.find(n=>!n.talkie && n.start>=lastLineAt-0.05 && n.start<=lastLineTo+0.2);
  let list=[];
  if(active && Number.isFinite(active.phrase)) list=notes.filter(n=>!n.talkie && n.phrase===active.phrase);
  if(!list.length){
    const start=Number.isFinite(lastLineAt)?lastLineAt:t-0.2, end=Number.isFinite(lastLineTo)&&lastLineTo>start?lastLineTo:t+3;
    list=notes.filter(n=>!n.talkie && n.end>=start-0.1 && n.start<=end+0.1);
  }
  return list;
}

function syllabizeLine(text){
  const clean=String(text||'').replace(/\s+/g,' ').trim(); if(!clean) return [];
  return clean.split(' ').flatMap(w=>splitPt(w));
}
function splitPt(word){
  const punct = word.match(/[.,!?;:]+$/)?.[0] || '';
  const base = punct ? word.slice(0,-punct.length) : word;
  if(base.length < 5) return [base + punct];
  const vowels='aeiouáéíóúâêôãõàüAEIOUÁÉÍÓÚÂÊÔÃÕÀÜ';
  const parts=[]; let cur='';
  for(let i=0;i<base.length;i++){
    cur += base[i];
    const c=base[i], n=base[i+1]||'', p=base[i-1]||'';
    const isV=vowels.includes(c), nextV=vowels.includes(n), prevV=vowels.includes(p);
    if(isV && i<base.length-1){
      if(!nextV && vowels.includes(base[i+2]||'')) { parts.push(cur+'-'); cur=''; }
      else if(!nextV && !/[rRlLhH]/.test(n) && prevV) { parts.push(cur+'-'); cur=''; }
    }
  }
  if(cur) parts.push(cur + punct);
  return parts.filter(Boolean);
}

function drawArrow(g,x,y){
  g.save();
  g.shadowColor='rgba(255,213,84,.95)'; g.shadowBlur=18;
  g.fillStyle='#f3c24f';
  g.beginPath();
  g.moveTo(x-34,y);
  g.lineTo(x-6,y-16);
  g.lineTo(x+22,y-16);
  g.lineTo(x+38,y);
  g.lineTo(x+22,y+16);
  g.lineTo(x-6,y+16);
  g.closePath();
  g.fill();
  g.shadowBlur=0;
  g.strokeStyle='rgba(255,248,220,.95)'; g.lineWidth=2;
  g.stroke();
  g.fillStyle='rgba(255,255,255,.38)';
  g.fillRect(x-28,y-2,16,4);
  g.restore();
}

function drawHighway(){
  if(!hctx || !highwayCanvas) return;
  const g=hctx, w=highwayCanvas.width, h=highwayCanvas.height;
  g.clearRect(0,0,w,h);

  const bg=g.createLinearGradient(0,0,0,h); bg.addColorStop(0,'rgba(5,11,28,.98)'); bg.addColorStop(.45,'rgba(8,13,34,.96)'); bg.addColorStop(1,'rgba(4,8,22,.99)');
  g.fillStyle=bg; g.fillRect(0,0,w,h);

  const laneTop=18, laneBottom=h-46, lanes=7;
  for(let i=0;i<lanes;i++){
    const y=laneTop + (laneBottom-laneTop)*i/(lanes-1);
    g.strokeStyle=i===3?'rgba(255,164,230,.72)':'rgba(132,168,223,.18)';
    g.lineWidth=i===3?2.4:1.2; g.beginPath(); g.moveTo(0,y); g.lineTo(w,y); g.stroke();
  }
  for(let i=0;i<=16;i++){
    const x=i*(w/16); g.strokeStyle='rgba(255,228,124,.10)'; g.lineWidth=1; g.beginPath(); g.moveTo(x,laneTop); g.lineTo(x,laneBottom); g.stroke();
  }

  const t=$('gameAudio')?.currentTime || 0;
  const notes=state.chart?.notes || [];
  const cursorX=Math.round(w*0.13);
  const rightPad=48, lookAhead=6.8, lookBehind=.55;
  const speed=(w-cursorX-rightPad)/lookAhead;
  const [pmin,pmax]=getPitchRange();
  const span=Math.max(4,pmax-pmin);
  const pitchToY=(p)=>laneBottom - ((p-pmin)/span) * (laneBottom-laneTop);

  const visible=notes.filter(n=>!n.talkie && n.end>=t-lookBehind && n.start<=t+lookAhead);
  visible.forEach(n=>{
    const x=cursorX + (n.start-t)*speed, xe=cursorX + (n.end-t)*speed;
    const y=pitchToY(Number.isFinite(n.pitch)?n.pitch:(pmin+pmax)/2);
    const grad=g.createLinearGradient(x,0,xe,0); grad.addColorStop(0,'#20c8ff'); grad.addColorStop(.6,'#47ddff'); grad.addColorStop(1,'#79ecff');
    g.fillStyle=grad; g.shadowColor='rgba(67,222,255,.85)'; g.shadowBlur=14;
    roundRect(g,x,y-7,Math.max(7,xe-x),14,7,true,false);
  });
  g.shadowBlur=0;

  // center hit line + always visible stylized arrow
  g.strokeStyle='rgba(255,255,255,.94)'; g.lineWidth=4; g.beginPath(); g.moveTo(cursorX,12); g.lineTo(cursorX,h-20); g.stroke();
  const target=visible.find(n=>n.start<=t && n.end>=t) || visible[0];
  const livePitch=state.players?.[0]?.mid;
  const arrowY=pitchToY(Number.isFinite(livePitch)?livePitch:(target?.pitch ?? ((pmin+pmax)/2)));
  g.strokeStyle='rgba(255,230,150,.30)'; g.lineWidth=4; g.beginPath(); g.moveTo(cursorX-74, arrowY); g.lineTo(cursorX-14, arrowY); g.stroke();
  drawArrow(g, cursorX-22, arrowY);

  // line + syllable guides
  const line=String($('lyricCurrent')?.textContent||'').trim();
  if(line){
    const tokens=syllabizeLine(line).slice(0,28);
    const phraseNotes=getCurrentPhraseNotes(t);
    const start=Number.isFinite(lastLineAt)?lastLineAt:(phraseNotes[0]?.start ?? t);
    const end=Number.isFinite(lastLineTo)&&lastLineTo>start?lastLineTo:(phraseNotes[phraseNotes.length-1]?.end ?? start+4);
    const dur=Math.max(.25,end-start);
    const progress=clamp((t-start)/dur,0,1);
    g.font='800 18px system-ui, sans-serif'; g.textAlign='center'; g.textBaseline='middle';
    tokens.forEach((tok,i)=>{
      const frac=(i+.5)/tokens.length;
      const tokenTime=start + frac*dur;
      const idx=phraseNotes.length ? Math.min(phraseNotes.length-1, Math.floor(frac*phraseNotes.length)) : -1;
      const note=idx>=0 ? phraseNotes[idx] : target;
      const x=cursorX + (tokenTime-t)*speed;
      if(x<22 || x>w-22) return;
      const y=clamp((note? pitchToY(note.pitch):laneBottom-16)+28, laneTop+18, h-22);
      g.lineWidth=5; g.strokeStyle='rgba(0,0,0,.72)'; g.strokeText(tok,x,y);
      g.fillStyle= frac<=progress ? '#ff59c1' : '#ffffff';
      g.fillText(tok,x,y);
    });
  }

  const tip = target && Number.isFinite(livePitch)
    ? Math.abs(livePitch-target.pitch)<0.35 ? 'NO ALVO!' : livePitch<target.pitch ? 'SUBA A VOZ' : 'DESÇA A VOZ'
    : 'CANTE PARA CENTRALIZAR';
  phraseBadge.textContent = `VERSO ${Math.max(1,lastVerseIx+1)} / ${Math.max(1,(state.chart?.lyric_lines||[]).filter(x=>String(x.text||'').trim()).length)}`;
  phraseBadge.dataset.tip = tip;
}

function drawParticles(){
  const dpr=Math.min(2,window.devicePixelRatio||1), w=stage.clientWidth, h=stage.clientHeight; if(w<=0||h<=0) return;
  if(particleCanvas.width!==Math.ceil(w*dpr) || particleCanvas.height!==Math.ceil(h*dpr)){
    particleCanvas.width=Math.ceil(w*dpr); particleCanvas.height=Math.ceil(h*dpr);
  }
  pctx.setTransform(dpr,0,0,dpr,0,0); pctx.clearRect(0,0,w,h);
  for(let j=fx.length-1;j>=0;j--){
    const p=fx[j]; p.x+=p.vx; p.y+=p.vy; p.vy+=.045; p.life-=1;
    pctx.beginPath(); pctx.fillStyle=`hsla(${p.hue},100%,75%,${clamp(p.life/70,0,1)})`; pctx.arc(p.x,p.y,p.r,0,Math.PI*2); pctx.fill();
    if(p.life<=0) fx.splice(j,1);
  }
}
function refreshMeta(){
  const r=round[0]; if(!r) return;
  const max=Math.max(1, state.chart?.notes?.length || 1), sum=round.reduce((v,a)=>v+a.perfect+a.great+a.good,0), accuracy=sum/max;
  const st=clamp(Math.round(accuracy*5),0,5); rightStars.textContent='★'.repeat(st)+'☆'.repeat(5-st); updateHud(r);
}
function animation(){
  if(!playing || !stage?.isConnected) return; drawParticles(); drawHighway(); refreshMeta(); frameId=requestAnimationFrame(animation);
}

const nativeScore=scoreFrame;
scoreFrame=function(t,dt){
  const prePlayers=state.players.map(p=>({attempts:p.attempts,hits:p.hits,score:p.score})); const preIndex=state.lastNote;
  nativeScore.apply(this,arguments);
  if(playing){
    for(let i=0;i<round.length;i++){
      const p=state.players[i], r=round[i]; if(!p||!r) continue;
      const earned=Math.max(0,p.score-prePlayers[i].score), factor=multiplier(r) * (r.superUntil>performance.now()?2:1), bonus=earned*(factor-1);
      if(Number.isFinite(bonus) && bonus>0){ p.score+=bonus; r.scoreBonus+=bonus; }
    }
    if(preIndex>=0 && preIndex!==state.lastNote) onNote(preIndex, prePlayers);
  }
};

const nativeLyrics=renderLyrics;
renderLyrics=function(t){
  nativeLyrics.apply(this,arguments);
  if(!playing) return;
  const cur=$('lyricCurrent'); if(!cur) return;
  const prev=$('lyricPrevious'), next=$('lyricNext');
  const full=String(cur.textContent||'').trim();
  const lines=(state.chart?.lyric_lines||[]).filter(x=>String(x.text||'').trim());
  if(full!==lastLine){
    lastLine=full; cur.classList.remove('ns-line-enter'); void cur.offsetWidth; cur.classList.add('ns-line-enter');
    prev?.classList.remove('ns-line-shift'); next?.classList.remove('ns-line-shift'); void cur.offsetWidth; prev?.classList.add('ns-line-shift'); next?.classList.add('ns-line-shift');
    const ix=lines.findIndex(x=>String(x.text||'').trim()===full);
    lastVerseIx = ix>=0 ? ix : lastVerseIx;
    const at=ix>=0 ? Number(lines[ix].at) : t;
    const to=ix>=0 && lines[ix+1] ? Number(lines[ix+1].at) : (t+4);
    lastLineAt=at; lastLineTo=to;
  }
  const progress=Number.isFinite(lastLineAt)&&Number.isFinite(lastLineTo)&&lastLineTo>lastLineAt ? clamp(100*(t-lastLineAt)/(lastLineTo-lastLineAt),0,100) : 0;
  cur.style.setProperty('--ns-lyric-progress', progress.toFixed(2)+'%');
};

const nativeBegin=beginSong;
beginSong=async function(){ const v=await nativeBegin.apply(this,arguments); if(state.playing && state.chart) mount(); return v; };
const nativeStop=stopGame;
stopGame=async function(){ playing=false; cancelAnimationFrame(frameId); return nativeStop.apply(this,arguments); };
const nativeFinish=finishGame;
finishGame=async function(){ if(state.playing) finishRound(); const v=await nativeFinish.apply(this,arguments); presentResults(); return v; };

function finishRound(){
  if(!playing) return;
  const data=saved();
  resultsPending=round.map(q=>({name:q.name,xp:q.xp,perfect:q.perfect,great:q.great,good:q.good,miss:q.miss,best:q.best,accuracy:q.total?Math.round(q.totalAccuracy/q.total*100):0,score:Math.round(state.players[q.id]?.score||0)}));
  for(const q of round) data[q.name]=(data[q.name]||0)+q.xp;
  try{ localStorage.setItem('neon_showtime_profile_v827', JSON.stringify(data)); }catch{}
}
function presentResults(){
  if(!resultsPending) return;
  const root=$('finishScores'); if(!root) return;
  root.querySelector('.ns-results')?.remove();
  const wrap=document.createElement('section'); wrap.className='ns-results'; wrap.innerHTML='<div class="ns-finish-title">RESULTADO DO SHOW</div>';
  resultsPending.forEach(r=>{
    const row=document.createElement('div'); row.className='ns-finish-card';
    const stars=clamp(Math.round(r.accuracy/20),0,5);
    row.innerHTML=`<div class="ns-finish-name">${r.name}</div><strong>${fmt(r.score)} PTS</strong><div class="ns-finish-stars">${'★'.repeat(stars)}${'☆'.repeat(5-stars)}</div><div class="ns-finish-metrics"><span>${r.accuracy}% PRECISÃO</span><span>${r.best}x COMBO</span><span>+${r.xp} XP</span><span>${r.perfect} PERFECTS</span></div>`;
    wrap.appendChild(row);
  });
  root.appendChild(wrap); resultsPending=null;
}

const gameScreen=$('gameScreen');
if(gameScreen){
  const syncStage=()=>{
    if(state.playing && state.chart && !gameScreen.classList.contains('hidden')){ if(!gameScreen.querySelector('#nsShowLayer')) mount(); }
    else if(playing){ playing=false; cancelAnimationFrame(frameId); gameScreen.querySelector('#nsShowLayer')?.remove(); gameScreen.classList.remove('ns-showtime'); }
  };
  new MutationObserver(syncStage).observe(gameScreen,{attributes:true,attributeFilter:['class']});
  $('startGame')?.addEventListener('click',()=>{ setTimeout(syncStage,0); setTimeout(syncStage,600); setTimeout(syncStage,1800); });
  syncStage();
}
window.addEventListener('keydown',e=>{
  if(e.code==='Space' && !e.repeat && state.playing && !/INPUT|TEXTAREA|BUTTON/.test(document.activeElement?.tagName||'')){
    const r=round[0];
    if(r?.energy>=100 && r.superUntil<=performance.now()){
      e.preventDefault(); r.energy=0; r.superUntil=performance.now()+12000; emitEvent('SUPERSTAR MODE'); emitBurst('SUPERSTAR!','perfect'); particleBurst(70); sfx('super'); refreshMeta();
    }
  }
});
})();
