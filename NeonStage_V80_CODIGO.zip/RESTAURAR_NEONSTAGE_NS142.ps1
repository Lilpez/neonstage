$ErrorActionPreference = 'Stop'
# Pare o NeonStage antes de restaurar.
$root = 'C:\Users\freit\Downloads\NeonStage_V80'
$backup = 'C:\Users\freit\Downloads\NeonStage_V80\BACKUP_ANTES_NS142_20261012_193953_585888'
if (!(Test-Path -LiteralPath $backup)) { throw 'Backup NS14.2 nao encontrado.' }
Copy-Item -LiteralPath (Join-Path $backup 'neon_sync_v2.py') -Destination (Join-Path $root 'neon_sync_v2.py') -Force
Remove-Item -LiteralPath (Join-Path $root 'neon_sync_reference.py') -Force -ErrorAction SilentlyContinue
Copy-Item -LiteralPath (Join-Path $backup 'static\sync14.js') -Destination (Join-Path $root 'static\sync14.js') -Force
Copy-Item -LiteralPath (Join-Path $backup 'static\sync14.html') -Destination (Join-Path $root 'static\sync14.html') -Force
Copy-Item -LiteralPath (Join-Path $backup 'static\sync14.css') -Destination (Join-Path $root 'static\sync14.css') -Force
Write-Host 'NS14.2 restaurada para NS14.1. Reinicie o servidor.' -ForegroundColor Green
