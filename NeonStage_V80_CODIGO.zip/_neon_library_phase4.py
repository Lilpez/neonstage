﻿from pathlib import Path
import datetime, shutil, re, subprocess, json
ROOT=Path(__file__).resolve().parent
STATIC=ROOT/'static'; APP=ROOT/'app.py'; INDEX=STATIC/'index.html'
JS=STATIC/'neon_library_phase4.js'; CSS=STATIC/'neon_library_phase4.css'
for p in (APP, INDEX, STATIC/'app.js'):
    if not p.exists(): raise SystemExit('Arquivo ausente: '+str(p))
app=APP.read_text(encoding='utf-8-sig'); html=INDEX.read_text(encoding='utf-8-sig')
marker='# NEON_LIBRARY_PHASE4_SERVER'
route=r'''# NEON_LIBRARY_PHASE4_SERVER
@app.delete('/api/library/<song_id>')
def neon_library_delete(song_id):
    import shutil as _ns_shutil
    if request.remote_addr not in ('127.0.0.1', '::1'):
        return jsonify(error='Exclusao permitida apenas no computador.'),403
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', song_id):
        return jsonify(error='ID invalido.'),400
    if song_id=='demo_neonstage':
        return jsonify(error='A musica de demonstracao e protegida.'),403
    with LOCK:
        if any(j.get('song_id')==song_id or (j.get('song_id') is None and job_id==song_id) for job_id,j in JOBS.items() if j.get('progress',0)<100 and not j.get('error')):
            return jsonify(error='Esta musica ainda esta sendo preparada.'),409
    folder=(SONGS/song_id).resolve()
    if folder.parent != SONGS.resolve() or not folder.is_dir() or not (folder/'chart.json').is_file():
        return jsonify(error='Musica nao encontrada.'),404
    try:
        _ns_shutil.rmtree(folder)
    except OSError as e:
        return jsonify(error='Nao foi possivel excluir: '+str(e)),500
    return jsonify(ok=True, deleted=song_id)
'''
if marker not in app:
    if "@app.get('/api/library')" not in app: raise SystemExit('API da biblioteca nao reconhecida; nenhuma alteracao aplicada.')
    app=app.replace("@app.get('/api/library')",route+"\n@app.get('/api/library')",1)
# Include official thumbnail in new charts without changing notes or timing.
old="chart.update(id=job_id,title=title,artist=artist,source='youtube')"
new="chart.update(id=job_id,title=title,artist=artist,source='youtube', image=f'https://i.ytimg.com/vi/{video_id}/hqdefault.jpg', video_id=video_id)"
if old in app: app=app.replace(old,new,1)
js=r'''(()=>{
'use strict';
if(window.__NS_LIBRARY_PHASE4__)return;window.__NS_LIBRARY_PHASE4__=true;
const grid=document.getElementById('libraryGrid');if(!grid)return;
let running=false;
function getSongs(){try{return state.library||[]}catch{return []}}
function attach(){
 if(running)return;running=true;
 try{
   const songs=getSongs();
   for(const card of grid.querySelectorAll('.album[data-song]')){
     const id=card.dataset.song;
     if(!id||card.querySelector('.ns-lib-del'))continue;
     const song=songs.find(x=>x.id===id);if(!song)continue;
     card.classList.add('ns-lib-card');
     const art=card.querySelector('.album-art');
     const thumb=song.image||song.thumbnail||song.thumb||(song.video_id&&/^[\w-]{11}$/.test(song.video_id)?'https://i.ytimg.com/vi/'+song.video_id+'/hqdefault.jpg':'');
     if(art&&thumb&&/^https?:\/\//i.test(thumb)){
       const img=document.createElement('img');img.className='ns-lib-cover';img.alt='Capa de '+song.title;img.loading='lazy';img.referrerPolicy='no-referrer';img.src=thumb;
       img.onerror=()=>img.remove();art.prepend(img);
     }
     if(id==='demo_neonstage')continue;
     const btn=document.createElement('button');btn.type='button';btn.className='ns-lib-del';btn.textContent='Excluir';btn.title='Apagar esta musica do NeonStage';
     btn.onclick=async(ev)=>{
       ev.preventDefault();ev.stopPropagation();
       if(!confirm('Excluir "'+song.title+'"? Todos os arquivos desta musica serao apagados do PC. Esta acao nao pode ser desfeita.'))return;
       btn.disabled=true;btn.textContent='Excluindo...';
       try{
         const response=await fetch('/api/library/'+encodeURIComponent(id),{method:'DELETE'});
         const data=await response.json();if(!response.ok)throw Error(data.error||'Erro ao excluir');
         if(window.state&&window.state.selected?.id===id)window.state.selected=null;
         if(typeof refreshLibrary==='function')await refreshLibrary();else location.reload();
       }catch(e){alert('Nao foi possivel excluir: '+e.message);btn.disabled=false;btn.textContent='Excluir';}
     };
     card.appendChild(btn);
   }
 }finally{running=false;}
}
new MutationObserver(()=>attach()).observe(grid,{childList:true});
attach();
})();'''
css=r'''/* NeonStage Library Phase4 - scoped */
#libraryGrid .ns-lib-card{position:relative}
#libraryGrid .ns-lib-del{position:absolute;top:9px;right:9px;z-index:5;background:rgba(19,9,19,.88);color:#ffd9e1;border:1px solid rgba(255,126,149,.45);border-radius:9px;padding:7px 10px;font:700 11px system-ui;cursor:pointer;box-shadow:0 2px 12px #0009}
#libraryGrid .ns-lib-del:hover{background:#9c294e;color:#fff}
#libraryGrid .ns-lib-cover{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:inherit;z-index:1}
#libraryGrid .album-play{z-index:2;position:relative}
'''
if 'neon_library_phase4.js' not in html:
    if not re.search(r'</body\s*>',html,re.I):raise SystemExit('HTML incompleto; nenhuma alteracao aplicada.')
    html=re.sub(r'</body\s*>','<script src="/static/neon_library_phase4.js?v=401"></script></body>',html,count=1,flags=re.I)
if 'neon_library_phase4.css' not in html:
    if not re.search(r'</head\s*>',html,re.I):raise SystemExit('HTML incompleto; nenhuma alteracao aplicada.')
    html=re.sub(r'</head\s*>','<link rel="stylesheet" href="/static/neon_library_phase4.css?v=401"></head>',html,count=1,flags=re.I)
compile(app,str(APP),'exec')
node=shutil.which('node')
if node:
    checked=subprocess.run([node,'--check','-'],input=js,text=True,capture_output=True)
    if checked.returncode:raise SystemExit(checked.stderr)
backup=ROOT/('backup_biblioteca_fase4_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
backup.mkdir()
for p in (APP,INDEX,JS,CSS):
    if p.exists():shutil.copy2(p,backup/p.name)
try:
    APP.write_text(app,encoding='utf-8',newline='')
    INDEX.write_text(html,encoding='utf-8',newline='')
    JS.write_text(js,encoding='utf-8',newline='')
    CSS.write_text(css,encoding='utf-8',newline='')
except BaseException:
    for p in (APP,INDEX,JS,CSS):
        original=backup/p.name
        if original.exists():shutil.copy2(original,p)
        else:p.unlink(missing_ok=True)
    raise
print('BIBLIOTECA FASE 4 INSTALADA')
print('Exclusao local com confirmacao e capa de video, quando disponivel.')
print('Backup:',backup)
print('Reinicie o NeonStage e atualize a pagina.')
