"""V8.17 wrapper: preserve V8.16 Genius preprocessing then forced-align once."""
import importlib.util
from pathlib import Path
import json

def process(root,song_id,force=False):
    root=Path(root)
    # First reuse validated V8.16 Genius selection + caching, without changing its engine.
    previous=root/'neon_preplay_v816_backup.py'
    if not previous.exists():return {'state':'missing_v816_engine'}
    spec=importlib.util.spec_from_file_location('_v816_preplay',str(previous))
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    old=mod.process(root,song_id,force=force)
    if old.get('state') not in ('done',):return old
    from neon_v817_align import align_chart
    align=align_chart(root,song_id,force=force)
    return {'state':old['state'],'genius':old,'forced_alignment':align}
