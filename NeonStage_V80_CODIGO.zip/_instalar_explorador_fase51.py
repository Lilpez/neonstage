﻿from pathlib import Path
import datetime
import shutil
import sys

if len(sys.argv) != 2:
    raise SystemExit('Uso: python instalador.py CAMINHO_NEONSTAGE')
root = Path(sys.argv[1]).resolve()
app_file = root / 'app.py'
js_file = root / 'static' / 'neon_storage_phase5.js'
css_file = root / 'static' / 'neon_storage_phase5.css'
if not all(p.is_file() for p in (app_file, js_file, css_file)):
    raise SystemExit('Fase 5 nao encontrada. Instale a Fase 5 antes do seletor de pasta.')
app = app_file.read_text(encoding='utf-8-sig')
js = js_file.read_text(encoding='utf-8-sig')
css = css_file.read_text(encoding='utf-8-sig')
if '# NS_STORAGE_FASE5_API' not in app or 'nsStorageFolder' not in js:
    raise SystemExit('Estrutura da Fase 5 nao reconhecida; nenhum arquivo alterado.')

marker_py = '# NS_STORAGE_FOLDER_PICKER_51'
marker_js = '// NS_STORAGE_FOLDER_PICKER_51'
marker_css = '/* NS_STORAGE_FOLDER_PICKER_51 */'

route = r'''# NS_STORAGE_FOLDER_PICKER_51
@app.post('/api/neon/storage/pick-folder')
def neon_storage_pick_folder():
    # Dialog can only open on the Windows PC running the server.
    if request.remote_addr not in ('127.0.0.1', '::1'):
        return jsonify(error='Abra as configuracoes no proprio notebook.'), 403
    origin = request.headers.get('Origin', '')
    if origin and origin != (request.scheme + '://' + request.host):
        return jsonify(error='Origem nao autorizada.'), 403
    if request.headers.get('X-NeonStage-Local') != '1':
        return jsonify(error='Requisicao nao autorizada.'), 403
    if os.name != 'nt':
        return jsonify(error='O seletor visual requer Windows.'), 501
    import base64 as _nfp_base64
    import subprocess as _nfp_subprocess
    import shutil as _nfp_shutil
    current = str((request.get_json(silent=True) or {}).get('current', ''))[:900]
    if not Path(current).is_dir():
        current = str(SONGS)
    encoded = _nfp_base64.b64encode(current.encode('utf-8')).decode('ascii')
'''
# Native Windows folder dialog runs in a short-lived PowerShell STA process.
powershell_code = r'''
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
$folder = New-Object System.Windows.Forms.FolderBrowserDialog
$folder.Description = 'Selecione a pasta para as musicas do NeonStage'
$folder.ShowNewFolderButton = $true
$folder.AutoUpgradeEnabled = $true
$start = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String('__INITIAL_FOLDER_B64__'))
if ([System.IO.Directory]::Exists($start)) { $folder.SelectedPath = $start }
$owner = New-Object System.Windows.Forms.Form
$owner.TopMost = $true
$owner.ShowInTaskbar = $false
$owner.Opacity = 0
$owner.Width = 1
$owner.Height = 1
$owner.StartPosition = [System.Windows.Forms.FormStartPosition]::Manual
$owner.Location = New-Object System.Drawing.Point(-3000, -3000)
$owner.Show()
try {
    $selected = $folder.ShowDialog($owner)
    if ($selected -eq [System.Windows.Forms.DialogResult]::OK) {
        $base64 = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($folder.SelectedPath))
        [Console]::WriteLine('NS_PATH:' + $base64)
    } else {
        [Console]::WriteLine('NS_CANCEL')
    }
} finally {
    $owner.Close()
    $owner.Dispose()
    $folder.Dispose()
}
'''
# Embed Powershell as a Python triple-double-quoted raw string, which does not
# interfere with the surrounding single-quoted route template.
route += '    ps = r"""' + powershell_code + '"""\n'
route += r'''    ps = ps.replace('__INITIAL_FOLDER_B64__', encoded)
    powershell = _nfp_shutil.which('powershell.exe')
    if not powershell:
        return jsonify(error='PowerShell do Windows nao encontrado.'), 500
    try:
        completed = _nfp_subprocess.run(
            [powershell, '-NoProfile', '-STA', '-EncodedCommand',
             _nfp_base64.b64encode(ps.encode('utf-16le')).decode('ascii')],
            stdout=_nfp_subprocess.PIPE,
            stderr=_nfp_subprocess.PIPE,
            timeout=300,
            creationflags=getattr(_nfp_subprocess, 'CREATE_NO_WINDOW', 0)
        )
    except _nfp_subprocess.TimeoutExpired:
        return jsonify(error='Tempo esgotado ao escolher a pasta.'), 504
    except OSError:
        return jsonify(error='Nao foi possivel abrir a janela do Windows.'), 500
    output = completed.stdout.decode('utf-8', errors='replace')
    for line in output.splitlines():
        line = line.strip()
        if line.startswith('NS_PATH:'):
            try:
                selected = _nfp_base64.b64decode(line[8:], validate=True).decode('utf-8')
                if Path(selected).is_dir():
                    return jsonify(ok=True, path=selected, cancelled=False)
            except (ValueError, UnicodeDecodeError, OSError):
                pass
        if line == 'NS_CANCEL':
            return jsonify(ok=True, cancelled=True)
    if completed.returncode:
        return jsonify(error='O seletor de pasta falhou no Windows. Verifique se PowerShell e Windows Forms estao disponiveis.'), 500
    return jsonify(error='Nenhuma pasta foi retornada pelo Windows.'), 500
'''

js_add = r''' // NS_STORAGE_FOLDER_PICKER_51
 const browse=document.createElement('button');
 browse.id='nsStorageBrowse'; browse.type='button'; browse.className='ghost';
 browse.textContent='Procurar pasta...';
 const actions=box.querySelector('.ns-storage-actions');
 actions.insertBefore(browse,actions.firstChild);
 browse.onclick=async()=>{
   browse.disabled=true;
   info.textContent='Escolha a pasta na janela do Windows que foi aberta no notebook.';
   try{
     const response=await fetch('/api/neon/storage/pick-folder',{
       method:'POST',
       headers:{'Content-Type':'application/json','X-NeonStage-Local':'1'},
       body:JSON.stringify({current:field.value})
     });
     const data=await response.json();
     if(!response.ok)throw Error(data.error||'Falha ao abrir o explorador.');
     if(data.cancelled){info.textContent='Escolha cancelada; nenhuma pasta foi alterada.';return;}
     if(!data.path)throw Error('O Windows nao retornou a pasta selecionada.');
     field.value=data.path;
     info.textContent='Pasta escolhida. Agora clique em Copiar musicas e salvar pasta para confirmar a migracao.';
     field.focus();
   }catch(err){info.textContent='Erro ao escolher pasta: '+err.message;}
   finally{browse.disabled=false;}
 };
'''
css_add = r'''
/* NS_STORAGE_FOLDER_PICKER_51 */
#nsStorageBrowse{background:linear-gradient(115deg,#6652a4,#453a7a);color:#fff;border:1px solid #9f86e3;border-radius:10px;box-shadow:0 3px 18px #0003;font-weight:750}
#nsStorageBrowse:hover{filter:brightness(1.16)}
#nsStorageBrowse:disabled{opacity:.5;cursor:wait}
'''

if marker_py not in app:
    anchor = "@app.post('/api/neon/storage')"
    if app.count(anchor) != 1:
        raise SystemExit('Rota de migracao nao encontrada; nenhum arquivo alterado.')
    app = app.replace(anchor, route + '\n' + anchor, 1)

if marker_js not in js:
    anchor = ' save.onclick=async()=>{'
    if js.count(anchor) != 1:
        raise SystemExit('Controles de armazenamento nao encontrados; nenhum arquivo alterado.')
    js = js.replace(anchor, js_add + anchor, 1)
if marker_css not in css:
    css += css_add

compile(app, str(app_file), 'exec')
backup = root / ('backup_antes_explorador_' + datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
changes = {app_file:app, js_file:js, css_file:css}
modified = {p:s for p,s in changes.items() if p.read_text(encoding='utf-8-sig') != s}
if not modified:
    print('O botao Procurar pasta ja esta instalado; nenhuma alteracao necessaria.')
    raise SystemExit(0)
backup.mkdir(parents=True, exist_ok=True)
for p in modified:
    shutil.copy2(p, backup / p.name)
try:
    for p,s in modified.items():
        with p.open('w', encoding='utf-8', newline='') as f:
            f.write(s)
except BaseException:
    for p in modified:
        shutil.copy2(backup / p.name, p)
    raise
print('NEONSTAGE: BOTAO PROCURAR PASTA INSTALADO')
print('Arquivos:', ', '.join(p.name for p in modified))
print('Backup:', backup)
print('Abra Configuracoes > Armazenamento > Procurar pasta...')
print('Reinicie o servidor (o endpoint Python foi atualizado).')
