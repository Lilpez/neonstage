"""Post-pass: split LONG displayed phrases at the timed WhisperX word boundary.
Never changes notes, pitches or original note/phrase timestamps.
"""
import re
from neon_text_correction import tokens,similarity,norm,clean_lines

def refine(chart, official):
    lines=chart.get('lyric_lines') or []
    notes=chart.get('notes') or []
    groups={}
    for w in notes:
        groups.setdefault(w.get('phrase',0),[]).append(w)
    slots=sorted(groups.values(),key=lambda ws:float(ws[0].get('start',0)))
    # Each rendered text line has original note-group timing; avoid matching on guessed indices.
    out=[]; splits=0; recovered=0
    for row in lines:
        out.append(row)
        content=str(row.get('text') or '')
        if not content or ',' not in content or len(tokens(content))<9:
            continue
        at=float(row.get('at',-1))
        matching=[ws for ws in slots if abs(float(ws[0].get('start',-999))-at)<0.035]
        if len(matching)!=1:continue
        ws=matching[0]
        if len(ws)<6:continue
        # One internal comma only. A second comma can be part of a sung phrase;
        # this patch deliberately skips ambiguous multi-comma phrasing.
        if content.count(',')!=1:continue
        first,second=[s.strip() for s in content.split(',',1)]
        if len(tokens(first))<3 or len(tokens(second))<3:continue
        original=[str(w.get('asr_original',w.get('text',''))) for w in ws]
        best=[]
        for pivot in range(2,len(ws)-1):
            try:t=float(ws[pivot].get('start'))
            except Exception:continue
            if t-at<0.6 or t-at>12:continue
            a=similarity(' '.join(original[:pivot]),first)[0]
            b=similarity(' '.join(original[pivot:]),second)[0]
            best.append(((a+b)/2,pivot,t,a,b))
        if not best:continue
        best.sort(reverse=True)
        value,pivot,t,a,b=best[0]
        # Do not split without clear independent evidence that each side
        # maps to different sets of WhisperX words.
        if min(a,b)<.48 or value<.60:continue
        if len(best)>1 and value-best[1][0]<.035 and abs(best[1][1]-pivot)>1:continue
        row['text']=first+','
        row['text_source']=str(row.get('text_source',''))+'_timed_split'
        out.append({'at':round(t,3),'text':second,'text_source':'genius_v816_word_split','match_confidence':round(value,3)})
        splits+=1
    out.sort(key=lambda r:float(r.get('at',0)))
    chart['lyric_lines']=out
    chart['lyrics_refinement_version']='v816_word_boundaries'
    return {'long_phrases_split':splits,'repeated_verse_recovered':recovered,'lines_total':len(out)}
