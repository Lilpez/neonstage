
"""Local visual-only clip cache. Never changes any chart/audio or replaces the karaoke audio stream."""
from pathlib import Path
import re, threading
from flask import jsonify, send_from_directory
_LOCK=threading.Lock()
_STATES={}
def register(app, songs):
    def clip_path(song_id): return songs/song_id/'showtime_background.mp4'
    @app.route('/api/showtime/video/<song_id>',methods=['GET','POST'])
    def video_status(song_id):
        if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',song_id):return jsonify(state='error'),400
        dest=songs/song_id
        if not (dest/'chart.json').exists():return jsonify(state='error'),404
        video=clip_path(song_id)
        if video.exists() and video.stat().st_size>5000:return jsonify(ready=True,state='done',url='/api/showtime/video-file/'+song_id)
        if video.exists() and video.stat().st_size<5000:video.unlink(missing_ok=True)
        with _LOCK:
            state=_STATES.get(song_id,'idle')
            if state=='idle' and __import__('flask').request.method=='POST':
                _STATES[song_id]='working'
                threading.Thread(target=_download,args=(song_id,dest,_STATES),daemon=True).start()
                state='working'
        return jsonify(ready=False,state=state)
    @app.get('/api/showtime/video-file/<song_id>')
    def video_file(song_id):
        if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',song_id):return ('Invalid ID',400)
        if not clip_path(song_id).exists():return ('Video not found',404)
        return send_from_directory(songs/song_id,'showtime_background.mp4',conditional=True)

def _download(song_id,dest,states):
    try:
        import json,yt_dlp
        chart=json.loads((dest/'chart.json').read_text(encoding='utf-8'))
        query=(chart.get('title') or '')+' '+(chart.get('artist') or '')
        search={'quiet':True,'no_warnings':True,'extract_flat':True,'skip_download':True,'socket_timeout':12,'default_search':'ytsearch'}
        with yt_dlp.YoutubeDL(search) as ydl:
            hits=(ydl.extract_info('ytsearch1:'+query,download=False) or {}).get('entries',[])
        if not hits or not hits[0].get('id'):raise RuntimeError('video not found')
        video_id=hits[0]['id']
        opts={'format':'best[ext=mp4][height<=720]/best[height<=720]/best','outtmpl':str(dest/'showtime_background.%(ext)s'),'quiet':True,'no_warnings':True,'noplaylist':True,'socket_timeout':20,'retries':2,'max_filesize':300*1024*1024}
        with yt_dlp.YoutubeDL(opts) as ydl:ydl.download(['https://www.youtube.com/watch?v='+video_id])
        file=next((p for p in dest.glob('showtime_background.*') if p.suffix.lower() in ('.mp4','.webm','.mkv')),None)
        if file is None:raise RuntimeError('no downloaded video')
        if file.suffix.lower()!='.mp4':
            import subprocess
            p=subprocess.run(['ffmpeg','-y','-loglevel','error','-i',str(file),'-an','-c:v','libx264','-preset','ultrafast','-crf','30',str(dest/'showtime_background.mp4')],capture_output=True,timeout=150)
            if p.returncode:raise RuntimeError('could not convert video')
            file.unlink(missing_ok=True)
        states[song_id]='done'
    except Exception as exc:
        states[song_id]='error'
        print('SHOWTIME video:',str(exc)[:180])
