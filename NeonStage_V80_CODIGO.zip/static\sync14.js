(()=>{'use strict';
const $=id=>document.getElementById(id);
let poller=null, searchResults=[];
const show=(id,text,kind='')=>{const el=$(id);el.textContent=text;el.className=(id==='state'?'state ': 'refstate ')+kind;};
function stamp(t){if(t==null||!Number.isFinite(Number(t)))return '—';const n=Number(t);return `${Math.floor(n/60)}:${String(Math.floor(n%60)).padStart(2,'0')}.${String(Math.round(n%1*100)).padStart(2,'0')}`;}
async function json(url,opts){const r=await fetch(url,{cache:'no-store',...opts});let result;try{result=await r.json();}catch{throw Error('Resposta invalida do servidor.');}if(!r.ok)throw Error(result.error||`HTTP ${r.status}`);return result;}
const localPost=(obj)=>({method:'POST',headers:{'Content-Type':'application/json','X-NeonStage-Local':'1'},body:JSON.stringify(obj)});
async function loadSongs(){try{const res=await json('/api/library'), list=Array.isArray(res)?res:(res.songs||[]),selected=$('songs').value;$('songs').replaceChildren();for(const s of list){if(!s.id)continue;const o=document.createElement('option');o.value=s.id;o.textContent=`${s.artist||'Artista'} — ${s.title||s.id}`;$('songs').append(o);}if([...$('songs').options].some(x=>x.value===selected))$('songs').value=selected;show('state',`${$('songs').options.length} musica(s) na biblioteca.`);await showCurrentReference();}catch(e){show('state','Erro na biblioteca: '+e.message,'error');}}
function clearSuggestions(){searchResults=[];$('referenceResults').replaceChildren();}
async function searchKaraoke(){const id=$('songs').value;if(!id)return;const btn=$('searchRef');btn.disabled=true;show('refState','Consultando videos de karaokê no YouTube...');clearSuggestions();try{const res=await json(`/api/sync14/${encodeURIComponent(id)}/reference/search`,localPost({}));searchResults=res.results||[];for(const v of searchResults){const row=document.createElement('option');row.value=v.url;row.textContent=`${v.title} — ${v.duration?Math.round(v.duration)+' s':'duração desconhecida'}`;$('referenceResults').append(row);}if(searchResults.length){$('referenceUrl').value=searchResults[0].url;show('refState',`${searchResults.length} sugestoes encontradas. Escolha a gravacao correspondente e clique em Examinar legendas.`);}else show('refState','Nenhuma versao localizada. Cole um link especifico para tentar.','warn');}catch(e){show('refState',e.message,'error');}finally{btn.disabled=false;}}
async function lrcReference(){const id=$('songs').value;if(!id)return;const button=$('lrcRef');button.disabled=true;show('refState','Consultando letras com tempos no LRCLIB...');try{const result=await json(`/api/sync14/${encodeURIComponent(id)}/reference/lrc`,localPost({}));if(result.reference)renderRef(result.reference);else show('refState','Nao ha letra temporizada LRC compativel nesta consulta.','warn');}catch(e){show('refState',e.message,'error');}finally{button.disabled=false;}}
async function autoReference(){const id=$('songs').value;if(!id)return;const button=$('autoRef');button.disabled=true;show('refState','Verificando LRCLIB e ate tres videos do YouTube. Pode demorar...');try{const out=await json(`/api/sync14/${encodeURIComponent(id)}/reference/auto`,localPost({}));renderRef(out.reference);if(!out.reference)show('refState',out.message||'Nao foi possivel encontrar uma referencia.','warn');}catch(e){show('refState',e.message,'error');}finally{button.disabled=false;}}
function renderRef(ref){if(!ref){show('refState','Sem video de referencia. O alinhamento acustico continua disponivel.');return;}
const pct=Math.round(100*(ref.matched_ratio||0));const title=ref.video_title||'Referencia';
const detail=ref.caption_available?`${pct}% dos versos localizados; desvio mediano ${ref.offset_mad_seconds??'—'}s; diferenca de duracao ${ref.duration_difference??'—'}s.`:'O video nao tem faixa de legendas temporizadas disponivel.';
const kind=ref.reference_compatible?'success':'warn';show('refState',`${title}. ${detail} ${ref.reference_compatible?'Referencia consistente, ainda requer revisao.':'Somente comparacao: nao alterara o chart.'}`,kind);
if(ref.url&&ref.url.includes('youtube.com/watch'))$('referenceUrl').value=ref.url;
}
async function showCurrentReference(){const id=$('songs').value;if(!id)return;try{const data=await json(`/api/sync14/${encodeURIComponent(id)}/reference`);renderRef(data.reference);}catch(e){show('refState',e.message,'error');}}
async function previewReference(){const id=$('songs').value, url=$('referenceUrl').value.trim();if(!id||!url){show('refState','Selecione uma musica e cole o link do video.','error');return;}const btn=$('previewRef');btn.disabled=true;show('refState','Baixando apenas as legendas temporizadas do video. Aguarde...');try{const result=await json(`/api/sync14/${encodeURIComponent(id)}/reference/preview`,localPost({url}));renderRef(result);}catch(e){show('refState',e.message,'error');}finally{btn.disabled=false;}}
// NS14.3: video-frame OCR, independent of caption tracks.
let visualPoll=null;
function renderVisual(ref){
 if(!ref){$('visualState').textContent='Nenhuma leitura visual concluida nesta musica.';return;}
 const lines=ref.lines||[], compatible=ref.reference_compatible;
 const pct=Math.round(100*Number(ref.matched_ratio||0));
 const message=`${ref.video_title||'Karaokê'} · ${lines.length} versos ligados ao video (${pct}%) · `+
   `${ref.highlight_candidates||0} transicoes de cor candidatas · `+
   `${compatible?'Duracao/ordem compativeis.':'Gravacao/ordem possivelmente diferentes.'} `+
   'Isto e uma referencia visual, nao uma prova de sincronismo da voz. Chart original intacto.';
 $('visualState').textContent=message;
 $('visualState').className='refstate '+(compatible?'success':'warn');
}
async function readVisual(){const id=$('songs').value;if(!id)return;
 try{const data=await json(`/api/sync14/${encodeURIComponent(id)}/reference/visual`);renderVisual(data.reference)}
 catch(e){$('visualState').textContent=e.message;}}
async function visualScan(){
 const id=$('songs').value,url=$('referenceUrl').value.trim();
 if(!id||!url){$('visualState').textContent='Selecione a musica e cole o link de um video karaokê.';return;}
 const btn=$('scanVisual');btn.disabled=true;
 $('visualState').textContent='Iniciando analise de quadros do video...';
 try{
  await json(`/api/sync14/${encodeURIComponent(id)}/reference/visual`,localPost({url}));
  if(visualPoll)clearInterval(visualPoll);
  const checkVisual=async()=>{
    try{
      const status=await json(`/api/sync14/${encodeURIComponent(id)}/reference/visual/status`);
      $('visualState').textContent=status.stage||'Analisando...';
      if(status.state==='done'||status.state==='error'){
        clearInterval(visualPoll);visualPoll=null;btn.disabled=false;
        if(status.state==='error')$('visualState').textContent=status.error||'Falha na analise visual';
        else await readVisual();
      }
    }catch(e){clearInterval(visualPoll);visualPoll=null;btn.disabled=false;$('visualState').textContent=e.message;}
  };
  visualPoll=setInterval(checkVisual,2500);await checkVisual();
 }catch(e){btn.disabled=false;$('visualState').textContent=e.message;}
}
function render(report){const state=report.status_counts||{},n=report.reference_lines||0,changed=report.changed_lines||0,kept=report.validated_unchanged||0;
$('metrics').replaceChildren();for(const [label,value] of [['Versos analisados',n],['Corroborados',changed+kept],['Mudaram',changed],['Para revisar',report.review_required??'?']]){const box=document.createElement('div');box.className='metric';const big=document.createElement('div');big.className='value';big.textContent=value;const little=document.createElement('div');little.className='name';little.textContent=label;box.append(big,little);$('metrics').append(box);}
const rows=$('rows');rows.replaceChildren();for(const r of report.lines||[]){const tr=document.createElement('tr');tr.className=['aligned','validated_unchanged'].includes(r.status)?'':'warn';const status={aligned:'Mudanca corroborada',validated_unchanged:'Voz presente; tempo mantido',review:'Revisar letra/acustica',review_audio:'Pouca atividade vocal',review_shift:'Mudanca sem confirmacao',unmatched:'Verso nao identificado',review_order:'Conflito de ordem',review_large_shift:'Deslocamento grande',diagnostic_match:'Somente comparacao textual',pending_firstpass:'Aguardando validacao'}[r.status]||r.status;
for(const val of [r.text,stamp(r.old_at),stamp(r.candidate_at),`${r.delta_seconds>0?'+':''}${Number(r.delta_seconds||0).toFixed(2)} s`,`${Math.round(Number(r.confidence||0)*100)}%`,status]){const td=document.createElement('td');td.textContent=String(val);tr.append(td);}rows.append(tr);}
show('state',`NS14.3: ${changed} alteradas, ${kept} confirmadas sem mudanca, ${report.review_required??'?'} para revisar. Modelo ${report.evidence?.asr_model||'—'} / ${report.evidence?.device||'diagnostico'}. Original intacto.`,'success');}
async function getReport(){const id=$('songs').value;if(!id)return;try{render(await json(`/api/sync14/${encodeURIComponent(id)}/report`));}catch(e){show('state',e.message,'error');}}
async function check(){const id=$('songs').value;if(!id)return;try{const s=await json(`/api/sync14/${encodeURIComponent(id)}/status`);if(s.state==='done'){clearInterval(poller);poller=null;$('run').disabled=false;await getReport();}else if(s.state==='error'){clearInterval(poller);poller=null;$('run').disabled=false;show('state','Erro: '+s.error,'error');}else show('state',(s.state==='queued'?'Na fila: ':'Processando: ')+(s.stage||''));}catch(e){show('state',e.message,'error');}}
async function run(){const id=$('songs').value;if(!id){show('state','Selecione a musica.','error');return;}$('run').disabled=true;try{await json(`/api/sync14/${encodeURIComponent(id)}/run`,localPost({mode:document.querySelector('[name=mode]:checked').value,separate:$('separate').checked}));show('state','Analise iniciada...');if(poller)clearInterval(poller);poller=setInterval(check,2500);await check();}catch(e){show('state',e.message,'error');$('run').disabled=false;}}
async function environment(){try{const e=await json('/api/sync14/environment');$('environment').textContent=e.cuda?`GPU detectada: ${e.gpu} (${e.torch})`:`CUDA indisponivel no Python da analise: ${e.python||'desconhecido'}. ${e.error||'Executara na CPU.'}`;}catch(e){$('environment').textContent='Nao foi possivel verificar a GPU.';}}
$('songs').addEventListener('change',()=>{clearSuggestions();showCurrentReference();readVisual();});$('referenceResults').onchange=()=>$('referenceUrl').value=$('referenceResults').value;
$('lrcRef').onclick=lrcReference;$('autoRef').onclick=autoReference;$('searchRef').onclick=searchKaraoke;$('scanVisual').onclick=visualScan;$('refresh').onclick=loadSongs;$('report').onclick=getReport;$('run').onclick=run;
loadSongs().then(readVisual);environment();
})();
