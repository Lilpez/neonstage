(()=>{
'use strict';
if(window.__NS_PARTY_HUD_V3__)return;window.__NS_PARTY_HUD_V3__=true;
let el=null,inflight=false,elapsed=0;
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const pic=p=>p?.avatar?`<img src="${p.avatar}" style="width:36px;height:36px;object-fit:cover;border-radius:50%">`:`<span style="width:36px;height:36px;border-radius:50%;display:grid;place-items:center;background:#522d85">${esc((p?.name||'?')[0])}</span>`;
async function tick(){if(inflight)return;inflight=true;try{
 const res=await fetch('/api/party/state',{cache:'no-store'});if(!res.ok)return;const s=await res.json();
 const game=document.getElementById('gameScreen');const active=s.phase==='singing'&&game&&!game.classList.contains('hidden')&&window.NEON_PARTY?.isPlaying?.();
 if(!active){el?.remove();el=null;return}
 if(!el){el=document.createElement('aside');el.id='nsPartyRankingV3';el.style.cssText='position:fixed;right:22px;bottom:78px;z-index:100000;background:rgba(7,11,26,.83);backdrop-filter:blur(18px);border:1px solid #ffffff28;color:white;border-radius:18px;padding:15px;width:min(280px,30vw);max-height:42vh;overflow:auto;font:13px system-ui;box-shadow:0 16px 50px #0009';document.body.appendChild(el)}
 const entry=s.queue?.[s.position];const segments=s.duet_segments||[];let current=entry?.singer;for(const part of segments){if(part.at<=(s.playback?.time||0)+.12)current=part.singer;else break}const singer=s.players?.[current];const live=Number(s.playback?.live_score||0);
 const rank=s.players.map((p,i)=>({p,points:Number(s.scores[i]||0)+(entry?.duet?Number(s.playback?.live_scores?.[i]||0):(i===entry?.singer?live:0))})).filter(x=>x.p).sort((a,b)=>b.points-a.points);
 el.innerHTML=`<div style="font-size:10px;letter-spacing:.16em;color:#a9f1f5">NEONSTAGE PARTY</div><div style="margin:10px 0 13px;font-weight:900">NO MICROFONE: ${esc(singer?.name||'Convidado')}</div>`+rank.map((x,i)=>`<div style="display:flex;gap:9px;align-items:center;margin:7px 0"><b style="width:15px;color:#ffd87c">${i+1}</b>${pic(x.p)}<span style="min-width:0;flex:1;text-overflow:ellipsis;overflow:hidden;white-space:nowrap">${esc(x.p.name)}</span><b>${Math.round(x.points).toLocaleString('pt-BR')}</b></div>`).join('');
 }catch(e){}finally{inflight=false}}
setInterval(tick,1000);tick();
})();