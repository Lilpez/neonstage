$ErrorActionPreference = 'Stop'
# Feche o servidor antes de restaurar.
$root = 'C:\Users\freit\Downloads\NeonStage_V80'
$backup = 'C:\Users\freit\Downloads\NeonStage_V80\BACKUP_ANTES_NS14_20261012_190342_796143'
if (!(Test-Path $backup)) { throw 'Backup NS14 nao encontrado' }
Copy-Item -LiteralPath (Join-Path $backup 'app.py') -Destination (Join-Path $root 'app.py') -Force
Remove-Item -LiteralPath (Join-Path $root 'neon_sync_v2.py') -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath (Join-Path $root 'static\sync14.html') -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath (Join-Path $root 'static\sync14.css') -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath (Join-Path $root 'static\sync14.js') -Force -ErrorAction SilentlyContinue
Write-Host 'NS14 restaurada. Reinicie o NeonStage.' -ForegroundColor Green
