"""V8.18: presentation-only regrouping on V8.17 lyrics. Never edits scoring notes."""
from pathlib import Path
import json, shutil, os, re, datetime, hashlib
VERSION='v818-20261012a'
def _words(s):return len(re.findall(r'\b[\wÀ-ÿ]+\b',s,flags=re.UNICODE))
def _digest(chart):
    raw=json.dumps(chart.get('lyric_lines',[]),ensure_ascii=False,sort_keys=True)
    return hashlib.sha256(raw.encode('utf8')).hexdigest()
def regroup(root,song_id,force=False):
    song=Path(root)/'songs'/song_id; fn=song/'chart.json'
    if not fn.exists():return {'state':'missing_chart'}
    chart=json.loads(fn.read_text(encoding='utf8'))
    lines=chart.get('lyric_lines',[])
    if not lines:return {'state':'no_lyrics'}
    if chart.get('lyrics_grouping_version')==VERSION and not force:return {'state':'already_grouped','lines':len(lines)}
    orig_notes=json.dumps(chart.get('notes'),ensure_ascii=False,sort_keys=True)
    raw=sorted([dict(r) for r in lines if isinstance(r,dict)],key=lambda a:float(a.get('at',0)))
    merged=[];count=0;short=0
    # Group only a fragment explicitly created by the comma splitter; do not merge verified independent verses.
    for r in raw:
        text=str(r.get('text','')).strip()
        if merged and text and 'v817_aligned_split' in str(r.get('text_source','')):
            prev=merged[-1];left=str(prev.get('text','')).strip();right=text
            gap=float(r.get('at',0))-float(prev.get('at',0))
            joined=(left.rstrip()+' '+right.lstrip()).strip()
            # Short complete thought or unusually rapid split; leave longer lyrical phrases split.
            can=(left.endswith(',') and 0<=gap<=3.0 and _words(joined)<=9 and len(joined)<=67 and not prev.get('hidden') and not r.get('hidden'))
            if can:
                prev['text']=joined
                prev['text_source']=str(prev.get('text_source','genius'))+'_v818_grouped'
                count+=1
                continue
        merged.append(r)
    # Safety: regroup may only reduce lines; preserves original starts for surviving lines.
    if len(merged)>len(raw):raise RuntimeError('Line count increased unexpectedly')
    if orig_notes!=json.dumps(chart.get('notes'),ensure_ascii=False,sort_keys=True):raise RuntimeError('Notes changed')
    if count==0:
        # still mark processed to avoid repeat scans
        chart['lyrics_grouping_version']=VERSION
    else:
        chart['lyric_lines']=merged
        chart['lyrics_grouping_version']=VERSION
    backup=song/('chart_pre_v818_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.json')
    shutil.copy2(fn,backup)
    tmp=song/'chart.v818.tmp'
    try:
        tmp.write_text(json.dumps(chart,ensure_ascii=False,indent=2),encoding='utf8')
        os.replace(tmp,fn)
    finally:tmp.unlink(missing_ok=True)
    return {'state':'done','version':VERSION,'merged_short_comma_parts':count,'lines_before':len(raw),'lines_after':len(merged),'notes_unchanged':len(chart.get('notes',[])),'backup':str(backup)}
