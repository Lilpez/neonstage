"""V8.12: preserve the V8.11 phrase time structure; improve text/mark spoken intros.
No audio, note, pitch or phrase timing is modified.
"""
import collections
import difflib
import re
import unicodedata


def tokens(s):
    return re.findall(r"[^\W_]+(?:['’][^\W_]+)?", str(s), flags=re.UNICODE)


def norm(s):
    return re.sub(r'[^a-z0-9]', '', ''.join(c for c in unicodedata.normalize('NFKD', str(s).casefold()) if not unicodedata.combining(c)))


def clean_lines(rows):
    out = []
    for row in rows:
        s = str(row.get('text', '') if isinstance(row, dict) else row).strip()
        s = re.sub(r'(?i)^.{0,90}?\blyrics\b\s*(?:\[[^\]]*\])?', '', s).strip() if re.search(r'(?i)^.{0,90}?\blyrics\b', s) else s
        s = re.sub(r'^\s*\[[^\]]+\]\s*', '', s).strip()
        if re.match(r'(?i)^(embed|contributors|you might also like|translations|about|read more)\b', s):
            continue
        if len(tokens(s)) >= 2:
            out.append(s)
    return out


def similarity(a,b):
    aa = [norm(w) for w in tokens(a) if norm(w)]
    bb = [norm(w) for w in tokens(b) if norm(w)]
    if not aa or not bb: return 0., 0
    whole = difflib.SequenceMatcher(None, aa, bb, autojunk=False).ratio()
    chars = difflib.SequenceMatcher(None, ' '.join(aa), ' '.join(bb), autojunk=False).ratio()
    anchors = sum(1 for w in aa if len(w)>=5 and any(difflib.SequenceMatcher(None,w,z,autojunk=False).ratio() >= .78 for z in bb))
    size = min(len(aa),len(bb))/max(len(aa),len(bb))
    return (.55*whole+.45*chars)*(.65+.35*size),anchors


def correct_chart_text(chart, lyric_lines):
    notes=chart.get('notes') or []
    official=clean_lines(lyric_lines)
    grouped=collections.OrderedDict()
    for i,n in enumerate(notes):grouped.setdefault(n.get('phrase',0),[]).append(i)
    slots=[]
    for indices in grouped.values():
        text=' '.join(str(notes[i].get('asr_original', notes[i].get('text','')) or '').strip() for i in indices).strip()
        at=round(float(notes[indices[0]].get('start',0)),3)
        slots.append((indices,at,text))
    if not slots or not official:
        return chart,{'phrases_total':len(slots),'phrases_corrected':0,'reason':'no official lyrics'}
    # Existing trusted phrases are used only as a tie-breaker and preserved
    # if a new pass would degrade their match.
    old=chart.get('lyric_lines') or []
    prior={round(float(row.get('at',-999)),3):row for row in old if isinstance(row,dict)}
    candidate=[(s,) for s in official]+[(official[i], official[i+1]) for i in range(len(official)-1)]
    nlines=len(official)
    emission=[]
    for _,at,text in slots:
        row=[]
        for c in candidate:
            score,anchors=similarity(text,' '.join(c))
            # Extra weight for context learned from a prior, already verified line.
            oldrow=prior.get(at,{})
            if oldrow.get('text_source')=='genius_exact_line' and oldrow.get('text','').strip()==' '.join(c):score+=.025
            row.append((min(score,1.0),anchors))
        emission.append(row)
    # The same monotonic neighborhood as V8.11, with refrain resets possible.
    K=len(candidate);P=len(slots)
    prev=[v[0] for v in emission[0]]; back=[]
    for i in range(1,P):
        curr=[-1e9]*K;b=[0]*K
        for j in range(K):
            dst=j if j<nlines else j-nlines
            for k in range(K):
                src=k if k<nlines else k-nlines
                d=dst-src
                penalty=0. if d in (0,1) else (-.09*(d-1) if 2<=d<=3 else (-.30 if d<0 else -.33))
                value=prev[k]+penalty
                if value>curr[j]:curr[j]=value;b[j]=k
            curr[j]+=emission[i][j][0]
        prev=curr;back.append(b)
    path=[max(range(K),key=lambda j:prev[j])]
    for b in reversed(back):path.append(b[path[-1]])
    path.reverse()
    # Pick a contextual official candidate for uncertain slots using two-sided
    # nearby trusted anchors. Crucially, no ASR tokens are presented as final lyrics.
    confident=[]
    for i,j in enumerate(path):
        score,anchors=emission[i][j]
        original=slots[i][2]
        confident.append(score >= .74 and (anchors>=2 or (len(tokens(original))<5 and score>=.88)))
    result=[];corrected=0;provisional=0;hidden=0;preserved=0;estimated=0
    for i,(indices,at,original) in enumerate(slots):
        j=path[i];score,anchors=emission[i][j];c=candidate[j]
        chosen=' '.join(c)
        safe=score >= .74 and (anchors>=2 or (len(tokens(original))<5 and score>=.88))
        # Verified phrases that were already good should never be overwritten with a weaker choice.
        oldrow=prior.get(at,{})
        oldverified=oldrow.get('text_source')=='genius_exact_line' and oldrow.get('text')
        if oldverified:
            oscore,oanchors=similarity(original,oldrow['text'])
            if oscore>=max(.74,score-.025) and (oanchors>=2 or len(tokens(original))<5):
                chosen=oldrow['text'];safe=True;preserved+=1;c=(chosen,)
        # Suppress only highly credible unscripted stage speech. A low score alone
        # is NEVER enough to hide a potentially mistranscribed sung line.
        start_is_early=i<=2
        stage_cues=re.search(r'(?i)\b(boa noite|boa tarde|bom dia|obrigad[oa]|valeu|al[oô]|palmas|barulho|com voc[eê]s|galera|pessoal|aplausos|vamo[s]? l[aá]|essa vai|eu quero ouvir)\b',original)
        very_low=score<.38 and anchors==0
        spoken=bool(not safe and (stage_cues and (score<.58 or anchors==0)) and (start_is_early or very_low))
        if not safe and not spoken:
            # The V8.12 bug: asr_provisional exposed recognizable ASR mistakes,
            # often after a phrase was already corrected in an earlier pass.
            # Infer Genius text ONLY when local text or contextual anchors support it.
            left=next((k for k in range(i-1,-1,-1) if confident[k]),None)
            right=next((k for k in range(i+1,P) if confident[k]),None)
            contextual = left is not None or right is not None
            lexical = anchors>=1 or score>=.42
            if contextual and lexical:
                # Require monotonic order within reliable anchors (no wrap allowed
                # in this particular gap); repetition boundaries stay unmodified.
                target=j if j<nlines else j-nlines
                def pos(k):
                    x=path[k]
                    return x if x<nlines else x-nlines
                consistent=(left is None or target>=pos(left)) and (right is None or target<=pos(right))
                if consistent:
                    chosen=' '.join(c)
                    safe=True
                    estimated+=1
        if spoken:
            hidden+=1
            result.append({'at':at,'text':'','text_source':'stage_speech_hidden','match_confidence':round(score,3)})
        elif safe and len(c)==2 and len(indices)>=4:
            # Split using existing real WhisperX word timestamps, never interpolation.
            first,second=c
            originalwords=[str(notes[q].get('asr_original',notes[q].get('text',''))) for q in indices]
            pivots=[]
            for q in range(2,len(indices)-1):
                l,_=similarity(' '.join(originalwords[:q]),first)
                r,_=similarity(' '.join(originalwords[q:]),second)
                pivots.append((l+r,q))
            _,q=max(pivots)
            result.append({'at':at,'text':first,'text_source':'genius_exact_line','match_confidence':round(score,3)})
            result.append({'at':round(float(notes[indices[q]].get('start',at)),3),'text':second,'text_source':'genius_exact_line','match_confidence':round(score,3)})
            corrected+=1
        else:
            result.append({'at':at,'text':chosen if safe else '','text_source':('genius_contextual_estimate' if safe and score<.74 else 'genius_exact_line') if safe else 'unverified_hidden','match_confidence':round(score,3)})
            if safe:corrected+=1
            else:provisional+=1
        for q in indices:
            if 'asr_original' not in notes[q]:notes[q]['asr_original']=notes[q].get('text','')
    chart['lyric_lines']=result
    chart['lyrics_authority']='v813_original_whisper_time_genius_only_visible'
    chart['lyrics_timing_mode']='original_whisperx'
    chart['lyrics_phrase_policy']='preserve_verified_and_hide_confident_stage_speech'
    return chart,{'phrases_total':P,'phrases_corrected':corrected,'phrases_provisional':provisional,'stage_speech_hidden':hidden,'verified_preserved':preserved,'genius_estimated':estimated,'unverified_hidden':provisional,'notes_unchanged':len(notes)}
