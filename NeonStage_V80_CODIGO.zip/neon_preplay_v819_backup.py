"""Preplay V8.19: continue existing pipeline and apply final presentation grouping once."""
from pathlib import Path
import importlib.util

def process(root,song_id,force=False):
    root=Path(root)
    previous=root/'neon_preplay_v818_backup.py'
    if not previous.exists():return {'state':'missing_v818_preplay_backup'}
    spec=importlib.util.spec_from_file_location('_v818_preplay',str(previous))
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    result=mod.process(root,song_id,force=force)
    if not isinstance(result,dict) or result.get('state')!='done':return result
    from neon_v819_sequence import run
    return {'state':'done','previous':result,'v819':run(root,song_id)}
