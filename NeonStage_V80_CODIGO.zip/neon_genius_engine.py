
"""Genius metadata lookup + best-effort permitted page extraction for local RB4 Studio.
Does not claim that the Genius REST API itself returns lyrics.
"""
import json
import re
import sys
import unicodedata
import urllib.parse
import urllib.request
from html.parser import HTMLParser
from pathlib import Path
from difflib import SequenceMatcher


def norm(s):
    s = ''.join(c for c in unicodedata.normalize('NFKD', str(s).casefold()) if not unicodedata.combining(c))
    return ' '.join(re.sub(r'[^a-z0-9]+', ' ', s).split())


def clean_title(s):
    s = re.sub(r'\([^)]*(?:lyric|album|álbum|video|vídeo|official|oficial|audio|áudio)[^)]*\)', '', s, flags=re.I)
    s = re.sub(r'\[[^]]*(?:lyric|album|álbum|video|vídeo|official|oficial|audio|áudio)[^]]*\]', '', s, flags=re.I)
    s = re.sub(r'\[[^]]*(?:lyric|album|.lbum|video|v.deo|official|oficial|audio|.udio)[^]]*\]', '', s, flags=re.I)
    s = re.sub(r'\([^)]*(?:lyric|album|.lbum|video|v.deo|official|oficial|audio|.udio)[^)]*\)', '', s, flags=re.I)
    return ' '.join(s.split())


def ratio(a,b):
    return SequenceMatcher(None, norm(a), norm(b)).ratio()


# GENIUS_OPCOES_V75
def _variants(title):
    base = clean_title(title)
    base = re.sub(r'(?i)\b(?:na\s+praia\s+ao\s+vivo|ao\s+vivo|live|vers[a??]o\s+ac[u??]stica|ac[u??]stico|video\s+oficial|clipe\s+oficial|official\s+(?:music\s+)?video|lyric\s+video|audio\s+oficial|remaster(?:ed)?(?:\s+\d{4})?)\b.*$', '', base).strip(' -|:()[]')
    base = re.sub(r'(?i)\s*[-|:]\s*(?:na\s+praia|ao\s+vivo|live|ac[u??]stico|video\s+oficial|clipe\s+oficial).*$', '', base).strip(' -|:()[]')
    vals = [base, re.split(r'\s+[-|:]\s+', base)[0], clean_title(title)]
    return list(dict.fromkeys(x.strip() for x in vals if len(norm(x)) >= 3))


def _artist_match(wanted, found):
    a, b = norm(wanted), norm(found)
    if not a or not b:
        return 0.0
    if a == b: return 1.0
    if a in b or b in a: return .92
    return SequenceMatcher(None, a, b).ratio()


def search(token,title,artist):
    variants=_variants(title)
    if not variants:raise RuntimeError('Genius: titulo vazio apos limpeza')
    queries=[]
    for t in variants:
        queries.extend((f'{artist} {t}', t))
    queries=list(dict.fromkeys(queries))[:8]
    seen={}
    for q in queries:
        url='https://api.genius.com/search?q='+urllib.parse.quote(q)
        req=urllib.request.Request(url,headers={'Authorization':'Bearer '+token,'Accept':'application/json','User-Agent':'RB4KaraokeStudio/7.5'})
        try:
            with urllib.request.urlopen(req,timeout=20) as response:
                hits=json.load(response).get('response',{}).get('hits',[])
        except Exception as exc:
            print('GENIUS: consulta indisponivel:',str(exc)[:120],flush=True)
            continue
        print('GENIUS: busca',repr(q),'opcoes',len(hits),flush=True)
        for hit in hits:
            song=hit.get('result') or {}
            key=str(song.get('id') or song.get('url') or '')
            if not key:continue
            seen[key]=song
    scored=[]
    for song in seen.values():
        st=song.get('title','')
        sa=(song.get('primary_artist') or {}).get('name','')
        ts=max(ratio(t,st) for t in variants)
        at=_artist_match(artist,sa)
        # Title must really match, not merely share one word.
        score=.72*ts+.28*at
        scored.append((score,ts,at,song))
    scored.sort(key=lambda row:row[0],reverse=True)
    for sc,ts,at,song in scored[:8]:
        print('GENIUS OPCAO:',repr(song.get('title','')),'-',repr((song.get('primary_artist') or {}).get('name','')),'titulo=',round(ts,3),'artista=',round(at,3),flush=True)
    for score,ts,at,song in scored:
        if ts>=.83 and at>=.58 and score>=.77:
            print('GENIUS ESCOLHIDO:',repr(song.get('title','')),'ID:',song.get('id'),flush=True)
            return song,round(score,3)
    raise RuntimeError('Genius: nenhuma das opcoes corresponde com seguranca ao titulo e artista')


class LyricsHTML(HTMLParser):
    VOID_TAGS = {'br', 'img', 'hr', 'meta', 'input', 'source', 'wbr', 'link'}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.active = 0
        self.parts = []
        self.blocks = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if self.active:
            if tag == 'br':
                self.parts.append('\n')
            elif tag in ('p', 'div'):
                self.parts.append('\n')
            if tag not in self.VOID_TAGS:
                self.active += 1
            return
        if 'data-lyrics-container' in attrs and str(attrs['data-lyrics-container']).lower() in ('true', '1', ''):
            self.active = 1
            self.parts = []

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in self.VOID_TAGS:
            self.handle_endtag(tag)

    def handle_endtag(self, tag):
        if self.active and tag not in self.VOID_TAGS:
            self.active -= 1
            if self.active == 0:
                self.blocks.append(''.join(self.parts))

    def handle_data(self, data):
        if self.active:
            self.parts.append(data)


def strip_lyrics(raw):
    lines=[]
    for line in raw.replace('\r','').split('\n'):
        line=' '.join(line.strip().split())
        if not line or re.match(r'^\[(?:verse|chorus|intro|outro|bridge|refr[aã]o|verso|pré-refrão|pre-chorus|instrumental|hook|interlude|post-chorus)[^]]*\]$',line,re.I):
            continue
        line=re.sub(r'\d*Embed\s*$', '',line,flags=re.I).strip()
        if line:lines.append(line)
    return '\n'.join(lines)


# RB4_GUARDA_CABECALHO_V76

def limpar_cabecalho_genius(raw):
    """Remove metadados do site, nunca versos no meio da letra."""
    raw = raw.replace('\r','')
    raw = re.sub(r'(?im)^\s*\d+\s+contributors?\s*$', '', raw)
    raw = re.sub(r'(?im)^\s*(?:contributors?|translations?|read more|letra|lyrics)\s*$', '', raw)
    raw = re.sub(r'(?im)^\s*(?:\d+\s+)?contributors?\s*[^\n]*?\s+lyrics\s*(?=\S)', '', raw, count=1)
    # '6 Contributors Decide A? Lyrics Quando ...' (mesma linha)
    raw = re.sub(r'(?is)^\s*(?:\d+\s+)?contributors?\b[^\n]{0,180}?\blyrics\b\s*', '', raw, count=1)
    raw = re.sub(r'(?is)^\s*[^\n]{1,100}?\s+lyrics\s+(?=\S)', '', raw, count=1) if re.search(r'(?i)^\s*[^\n]{1,100}?\s+lyrics\s+', raw) else raw
    return raw.strip()

def parse_genius_html(html):
    parser=LyricsHTML();parser.feed(html)
    return limpar_cabecalho_genius(strip_lyrics('\n'.join(parser.blocks)))


def read_page(url):
    req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/125 Safari/537.36'})
    try:
        with urllib.request.urlopen(req,timeout=18) as r:
            return r.read(2500000).decode('utf-8','replace')
    except Exception as e:
        print('V6.7: HTML direto indisponivel:',type(e).__name__,flush=True)
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            browser=p.chromium.launch(channel='msedge',headless=True)
            try:
                page=browser.new_page()
                page.goto(url,wait_until='domcontentloaded',timeout=25000)
                return page.content()
            finally:browser.close()
    except Exception as e:
        print('V6.7: Edge automatizado indisponivel:',type(e).__name__,flush=True)
    return ''


def run(folder,title,artist,app):
    folder=Path(folder);app=Path(app)
    tokenfile=app/'genius_token.txt'
    if not tokenfile.is_file():raise RuntimeError('Genius: genius_token.txt ausente na pasta do aplicativo')
    token=tokenfile.read_text(encoding='utf-8-sig').strip()
    if not token or re.search(r'\s',token):raise RuntimeError('Genius: token vazio ou invalido')
    song,score=search(token,title,artist)
    url=song.get('url','')
    if not url.startswith('https://genius.com/'):
        raise RuntimeError('Genius: pagina nao corresponde ao dominio esperado')
    report={'source':'Genius','song_id':song.get('id'),'title':song.get('title'),'artist':(song.get('primary_artist') or {}).get('name'), 'url':url,'matching_score':score,'status':'metadata_found'}
    output=folder/'letra_genius_v67.txt'
    if output.exists():output.unlink()  # Nunca reutilizar letra de pesquisa anterior.
    html=read_page(url)
    lyrics=parse_genius_html(html) if html else ''
    tokens=re.findall(r'[^\W_]+',lyrics,re.U)
    if len(tokens)<45 or len(tokens)>1400 or len(lyrics)>25000:
        report['status']='lyrics_unavailable'
        (folder/'relatorio_v67.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        raise RuntimeError('Genius localizou a musica, mas a letra nao foi extraida/validada. Consulte a pagina: '+url+'')
    (folder/'letra_genius_v67.txt').write_text(lyrics+'\n',encoding='utf-8')
    report['status']='lyrics_extracted';report['word_count']=len(tokens)
    (folder/'relatorio_v67.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'V6.7: letra Genius recuperada: {len(tokens)} palavras; correspondencia de metadados {score:.1%}; id {song.get("id")}',flush=True)

if __name__=='__main__':run(*sys.argv[1:5])
