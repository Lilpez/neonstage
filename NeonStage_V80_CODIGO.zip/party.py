"""Local network party mode, two authenticated phone players and a localhost host."""
import json, os, secrets, threading, time
from pathlib import Path
from flask import request, jsonify


def register(app, root, songs, jobs, pool, run_job):
    lock=threading.RLock()
    file=Path(root)/'party_session.json'
    def fresh():
        return dict(version=4,preparations={},pin=f'{secrets.randbelow(900000)+100000}',players=[None,None],mode='solo',per_player=3,phase='lobby',host_index=None,queue=[],position=0,ready=[],scores=[0,0],playback=dict(song_id=None,time=0,playing=False,started_at=0),results=[],created=time.time())
    try:
        state=json.loads(file.read_text(encoding='utf-8')) if file.exists() else fresh()
        if state.get('version')==3 and isinstance(state.get('players'),list) and len(state['players'])==2:
            state['version']=4;state.setdefault('preparations',{})
        elif state.get('version')!=4 or not isinstance(state.get('players'),list) or len(state['players'])!=2:state=fresh()
    except Exception:state=fresh()
    for _presence in state.get('players',[]):
        if _presence:_presence['last_seen']=time.time()
    def save():
        tmp=file.with_suffix('.tmp')
        tmp.write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf-8')
        os.replace(tmp,file)
    def host():return request.remote_addr in ('127.0.0.1','::1')
    def player():
        token=(request.headers.get('X-Player-Token') or '')[:128]
        if not token:return None
        for idx,p in enumerate(state['players']):
            if p and secrets.compare_digest(p['token'],token):return idx
        return None
    def ensure_preparation(ch):
        ident=ch['id']
        if ident=='demo_neonstage' or (songs/ident/'chart.json').exists():
            return dict(song_id=ident,stage='Pronta',progress=100,error=None)
        cache=state.setdefault('preparations',{})
        previous=cache.get(ident)
        if previous:
            job=jobs.get(previous.get('job_id'),{})
            if job:return previous
            # Jobs from before a server restart cannot be resumed; start them again.
            # Restart interrupted background jobs after server restart / explicit retry
        from uuid import uuid4
        job_id='music_'+uuid4().hex[:14]
        jobs[job_id]=dict(stage='Aguardando processamento',progress=2,error=None,song_id=None)
        cache[ident]=dict(job_id=job_id)
        pool.submit(run_job,job_id,ident,ch['title'],ch['artist'])
        return cache[ident]

    def prep_info(ch):
        ident=ch['id']
        prep=state.setdefault('preparations',{}).get(ident)
        if ident=='demo_neonstage' or (songs/ident/'chart.json').exists():
            return dict(progress=100,stage='Pronta',song_id=ident,error=None)
        if not prep:return dict(progress=0,stage='Aguardando',song_id=None,error=None)
        job=jobs.get(prep.get('job_id'),{})
        return dict(progress=int(job.get('progress',0)),stage=job.get('stage','Na fila'),song_id=job.get('song_id'),error=job.get('error'))

    def view(include_pin=False):
        players=[]
        for i,p in enumerate(state['players']):
            players.append(dict(id=i,name=p['name'],avatar=p.get('avatar',''),choices=p['choices'],ready=p['ready']) if p else None)
        q=[]
        for item in state['queue']:
            job=prep_info(dict(id=item['video_id']))
            q.append({**item,'job':job,'song_id':job.get('song_id')})
        for pp in state['players']:
            if pp:
                for ch in pp['choices']:
                    if ch['id']!='demo_neonstage' and not (songs/ch['id']/'chart.json').exists():ensure_preparation(ch)
        unique={ch['id']:prep_info(ch) for pp in state['players'] if pp for ch in pp['choices']}
        progress=int(sum(x['progress'] for x in unique.values())/len(unique)) if unique else 0
        return dict(preparation=unique,preparation_percent=progress,preparation_total=len(unique),preparation_ready=sum(bool(x.get('song_id')) for x in unique.values()),host_index=state.get('host_index'),players=players,mode=state['mode'],per_player=state['per_player'],phase=state['phase'],next_at=state.get('next_at'),queue=q,position=state['position'],scores=state['scores'],playback=state['playback'],results=state['results'],pin=state['pin'] if include_pin else None)
    # NS_PARTY_PRESENCE_V1
    PRESENCE_TIMEOUT=25.0
    def touch_player():
        who=player()
        if who is not None:
            state['players'][who]['last_seen']=time.time()
        return who
    def expire_absent():
        # Only release slots in the lobby / choosing phase; never mid-song.
        if state.get('phase') not in ('lobby','choosing'):
            return False
        changed=False
        now=time.time()
        for i,p in enumerate(state['players']):
            if p and now-float(p.get('last_seen',now))>PRESENCE_TIMEOUT:
                state['players'][i]=None
                changed=True
                if state.get('host_index')==i:
                    state['host_index']=next((j for j,v in enumerate(state['players']) if v),None)
        if changed:save()
        return changed
    @app.post('/api/party/presence')
    def presence_ping():
        with lock:
            expire_absent()
            who=touch_player()
            if who is None:return jsonify(error='Sessao expirada. Entre novamente.'),401
            return jsonify(ok=True,player=who)
    @app.post('/api/party/kick')
    def kick_player():
        with lock:
            who=player()
            if not (host() or (who is not None and who==state.get('host_index'))):return forbidden()
            target=data().get('player')
            if type(target)!=int or not 0<=target<len(state['players']):return jsonify(error='Jogador invalido.'),400
            victim=state['players'][target]
            if not victim:return jsonify(error='Vaga ja esta vazia.'),409
            if state.get('phase') not in ('lobby','choosing'):
                return jsonify(error='So e possivel expulsar jogadores antes de iniciar as apresentacoes.'),409
            if who==target and not host():return jsonify(error='O anfitriao nao pode expulsar a si mesmo.'),400
            state['players'][target]=None
            if state.get('host_index')==target:
                state['host_index']=next((i for i,p in enumerate(state['players']) if p),None)
            save()
            return jsonify(ok=True,player=target,state=view())
    def data():return request.get_json(silent=True) or {}
    def forbidden():return jsonify(error='Acesso negado.'),403
    def is_phone_host():return player() is not None and player()==state.get('host_index')
    def authorized_host():return host() or is_phone_host()
    @app.get('/party')
    def phone_page():return app.send_static_file('party.html')
    @app.get('/host')
    def host_page():
        if not authorized_host():return forbidden()
        return app.send_static_file('host.html')
    @app.get('/api/party/state')
    def state_api():
        with lock:
            expire_absent();touch_player()
            return jsonify(view(include_pin=host()))
    @app.get('/api/party/me')
    def me():
        with lock:
            expire_absent();who=touch_player()
            return jsonify(player=who if who is not None else -1)
    @app.post('/api/party/join')
    def join():
        inp=data();pin=str(inp.get('pin',''))
        name=str(inp.get('name','')).strip()[:25]
        if not name:return jsonify(error='Escolha um nome.'),400
        with lock:
            if pin!=state['pin']:return jsonify(error='Código da sala incorreto.'),403
            expire_absent()
            existing=player()
            if existing is not None:
                touch_player()
                return jsonify(token=state['players'][existing]['token'],player=existing,state=view())
            if state['phase'] not in ('lobby','choosing'):return jsonify(error='A sessão já foi iniciada.'),409
            slot=next((i for i,p in enumerate(state['players']) if p is None),None)
            if slot is None:return jsonify(error='A sala já tem dois jogadores.'),409
            token=secrets.token_urlsafe(32)
            state['players'][slot]=dict(name=name,token=token,choices=[],ready=False,last_seen=time.time())
            if state.get('host_index') is None:state['host_index']=slot
            save();return jsonify(token=token,player=slot,state=view())
    @app.post('/api/party/avatar')
    def avatar_upload():
        with lock:
            who=player()
            if who is None:return forbidden()
            avatar=data().get('avatar','')
            if not isinstance(avatar,str) or len(avatar)>65000:
                return jsonify(error='Imagem muito grande.'),400
            if avatar and not __import__('re').fullmatch(r'data:image/(?:jpeg|png|webp);base64,[A-Za-z0-9+/=]+',avatar):
                return jsonify(error='Formato de imagem invalido.'),400
            state['players'][who]['avatar']=avatar
            save()
            return jsonify(ok=True)

    @app.post('/api/party/open-choices')
    def open_choices():
        with lock:
            if not is_phone_host():return forbidden()
            if state['phase']!='lobby':return jsonify(error='Escolhas já iniciadas.'),409
            if not all(state['players']):return jsonify(error='Aguardando os dois jogadores.'),409
            state['phase']='choosing';save();return jsonify(view())
    @app.post('/api/party/transfer')
    def transfer():
        with lock:
            if not is_phone_host():return forbidden()
            target=data().get('player')
            if type(target)!=int or target not in (0,1) or not state['players'][target]:
                return jsonify(error='Jogador inválido.'),400
            state['host_index']=target;save();return jsonify(view())
    @app.post('/api/party/launch')
    def launch():
        with lock:
            if not is_phone_host():return forbidden()
            if state['phase']!='choosing':return jsonify(error='As escolhas ainda não foram abertas.'),409
            if not all(p and p['ready'] and len(p['choices'])==state['per_player'] for p in state['players']):
                return jsonify(error='Cada jogador precisa confirmar as três músicas.'),409
            _assemble_queue();save();return jsonify(view())
    @app.post('/api/party/host-action')
    def host_action():
        with lock:
            if not is_phone_host():return forbidden()
            action=data().get('action')
            if action=='next':
                if state['phase'] not in ('preparing','between'):return jsonify(error='Não é hora de iniciar.'),409
                if state['position']>=len(state['queue']):return jsonify(error='Fila concluída.'),409
                if not all(prep_info(dict(id=x['video_id'])).get('song_id') for x in state['queue']):
                    return jsonify(error='Aguardando preparação das músicas.'),409
                entry=state['queue'][state['position']]
                sid=prep_info(dict(id=entry['video_id'])).get('song_id')
                state['phase']='singing';state.pop('next_at',None);state['playback']=dict(song_id=sid,time=0,playing=False,started_at=time.time(),live_score=0)
            elif action=='reset':
                old=state['players'];new=fresh()
                new['host_index']=state.get('host_index')
                for i,x in enumerate(old):
                    if x:new['players'][i]=dict(name=x['name'],avatar=x.get('avatar',''),token=x['token'],choices=[],ready=False)
                state.clear();state.update(new)
            else:return jsonify(error='Ação desconhecida.'),400
            save();return jsonify(view())
    @app.post('/api/party/choices')
    def choices():
        inp=data()
        with lock:
            who=player()
            if who is None:return forbidden()
            if state['phase']!='choosing':return jsonify(error='Aguarde o anfitrião abrir a escolha de músicas.'),409
            p=state['players'][who]
            if p['ready']:return jsonify(error='Você já confirmou sua lista.'),409
            song=inp.get('song') or {}
            vid=str(song.get('id',''))
            if not (__import__('re').fullmatch(r'[A-Za-z0-9_-]{11}',vid) or (vid.startswith('music_') and (songs/vid/'chart.json').exists()) or vid=='demo_neonstage'):
                return jsonify(error='Versão inválida.'),400
            if len(p['choices'])>=state['per_player']:return jsonify(error='Você atingiu o limite de músicas.'),409
            choice=dict(id=vid,title=str(song.get('title','Música'))[:150],artist=str(song.get('artist','Artista'))[:120])
            p['choices'].append(choice)
            ensure_preparation(choice)
            save();return jsonify(view())
    @app.post('/api/party/remove')
    def remove():
        with lock:
            who=player()
            if who is None:return forbidden()
            p=state['players'][who]
            if state['phase']!='choosing' or p['ready']:return jsonify(error='Lista bloqueada.'),409
            idx=data().get('index')
            if not isinstance(idx,int) or not 0<=idx<len(p['choices']):return jsonify(error='Índice inválido.'),400
            p['choices'].pop(idx);save();return jsonify(view())
    @app.post('/api/party/ready')
    def ready():
        with lock:
            who=player()
            if who is None:return forbidden()
            if state['phase']!='choosing':return jsonify(error='As escolhas ainda não estão abertas.'),409
            p=state['players'][who]
            if len(p['choices'])!=state['per_player']:return jsonify(error=f'Escolha {state["per_player"]} músicas antes de confirmar.'),400
            p['ready']=True
            save();return jsonify(view())
    @app.post('/api/party/config')
    def config():
        if not authorized_host():return forbidden()
        with lock:
            if state['phase'] not in ('lobby','choosing'):return jsonify(error='Configuração bloqueada.'),409
            mode=data().get('mode')
            if mode not in ('solo','shared'):return jsonify(error='Modo inválido.'),400
            if any(p and p['ready'] for p in state['players']):return jsonify(error='Jogadores já confirmaram escolhas.'),409
            state['mode']=mode;save();return jsonify(view(include_pin=True))
    def prepare_all(queue):
        for entry in queue:
            ch=dict(id=entry['video_id'],title=entry['title'],artist=entry['artist'])
            prep=ensure_preparation(ch)
            if prep.get('song_id'):entry['song_id']=prep['song_id']
            if prep.get('job_id'):entry['job_id']=prep['job_id']
    def _assemble_queue():
        ps=state['players'];queue=[]
        for roundno in range(state['per_player']):
            for owner in (0,1):
                ch=ps[owner]['choices'][roundno]
                for singer in ((0,1) if state['mode']=='shared' else (owner,)):
                    queue.append(dict(video_id=ch['id'],title=ch['title'],artist=ch['artist'],owner=owner,singer=singer,round=roundno+1))
        state.update(phase='preparing',queue=queue,position=0,results=[],scores=[0,0],playback=dict(song_id=None,time=0,playing=False,started_at=0))
        prepare_all(state['queue'])

    @app.post('/api/party/mode')
    def player_mode():
        with lock:
            who=player()
            if who!=state.get('host_index'):return forbidden()
            mode=data().get('mode')
            if mode not in ('solo','shared'):return jsonify(error='Modo inválido.'),400
            if state['phase'] not in ('lobby','choosing') or any(p and p['ready'] for p in state['players']):return jsonify(error='Modo bloqueado após a confirmação.'),409
            state['mode']=mode;save();return jsonify(view())

    @app.post('/api/party/next')
    def player_next():
        with lock:
            who=player()
            if who is None:return forbidden()
            if state['phase'] not in ('preparing','between'):return jsonify(error='Aguardando o turno.'),409
            if state['position']>=len(state['queue']):return jsonify(error='Playlist concluída.'),409
            entry=state['queue'][state['position']]
            if who!=state.get('host_index'):return jsonify(error='Somente o anfitrião inicia o turno.'),403
            if not all(prep_info(dict(id=x['video_id'])).get('song_id') for x in state['queue']):
                return jsonify(error='A playlist ainda está sendo preparada.'),409
            sid=prep_info(dict(id=entry['video_id'])).get('song_id')
            state['phase']='singing';state.pop('next_at',None);state['playback']=dict(song_id=sid,time=0,playing=False,started_at=time.time(),live_score=0)
            save();return jsonify(view())

    @app.post('/api/party/lock')
    def lock_playlist():
        if not authorized_host():return forbidden()
        with lock:
            if state['phase']!='choosing':return jsonify(error='Primeiro abra as escolhas.'),409
            ps=state['players']
            if not all(p and p['ready'] for p in ps):return jsonify(error='Aguardando ambos confirmarem suas três músicas.'),409
            _assemble_queue()
            save();return jsonify(view(include_pin=True))
    @app.post('/api/party/retry')
    def retry():
        if not authorized_host():return forbidden()
        with lock:
            if state['phase']!='preparing':return jsonify(error='Preparação não está ativa.'),409
            failed={x['video_id'] for x in state['queue'] if prep_info(dict(id=x['video_id'])).get('error')}
            if not failed:return jsonify(error='Nenhuma música com erro; as demais continuam carregando.'),400
            for ident in failed:state['preparations'].pop(ident,None)
            prepare_all([x for x in state['queue'] if x['video_id'] in failed])
            save();return jsonify(view(include_pin=True))
    @app.post('/api/party/control')
    def control():
        if not authorized_host():return forbidden()
        inp=data();action=inp.get('action')
        with lock:
            if action=='start':
                if state['phase'] not in ('preparing','between'):return jsonify(error='A fila não está pronta.'),409
                if state['position']>=len(state['queue']):return jsonify(error='Playlist concluída.'),409
                entry=state['queue'][state['position']]
                sid=prep_info(dict(id=entry['video_id'])).get('song_id')
                if not sid:return jsonify(error='Essa música ainda está sendo preparada.'),409
                state['phase']='singing';state.pop('next_at',None);state['playback']=dict(song_id=sid,time=0,playing=False,started_at=time.time(),live_score=0)
            elif action=='heartbeat':
                if state['phase']!='singing':return jsonify(error='Não há música em execução.'),409
                try:t=max(0,min(36000,float(inp.get('time',0))))
                except (ValueError,TypeError):t=0
                state['playback'].update(time=t,playing=bool(inp.get('playing')),started_at=time.time(),live_score=max(0,int(inp.get('score') or 0)))
                return jsonify(ok=True)
            elif action=='complete':
                if state['phase']!='singing':return jsonify(error='Não há música ativa.'),409
                singer=state['queue'][state['position']]['singer']
                score=max(0,min(5000000,int(inp.get('score') or 0)))
                state['scores'][singer]+=score
                state['results'].append(dict(index=state['position'],singer=singer,score=score,failed=bool(inp.get('failed',False)),skipped=bool(inp.get('skipped',False))))
                state['position']+=1;state['phase']='completed' if state['position']>=len(state['queue']) else 'between'
                state['next_at']=time.time()+5 if state['phase']=='between' else None  # NS_PARTY_AUTO5_V1
                state['playback'].update(playing=False)
            elif action=='reset':
                old=state['players'];new=fresh()
                for i,p in enumerate(old):
                    if p:new['players'][i]=dict(name=p['name'],avatar=p.get('avatar',''),token=p['token'],choices=[],ready=False)
                new['host_index']=state.get('host_index')
                state.clear();state.update(new)
            else:return jsonify(error='Ação desconhecida.'),400
            save();return jsonify(view(include_pin=True))
    return state
