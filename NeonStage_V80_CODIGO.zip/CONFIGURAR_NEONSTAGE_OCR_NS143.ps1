﻿$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$basePython = Join-Path $root '.venv\Scripts\python.exe'
$envDir = Join-Path $root '.ns143_ocr'
$python = Join-Path $envDir 'Scripts\python.exe'

if (!(Test-Path -LiteralPath $basePython -PathType Leaf)) {
    throw 'Python principal do NeonStage nao encontrado.'
}
if (!(Test-Path -LiteralPath $python -PathType Leaf)) {
    Write-Host 'NS14.3: Criando ambiente isolado para OCR...' -ForegroundColor Cyan
    & $basePython -m venv $envDir
    if ($LASTEXITCODE -ne 0) { throw 'Falha ao criar ambiente OCR.' }
}

# A Windows PowerShell 5.1 command-line may strip the double quotes in python -c.
# Execute a real .py file instead, so quotes and strings are preserved exactly.
$probe = Join-Path $envDir 'neon143_verify_ocr.py'
$lines = @(
    'import importlib.util, sys'
    'required = ("rapidocr", "cv2", "onnxruntime", "yt_dlp")'
    'missing = [name for name in required if importlib.util.find_spec(name) is None]'
    'if missing:'
    '    print("MISSING: " + ", ".join(missing), flush=True)'
    '    sys.exit(10)'
    'if "--initialize" in sys.argv:'
    '    import cv2, onnxruntime, yt_dlp'
    '    from rapidocr import RapidOCR'
    '    engine = RapidOCR(params={"Rec.lang_type": "pt"})'
    '    print("OCR pronto para portugues; OpenCV " + cv2.__version__, flush=True)'
    'else:'
    '    print("Dependencias OCR presentes", flush=True)'
)
Set-Content -LiteralPath $probe -Value $lines -Encoding ASCII

& $python $probe
if ($LASTEXITCODE -ne 0) {
    Write-Host 'Instalando as dependencias OCR no ambiente isolado...' -ForegroundColor Cyan
    & $python -m pip install --disable-pip-version-check --no-input --prefer-binary 'rapidocr>=3.10,<4' 'onnxruntime>=1.18,<2' 'opencv-python-headless>=4.8,<5' 'yt-dlp>=2025.1'
    if ($LASTEXITCODE -ne 0) { throw 'Falha ao instalar OCR. Confira as mensagens do pip e a internet.' }
}

Write-Host 'Validando importacao e inicializacao do modelo OCR em portugues...' -ForegroundColor Cyan
& $python $probe '--initialize'
if ($LASTEXITCODE -ne 0) {
    throw 'Nao foi possivel inicializar o RapidOCR em portugues. Copie o erro Python acima.'
}
Write-Host 'NS14.3 OCR CONFIGURADO COM SUCESSO. Reinicie o NeonStage.' -ForegroundColor Green
