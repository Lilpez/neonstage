from pathlib import Path
import datetime
import re
import shutil

ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"

BACKUP = ROOT / (
    "backup_utf8_fase11_" +
    datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
)

# Recover the original byte values from characters
# produced by an incorrect Windows-1252 decoding.
CP1252_REVERSE = {}

for n in range(128, 160):
    try:
        character = bytes([n]).decode("cp1252")
        CP1252_REVERSE[character] = n
    except UnicodeDecodeError:
        pass

NON_ASCII_RUN = re.compile(r"[^\x00-\x7f]{2,}")

def recover_run(match):
    original = match.group(0)

    try:
        raw = bytes(
            ord(ch) if ord(ch) <= 255
            else CP1252_REVERSE[ch]
            for ch in original
        )

        decoded = raw.decode("utf-8")

        return decoded

    except (KeyError, ValueError, UnicodeDecodeError):
        return original

def repair(content):
    for _ in range(3):
        fixed = NON_ASCII_RUN.sub(recover_run, content)

        if fixed == content:
            break

        content = fixed

    return content

changed = []
files = [
    p for p in STATIC.iterdir()
    if p.is_file()
    and p.suffix.lower() in (".html", ".js", ".css")
]

for path in sorted(files):
    try:
        original = path.read_text(encoding="utf-8-sig")
    except UnicodeDecodeError:
        print("IGNORADO:", path.name)
        continue

    corrected = repair(original)

    if corrected == original:
        continue

    # Validate JavaScript when Node.js is available.
    # Validation failures prevent modifying that file.
    if path.suffix.lower() == ".js":
        import subprocess
        import shutil as sh

        node = sh.which("node")

        if node:
            result = subprocess.run(
                [node, "--check", "-"],
                input=corrected,
                text=True,
                capture_output=True
            )

            if result.returncode != 0:
                print("IGNORADO (sintaxe JS):", path.name)
                continue

    destination = BACKUP / "static" / path.name
    destination.parent.mkdir(
        parents=True, exist_ok=True
    )

    shutil.copy2(path, destination)

    path.write_text(
        corrected,
        encoding="utf-8",
        newline=""
    )

    changed.append(path.name)

print()
print("=" * 50)
print(" NEONSTAGE - REPARO UTF-8 FASE 1.1")
print("=" * 50)

if changed:
    for name in changed:
        print("CORRIGIDO:", name)
else:
    print("Nenhuma sequencia recuperavel encontrada.")

print()
print("Total de arquivos:", len(changed))
print("Backup:", BACKUP if changed else "Nao necessario")
print("Musicas e charts: inalterados")
print("Navegacao por paginas: preservada")
