from pathlib import Path
import datetime, re, shutil, sys
root=Path(__file__).resolve().parent
static=root/'static'
index=static/'index.html'
source=root/'_party_bridge_payload.js'
target=static/'neon_party_pc_bridge.js'
if not index.exists() or not (static/'app.js').exists():
    raise SystemExit('NeonStage invalido: nao encontrei o HTML e motor de canto.')
old=index.read_text(encoding='utf-8-sig')
if not re.search(r'</body\s*>',old,re.I):
    raise SystemExit('HTML invalido: body nao encontrado.')
backup=root/('backup_party_remote_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
backup.mkdir()
shutil.copy2(index,backup/'index.html')
if target.exists():shutil.copy2(target,backup/target.name)
try:
    # Remove any prior injection without touching original music engine.
    html=re.sub(r'<script\b(?=[^>]*neon_party_pc_bridge\.js)[^>]*>\s*</script\s*>','',old,flags=re.I)
    html=re.sub(r'</body\s*>','<script src="/static/neon_party_pc_bridge.js?v=1"></script>\n</body>',html,count=1,flags=re.I)
    target.write_bytes(source.read_bytes())
    index.write_text(html,encoding='utf-8',newline='')
    assert index.read_text(encoding='utf-8').count('neon_party_pc_bridge.js')==1
except Exception:
    shutil.copy2(backup/'index.html',index)
    if (backup/target.name).exists():shutil.copy2(backup/target.name,target)
    else:target.unlink(missing_ok=True)
    raise
print('PONTE PARTY -> PALCO SINGLEPLAYER INSTALADA')
print('Backup:',backup)
print('Abrir NeonStage PC em http://127.0.0.1:8765/inicio')
print('A musica inicia quando o host tocar Comecar a cantar no celular.')
print('O navegador pode exigir autorizacao inicial do microfone/audio.')
