"""Verified lyrics facade: never expose WhisperX words as song lyrics."""
from neon_auto_genius import lookup as auto_lookup

def lookup(title,artist,*args,**kwargs):
    try:
        return auto_lookup(title,artist,0,"",__import__("pathlib").Path(__file__).resolve().parent)
    except Exception as exc:
        print('Genius indisponivel:',repr(exc),flush=True)
        return None
