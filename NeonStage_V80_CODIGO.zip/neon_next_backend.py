"""NeonStage Consolidated: optional stem management and local capabilities.
Keep all user media in app.SONGS; no silent migration or chart rewriting.
"""
from __future__ import annotations
import re, sys, subprocess, threading, uuid
from pathlib import Path
from flask import request, jsonify, send_from_directory

_ID = re.compile(r'[A-Za-z0-9_-]{1,64}\Z')

def find_stems(directory: Path):
    candidates=list((directory/'separation').rglob('vocals.wav')) if (directory/'separation').is_dir() else []
    for v in candidates:
        instrumental=v.with_name('no_vocals.wav')
        if instrumental.is_file() and v.is_file():
            return v,instrumental
    return None

def register(app, songs, jobs, pool, lock):
    @app.get('/api/neon/mix/<song_id>')
    def next_mix_info(song_id):
        if not _ID.fullmatch(song_id):return jsonify(error='ID invalido'),400
        d=songs/song_id
        if not d.is_dir():return jsonify(error='Musica nao encontrada'),404
        pair=find_stems(d)
        if not pair:return jsonify(ready=False,can_separate=any((d/f'audio.{ext}').exists() for ext in ('mp3','wav','m4a','ogg')))
        return jsonify(ready=True, instrumental='/api/neon/stem/'+song_id+'/instrumental',vocals='/api/neon/stem/'+song_id+'/vocals')

    @app.get('/api/neon/stem/<song_id>/<kind>')
    def next_stem(song_id,kind):
        if not _ID.fullmatch(song_id) or kind not in ('vocals','instrumental'):return ('Invalid',400)
        d=songs/song_id
        pair=find_stems(d)
        if not pair:return ('Stems not found',404)
        file=pair[0] if kind=='vocals' else pair[1]
        return send_from_directory(file.parent,file.name,conditional=True)

    @app.post('/api/neon/separate/<song_id>')
    def next_separate(song_id):
        if request.remote_addr not in ('127.0.0.1','::1'):return jsonify(error='Use o PC do servidor.'),403
        if not _ID.fullmatch(song_id):return jsonify(error='ID invalido'),400
        d=songs/song_id
        if not d.is_dir() or not (d/'chart.json').is_file():return jsonify(error='Musica nao encontrada'),404
        if find_stems(d):return jsonify(ready=True)
        src=next((d/f'audio.{ext}' for ext in ('mp3','wav','m4a','ogg') if (d/f'audio.{ext}').is_file()),None)
        if not src:return jsonify(error='Audio nao encontrado'),404
        job_id='separate_'+uuid.uuid4().hex[:12]
        with lock:jobs[job_id]=dict(stage='Na fila para separar voz',progress=2,error=None,song_id=None)
        def job():
            with lock:jobs[job_id].update(stage='Separando vocal e instrumental (Demucs)',progress=22)
            try:
                proc=subprocess.run([sys.executable,'-m','demucs','--two-stems','vocals','-n','htdemucs','--shifts','1','-o',str(d/'separation'),str(src)],capture_output=True,text=True,timeout=1800)
                if proc.returncode or not find_stems(d):raise RuntimeError((proc.stderr or proc.stdout or 'Demucs nao encontrou stems')[-480:])
                with lock:jobs[job_id].update(stage='Vocal separado',progress=100,song_id=song_id)
            except Exception as exc:
                with lock:jobs[job_id].update(stage='Falha na separacao',progress=0,error=str(exc)[:450])
        pool.submit(job)
        return jsonify(job_id=job_id)
