"""Conservative acoustic word-anchor lyric-order validation. Never changes notes."""
import re,unicodedata,json,shutil,os,datetime
from pathlib import Path
VERSION='v820-20261012a'
def norm(x):
 x=''.join(c for c in unicodedata.normalize('NFKD',str(x).lower()) if not unicodedata.combining(c))
 return re.findall(r'[a-z0-9]+',x)
def anchors(text,notes):
 words=norm(text)
 if not words:return []
 found=[]
 for i,n in enumerate(notes):
  if not norm(n.get('asr_original',n.get('text',''))):continue
  found.append((i,norm(n.get('asr_original',n.get('text','')))[0]))
 # Require at least three consecutive word matches. Longer contiguous sequences get priority.
 spans=[]
 for j in range(len(found)):
  k=j
  while k<len(found) and k-j<len(words):
   if found[k][1]!=words[k-j]:break
   k+=1
  if k-j>=max(3,min(5,len(words))):
   spans.append((k-j, float(notes[found[j][0]].get('start',0)),float(notes[found[k-1][0]].get('end',0))))
 return sorted(spans,key=lambda r:(-r[0],r[1]))
def process_chart(chart):
 notes=chart.get('notes') or []
 lines=[dict(l) for l in chart.get('lyric_lines',[]) if isinstance(l,dict)]
 lines.sort(key=lambda x:float(x.get('at',0)))
 if not lines or not notes:return chart,{'state':'no_data'}
 fixed=[]; moved=0;duplicates=0; flags=[]
 # Narrow search before/after the currently assigned time; never move a confirmed phrase far away.
 for i,line in enumerate(lines):
  t=float(line.get('at',0));text=str(line.get('text','')).strip()
  if text and 'hidden' not in str(line.get('text_source','')):
   candidates=anchors(text,notes)
   eligible=[a for a in candidates if abs(a[1]-t)<=1.5]
   if eligible:
    rank,acoustic,end=eligible[0]
    if rank>=4 and abs(acoustic-t)>.65:
     # Only adjust within an occupied temporal neighborhood, and never crossing neighboring lines.
     prev=float(fixed[-1].get('at',-1e9)) if fixed else -1e9
     next_t=float(lines[i+1].get('at',1e9)) if i+1<len(lines) else 1e9
     if prev+.05<acoustic<next_t-.05:
      line['at']=round(max(0,acoustic-.12),3)
      line['v820_word_anchor']=True;moved+=1
   else:
    # Report unresolved rather than inventing a line for an unrelated audio region.
    if len(norm(text))>=4:flags.append({'at':t,'text':text,'reason':'no_nearby_word_anchor'})
  # Eliminate only truly overlapping duplicate lyrics, not refrains.
  if fixed and text and norm(text)==norm(fixed[-1].get('text','')) and t-float(fixed[-1].get('at',0))<3.5:
   duplicates+=1;continue
  fixed.append(line)
 chart['lyric_lines']=sorted(fixed,key=lambda x:float(x.get('at',0)))
 chart['lyrics_sequence_validation_version']=VERSION
 return chart,{'state':'done','lines_before':len(lines),'lines_after':len(fixed),'anchored_onsets':moved,'overlap_duplicates_removed':duplicates,'flags':flags[:30],'notes_unchanged':len(notes)}
def run(root,song_id,force=False):
 root=Path(root);path=root/'songs'/song_id/'chart.json'
 if not path.exists():return {'state':'missing_chart'}
 chart=json.loads(path.read_text(encoding='utf-8'))
 if chart.get('lyrics_sequence_validation_version')==VERSION and not force:return {'state':'already_processed'}
 before=json.dumps(chart.get('notes'),sort_keys=True,ensure_ascii=False)
 chart,report=process_chart(chart)
 assert before==json.dumps(chart.get('notes'),sort_keys=True,ensure_ascii=False)
 backup=path.parent/('chart_pre_v820_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.json')
 shutil.copy2(path,backup)
 tmp=path.with_suffix('.v820.tmp')
 try:
  tmp.write_text(json.dumps(chart,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(tmp,path)
 finally:tmp.unlink(missing_ok=True)
 report['backup']=str(backup)
 (path.parent/'v820_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
 return report
