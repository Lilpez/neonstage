"""Offline singing analysis: Demucs -> WhisperX words -> pitch notes.
Runs using an existing torch/WhisperX installation if available.
Only produces a chart for genuinely detected speech/vocals.
"""
from __future__ import annotations
import sys,json,subprocess,math,os,re
from pathlib import Path
import numpy as np

source=Path(sys.argv[1]).resolve(); target=Path(sys.argv[2]).resolve()
title=sys.argv[3]; artist=sys.argv[4]
print('STAGE: Extraindo vocal',flush=True)
root=target.parent
vocals=source
try:
    args=[sys.executable,'-m','demucs','--two-stems','vocals','-n','htdemucs','--shifts','1','-o',str(root/'separation'),str(source)]
    p=subprocess.run(args,capture_output=True,text=True,timeout=1000)
    candidates=list((root/'separation').rglob('vocals.wav'))
    if p.returncode==0 and candidates:vocals=candidates[0]
    else:print('Demucs indisponível; analisando mix completo',flush=True)
except Exception as exc:print('Demucs indisponível:',str(exc)[:100],flush=True)

import librosa
print('STAGE: Reconhecendo palavras no áudio',flush=True)
import whisperx
import torch
device='cuda' if torch.cuda.is_available() else 'cpu'
compute='float16' if device=='cuda' else 'int8'
wave=whisperx.load_audio(str(vocals))
model=whisperx.load_model('small',device,compute_type=compute,language=None)
result=model.transcribe(wave,batch_size=8 if device=='cuda' else 2)
lang=result.get('language') or 'pt'
segments=result.get('segments') or []
del model
if device=='cuda':torch.cuda.empty_cache()

try:
    model_a,metadata=whisperx.load_align_model(language_code=lang,device=device)
    aligned=whisperx.align(segments,model_a,metadata,wave,device,return_char_alignments=False)
    segments=aligned.get('segments') or segments
    del model_a
    if device=='cuda':torch.cuda.empty_cache()
except Exception as exc:
    print('Align fallback:',str(exc)[:180],flush=True)

words=[]
for seg in segments:
    wlist=seg.get('words') or []
    if not wlist:
        tokens=(seg.get('text') or '').split()
        if not tokens:continue
        st=float(seg.get('start') or 0); end=float(seg.get('end') or st+len(tokens)*.3)
        wlist=[dict(word=x,start=st+(end-st)*i/len(tokens),end=st+(end-st)*(i+1)/len(tokens)) for i,x in enumerate(tokens)]
    for w in wlist:
        text=str(w.get('word') or '').strip()
        text=re.sub(r'\s+',' ',text)
        if not text:continue
        if w.get('start') is None or w.get('end') is None:continue
        st=max(0,float(w['start']));end=max(st+.07,float(w['end']))
        if words and st < words[-1]['end']:
            st=max(st,words[-1]['end']+.005)
            end=max(end,st+.07)
        words.append(dict(start=st,end=end,text=text))

if len(words)<3:raise RuntimeError('O reconhecimento de voz não encontrou palavras suficientes para gerar a pista automaticamente.')

print('STAGE: Calculando melodia vocal',flush=True)
# Pitch is estimated from isolated vocals. Unreliable pitch becomes talkie.
# No RB-style MIDI manipulation is needed: gameplay uses continuous-time notes.
y,sr=librosa.load(str(vocals),sr=16000,mono=True)
duration=len(y)/sr
hop=512
f0=None; confidence=None
try:
    import torchcrepe
    x=torch.tensor(y,device=device,dtype=torch.float32).unsqueeze(0)
    pred,conf=torchcrepe.predict(x,16000,hop,55,1000,model='full',batch_size=512,device=device,return_periodicity=True)
    f0=pred.squeeze().detach().cpu().numpy()
    confidence=conf.squeeze().detach().cpu().numpy()
    del x,pred,conf
except Exception as exc:
    print('TorchCREPE indisponível:',str(exc)[:110],flush=True)
    # Fast, non-neural fallback. Mark low-confidence notes as talkies.
    f0=librosa.yin(y,fmin=70,fmax=900,sr=sr,frame_length=2048,hop_length=hop)
    confidence=np.full_like(f0,0.44)

notes=[]
for index,w in enumerate(words):
    a=max(0,int(w['start']*sr/hop));b=min(len(f0),max(a+1,int(w['end']*sr/hop)))
    pitches=f0[a:b]; confs=confidence[a:b]
    valid=np.isfinite(pitches)&(pitches>=65)&(pitches<=950)&(confs>=.48)
    coverage=float(np.mean(valid)) if len(valid) else 0
    quality=float(np.median(confs[valid])) if np.any(valid) else 0
    if np.any(valid):
        midi=np.rint(69+12*np.log2(pitches[valid]/440))
        pitch=int(np.clip(round(float(np.median(midi))),36,84))
        consistency=float(np.mean(abs(midi-pitch)<=2))
    else:
        pitch=60;consistency=0
    talkie=coverage<.28 or quality<.52 or consistency<.46
    notes.append(dict(start=round(w['start'],3),end=round(min(duration,w['end']),3),pitch=pitch,text=w['text'],talkie=talkie,confidence=round(quality*coverage*consistency,3),phrase=0))

# Group words into scoring phrases at breaths, but no longer than 8-10 seconds.
phrases=[]; startidx=0
for i in range(len(notes)):
    last=i==len(notes)-1
    gap=0 if last else notes[i+1]['start']-notes[i]['end']
    elapsed=notes[i]['end']-notes[startidx]['start']
    punctuation=bool(re.search(r'[.!?;:]$',notes[i]['text']))
    if last or (elapsed>=2.3 and (gap>=.38 or punctuation)) or elapsed>=8.5:
        if notes[i]['end']>notes[startidx]['start']:
            idx=len(phrases)
            phrases.append(dict(start=round(max(0,notes[startidx]['start']-.08),3),end=round(min(duration,notes[i]['end']+.1),3),index=idx))
            for k in range(startidx,i+1):notes[k]['phrase']=idx
        startidx=i+1

# Negative/future/outlier timestamps are clipped; do not synthesize gameplay notes from silence.
notes=[n for n in notes if n['end']>n['start'] and n['start']<duration]
chart=dict(title=title,artist=artist,duration=round(duration,2),bpm=None,language=lang,notes=notes,phrases=phrases,source='analysis',analysis='whisperx_torchcrepe' if 'torchcrepe' in sys.modules else 'whisperx_yin',warning='Afinação e reconhecimento são estimativas automáticas; revise trechos difíceis.',pitch_hop=hop/sr)
# V8.7: original V4 WhisperX timebase and note grouping are never modified by Genius.
try:
    from neon_text_correction import correct_chart_text
    official=None
    try:
        from lyrics_verified import lookup
        official=lookup(title,artist,0)
    except Exception as exc:
        print('GENIUS: falha de busca (pista preservada):',str(exc)[:180],flush=True)
    if official and official.get('lyric_lines'):
        chart,stats=correct_chart_text(chart,official['lyric_lines'])
        chart['lyrics_reference'] = official.get('lyrics_verified_source','Genius')
        print('TEXTO: correcoes',stats['corrected'],'de',stats['words'],'palavras. Tempos originais preservados.',flush=True)
    else:
        chart,stats=correct_chart_text(chart,[])
        chart['lyrics_notice']='Letra externa indisponivel; transcricao WhisperX provisoria'
        chart['lyrics_authority']='asr_provisional'
except Exception as exc:
    print('TEXTO: correcao indisponivel, mantendo chart da V4:',str(exc)[:220],flush=True)

target.write_text(json.dumps(chart,ensure_ascii=False,indent=2),encoding='utf-8')
print('STAGE: Pista vocal pronta',flush=True)
print('Palavras',len(notes),'frases',len(phrases),'talkies',sum(n['talkie'] for n in notes),flush=True)
